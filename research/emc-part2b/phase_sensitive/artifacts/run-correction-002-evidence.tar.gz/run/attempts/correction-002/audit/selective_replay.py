"""Draw-free selected saved-observation replay including correction-001 witness."""
import csv, json, hashlib, sys
from pathlib import Path
import numpy as np
A=Path(__file__).resolve().parent; RUN=A.parent; STUDY=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(STUDY))
import phase_models as m
import measurement_experiment as x

def rows(p):
    with (RUN/p).open(newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256((RUN/p).read_bytes()).hexdigest()
obs={kind:rows(f'data/{kind}_observed.csv') for kind in ('calibration','direct','pool','evaluation')}
selected={
('1','50','full','2','5','unmeasured','A1_P'),
('1','50','full','2','5','unmeasured','A2_P'),
('4','17','hard','2','5','measured','A2_P'),
('2','31','full','1','-1','direct','A2_H')}
keys=('cell_id','cohort_id','support_group','stage','budget','stratum','arm')
chosen={}
for r in rows('results/predictions.csv'):
    k=tuple(r[a] for a in keys)
    if k in selected and k not in chosen:chosen[k]=r
assert len(chosen)==len(selected)
input_hash={p.name:sha('data/'+p.name) for p in sorted((RUN/'data').glob('*_observed.csv'))}
checks=[]
for k,row in chosen.items():
    cell,cohort,group,stage,budget,stratum,arm=k
    cell=int(cell);cohort=int(cohort);budget=int(budget)
    support=x.support(group)
    cal=[r for r in obs['calibration'] if int(r['cell_id'])==cell and int(r['cohort_id'])==cohort]
    Y=np.stack([x.array(r,('QXRD_Q','QXRD_A','QXRD_R')) for r in cal])
    center_support=(True,False,True) if cell==4 else (True,True,True)
    initial=m.fit_initial(Y,x.RQ,center_support=center_support)
    sample=next(r for r in obs['direct' if stage=='1' else ('pool' if stratum=='measured' else 'evaluation')] if r['sample_id']==row['sample_id'])
    if stage=='1':
        typ=arm[-1] if arm!='A1' else 'B';indices={'B':[0,1],'T':[0,1,2],'H':[0,1,3]}[typ]
        D=x.D4[indices];y=x.array(sample,('SiO2','TiO2','redundant_Ti','H_A'))[indices];cov=x.R4[np.ix_(indices,indices)];prior=initial
    else:
        tag=arm.split('_',1)[1];mode='N' if tag=='N' or tag.endswith('0') else tag
        local='B' if stratum=='unmeasured' or tag=='N' else tag[0]
        D,y,cov=x.design(local,sample,stratum=='measured')
        prior=initial
        if mode!='N':
            pool=[r for r in obs['pool'] if int(r['cell_id'])==cell and int(r['cohort_id'])==cohort][:budget]
            units=[]
            for p in pool:
                d,v,c=x.design(mode,p,True)
                units.append({'unit_id':p['sample_id'],'D':d,'y':v,'cov':c})
            prior=m.update_mean(initial,units,support=support,exclude_unit=sample['sample_id'] if stratum=='measured' else None)
    method=arm[:2]
    assert prior['status']=='ok'
    est=m.estimate(None,None,None,prior,method='A1',support=support) if method=='A1' else m.estimate(y,D,cov,prior if method=='A2' else None,method=method,strength={1:1,2:.01,3:1,4:1}[cell],support=support)
    assert est['status']=='ok'
    original=np.array([float(sample[z]) for z in ('SiO2','TiO2')]);replay=x.prediction_row({**dict(zip(keys,k)),'sample_id':row['sample_id']},est,row['prior_id'],row['observation_design_id'],original)
    mass=np.array(est['mass']);saved=np.array([float(row[z]) for z in ('Q_hat','A_hat','R_hat')]);err=float(np.max(abs(mass-saved)))
    objective_error=abs(float(row['objective'])-float(est['objective']))
    assert err<=1e-12 and objective_error<=1e-12
    checks.append({'key':k,'sample_id':row['sample_id'],'prior_status':prior['status'],'mass_max_abs_error':err,'objective_abs_error':objective_error,'mass':mass.tolist(),'saved_mass':saved.tolist()})
assert input_hash=={p.name:sha('data/'+p.name) for p in sorted((RUN/'data').glob('*_observed.csv'))}
# Open truth only after every replay prediction has been finalized.
truth={r['sample_id']:r for kind in ('direct','pool','evaluation') for r in rows(f'data/{kind}_truth.csv')}
for check in checks:
    t=np.array([float(truth[check['sample_id']][z]) for z in 'QAR'])
    score=float(np.mean((np.array(check['mass'])-t)**2))
    saved_score=float(np.mean((np.array(check['saved_mass'])-t)**2))
    check['scoring_mse_abs_error']=abs(score-saved_score)
    assert check['scoring_mse_abs_error']<=1e-12
out={'verdict':'PASS','method':'selected saved observations fitted with current source, no generator/no fresh draws; truth only read for post-prediction score','tolerance_spec':'atol=1e-12,rtol=0','tolerance_used':'atol=1e-12,rtol=0','observed_sha256':input_hash,'checks':checks}
(A/'selective_replay.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'verdict':'PASS','selected':len(checks),'max_mass_error':max(q['mass_max_abs_error'] for q in checks)}))
