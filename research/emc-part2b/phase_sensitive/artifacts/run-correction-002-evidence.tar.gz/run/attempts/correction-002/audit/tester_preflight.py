"""Independent, draw-free tester extension to named analytical and provenance probes."""
import ast, copy, hashlib, importlib.util, json, os, pathlib, subprocess, sys, tempfile
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[4]
OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import phase_models as m
import measurement_experiment as x
U=np.array([[2/np.sqrt(6),0],[-1/np.sqrt(6),1/np.sqrt(2)],[-1/np.sqrt(6),-1/np.sqrt(2)]])
C=np.array([[1.,0,0],[0,1,1]])
Y=np.array([.6,.1,.3])+np.array([[.06,0],[-.06,0],[0,.09],[0,-.09]])@U.T
Rcal=np.eye(3)*.0004
p=m.fit_initial(Y,Rcal)
rows=[]
def check(i,name,expected,actual,tol='exact'):
    if tol!='exact':
        a=np.asarray(actual,dtype=float); e=np.asarray(expected,dtype=float)
        err=float(np.max(abs(a-e))) if a.shape==e.shape else float('inf')
        good=err<=tol
    else:
        err=None; good=actual==expected
    rows.append(dict(check_id=i,metric=name,expected=np.asarray(expected).tolist() if isinstance(expected,np.ndarray) else expected,actual=np.asarray(actual).tolist() if isinstance(actual,np.ndarray) else actual,tolerance=tol,error=err,verdict='PASS' if good else 'FAIL'))
def invalid(i,name,f):
    try: f(); actual='NO_EXCEPTION'
    except Exception as e: actual=type(e).__name__
    check(i,name,'ValueError',actual)
# D01: inputs and prior integrity across all public APIs.
for api,call in [('estimate',lambda D,cov:m.estimate([.6,.4],D,cov,method='A0')),('bounds',lambda D,cov:m.abundance_bounds([.6,.4],D,cov)),('info',lambda D,cov:m.information(D,cov))]:
    for name,D in [('empty',np.zeros((0,3))),('wrong',np.zeros((2,2))),('ragged',[[1,0,0],[0,1]]),('bool',np.ones((2,3),bool)),('inf',np.full((2,3),np.inf)),('complex',C+1j)]:
        invalid('D01',api+'.D.'+name,lambda D=D,call=call:call(D,np.eye(2)))
    for name,cov in [('bool',np.eye(2,dtype=bool)),('complex',np.eye(2)+1j),('inf',np.eye(2)*np.inf),('nonsym',[[1,.1],[0,1]],),('singular',np.zeros((2,2)))]:
        invalid('D01',api+'.cov.'+name,lambda cov=cov,call=call:call(C,cov))
    for sup in [(False,False,False),(1,1,1),(True,False),'bad']:
        invalid('D01',api+'.support.'+str(sup),lambda sup=sup,api=api:({'estimate':lambda:m.estimate([.6,.4],C,np.eye(2),method='A0',support=sup),'bounds':lambda:m.abundance_bounds([.6,.4],C,np.eye(2),support=sup),'info':lambda:m.information(C,np.eye(2),support=sup)}[api]()))
for name,bad in [('failed',dict(p,status='numerical_failure')),('missing',{'status':'ok'}),('T_negative',dict(p,tangent_cov=[[.01,0],[0,-.01]])),('M_singular',dict(p,mean_cov=[[0,0],[0,0]])),('K_bad',dict(p,precision=np.eye(3).tolist())),('center_bad',dict(p,center=[1.1,-.1,0])),('diag_bad',dict(p,diagnostics={}))]:
    invalid('D01','estimate.prior.'+name,lambda bad=bad:m.estimate([.6,.4],C,np.eye(2),bad,method='A2'))
    invalid('D01','update.prior.'+name,lambda bad=bad:m.update_mean(bad,[]))
for name,units in [('notlist',{}),('badunit',[1]),('badID',[{'unit_id':''}]),('badD',[{'unit_id':'x','D':[[1,2]],'y':[1],'cov':[[1]]}]),('badY',[{'unit_id':'x','D':C,'y':['a','.4'],'cov':np.eye(2)}]),('badCov',[{'unit_id':'x','D':C,'y':[.6,.4],'cov':np.zeros((2,2))}])]:
    invalid('D01','update.units.'+name,lambda units=units:m.update_mean(p,units))
for v in [-1,0,float('nan'),True,'3']:
    invalid('D01','bounds.multiplier.'+str(v),lambda v=v:m.abundance_bounds([.6,.4],C,np.eye(2),multiplier=v))
for v in [True,'1',1+1j]:
    invalid('D01','estimate.strength.'+str(v),lambda v=v:m.estimate([.6,.4],C,np.eye(2),p,method='A2',strength=v))
check('D01','signed.calibration', 'ok',m.fit_initial(np.array(Y)-.7,Rcal)['status'])
# D02 no aliasing, five APIs. Results contain Python lists and input mutation is prohibited.
for name,fn,inputs in [('fit',lambda:m.fit_initial(Y,Rcal),[Y,Rcal]),('update',lambda:m.update_mean(p,[{'unit_id':'x','D':C,'y':np.array([.6,.4]),'cov':np.eye(2)}]),[p,C]),('estimate',lambda:m.estimate(np.array([.6,.4]),C,np.eye(2),p,method='A2'),[p,C]),('info',lambda:m.information(C,np.eye(2)),[C]),('bounds',lambda:m.abundance_bounds([.6,.4],C,np.eye(2)),[C])]:
    before=copy.deepcopy(inputs); a=fn(); b=fn()
    check('D02',name+'.repeat',json.dumps(a,sort_keys=True),json.dumps(b,sort_keys=True))
    check('D02',name+'.input_unchanged',True,all(np.array_equal(v,w) if isinstance(v,np.ndarray) else v==w for v,w in zip(inputs,before)))
    check('D02',name+'.no_return_alias',True,not any(isinstance(v,np.ndarray) and np.shares_memory(v,np.asarray(a.get('mass',a.get('center',[])))) for v in inputs))
with tempfile.TemporaryDirectory(prefix='ps-import-') as td:
    code="import sys,pathlib,numpy as np; np.random.seed(123); s=np.random.get_state(); sys.path.insert(0,%r); import phase_models, measurement_experiment; assert all(np.array_equal(a,b) if isinstance(a,np.ndarray) else a==b for a,b in zip(s,np.random.get_state())); assert not list(pathlib.Path('.').iterdir())"%str(ROOT)
    run=subprocess.run([sys.executable,'-B','-c',code],cwd=td,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    check('D02','isolated_import_exit',0,run.returncode);check('D02','isolated_import_stdout','',run.stdout);check('D02','isolated_import_stderr','',run.stderr)
# D03 analytic spectrum and negative signed mean already above; inspect retained diagnostics.
for name in ('raw_mean','raw_tangent_cov','deconvolved_eigenvalues','floored_eigenvalues','projection_distance'):
    check('D03','diagnostic.'+name,True,name in p['diagnostics'])
# D04 full rank fixed-Q correlated conditional solution and strength-zero tied face.
D=np.vstack([C,[0,1,0]])
RR=np.array([[.0001,.00003,.00001],[.00003,.0001,.00002],[.00001,.00002,.00008]])
y=np.array([.62,.39,.23]); W=np.linalg.inv(RR)
expected_A=y[2]+W[2,:2]@(y[:2]-[.6,.4])/W[2,2]
check('D04','fixedQ_fullrank',[.6,expected_A,.4-expected_A],m.estimate(y,D,RR,method='A0',fixed_quartz=.6)['mass'],1e-8)
for q,expected in [(0,[0,.5,.5]),(1,[1,0,0])]:
    check('D04','fixedQ_boundary_'+str(q),expected,m.estimate([.62,.39],C,x.RB,method='A0',fixed_quartz=q)['mass'],1e-8)
check('D04','fixedQ_positive_strength_center',p['center'],m.estimate([.6,.4],C,x.RB,p,method='A2',fixed_quartz=.6)['mass'],1e-8)
# D05 independent KKT by feasible directional objective comparisons and witness perturbation.
for name,D0,y0,cov0,sup in [('interior',D,[.6,.4,.1],np.eye(3),(True,True,True)),('edge',D,[.6,.4,-.2],np.eye(3),(True,True,True)),('vertex',D,[1.,0.,0.],np.eye(3),(True,True,True)),('hard',C,[.6,.4],x.RB,(True,False,True)),('fixed',C,[.62,.39],x.RB,(True,True,True))]:
    kw={'fixed_quartz':.6} if name=='fixed' else {}
    e=m.estimate(y0,D0,cov0,method='A0',support=sup,**kw)
    mass=np.array(e['mass']); obs=np.array(y0); cov=np.array(cov0)
    obj=lambda z:float(.5*(obs-D0@z)@np.linalg.solve(cov,obs-D0@z))
    vertices=np.eye(3)[np.array(sup)]
    if name=='fixed':vertices=np.array([[.6,.4,0],[.6,0,.4]])
    gaps=[obj((1-t)*mass+t*v)-obj(mass) for v in vertices for t in (.001,.1,1)]
    check('D05',name+'.status','ok',e['status']);check('D05',name+'.feasible',True,e['constraint_violation']<=1e-9)
    check('D05',name+'.certified',True,e['kkt_residual']<=1e-8)
    check('D05',name+'.directional_min_gap',True,min(gaps)>=-1e-10)
    check('D05',name+'.perturbed_rejected',True,(name=='hard' and abs((mass+np.array([0,.01,-.01]))[1])>1e-9) or any(obj((1-t)*mass+t*v)<obj(mass+np.array([0,.01,-.01])) for v in vertices for t in (0,.1)))
# D04 independent unconstrained 2D stationary solve in tangent coordinates.
mu=np.array([.6,.1,.3]); bulk=np.array([.62,.39]); cov=x.RB; K=np.array(p['precision']); lam=1.
H=C.T@np.linalg.solve(cov,C)+lam*K
f=C.T@np.linalg.solve(cov,bulk)+lam*K@mu
z=np.linalg.solve(U.T@H@U,U.T@(f-H@np.ones(3)/3))
stationary=np.ones(3)/3+U@z
fitted=m.estimate(bulk,C,cov,p,method='A2',strength=lam)
check('D04','correlated_A2_stationary_mass',stationary,fitted['mass'],1e-8)
resid=bulk-C@stationary
objective=float(.5*resid@np.linalg.solve(cov,resid)+.5*(stationary-mu)@K@(stationary-mu))
check('D04','correlated_A2_objective',objective,fitted['objective'],1e-12)
check('D04','correlated_A2_signed_residual',resid,fitted['residual'],1e-12)
# D05 independent linear-program KKT multiplier witness, free inequalities only.
from scipy.optimize import linprog
for name,D0,y0,cov0,sup in [('interior',D,[.6,.4,.1],np.eye(3),(True,True,True)),('edge',D,[.6,.4,-.2],np.eye(3),(True,True,True)),('vertex',D,[1.,0.,0.],np.eye(3),(True,True,True)),('rankdef',C,[.6,.4],np.eye(2),(True,True,True)),('hard',C,[.6,.4],x.RB,(True,False,True)),('fixed',C,[.62,.39],x.RB,(True,True,True))]:
    kwargs={'fixed_quartz':.6} if name=='fixed' else {}
    e=m.estimate(y0,D0,cov0,method='A0',support=sup,**kwargs)
    mass=np.array(e['mass']); H0=D0.T@np.linalg.solve(cov0,D0); f0=D0.T@np.linalg.solve(cov0,y0);g=H0@mass-f0
    equal=[np.ones(3)]
    if name=='fixed':equal.append(np.array([1.,0,0]))
    equal +=[np.eye(3)[j] for j in range(3) if not sup[j]]
    active=[j for j in range(3) if sup[j] and mass[j]<=1e-9]
    mat=np.column_stack(equal+[-np.eye(3)[j] for j in active])
    n_eq=len(equal)
    # min infinity norm residual using independent LP; free equality multipliers.
    A_ub=np.vstack([np.column_stack((mat,-np.ones(3))),np.column_stack((-mat,-np.ones(3)))])
    b_ub=np.r_[-g,g]
    witness=linprog(np.r_[np.zeros(mat.shape[1]),1.],A_ub=A_ub,b_ub=b_ub,bounds=[(None,None)]*n_eq+[(0,None)]*len(active)+[(0,None)],method='highs')
    scale=max(1,np.linalg.norm(H0,np.inf)*max(1,np.linalg.norm(mass,np.inf))+np.linalg.norm(f0,np.inf))
    check('D05',name+'.independent_kkt_lp',True,bool(witness.success and witness.x[-1]/scale<=1e-8))
    check('D05',name+'.primal',True,bool(abs(sum(mass)-1)<=1e-9 and min(mass)>=-1e-9 and all(abs(mass[j])<=1e-9 for j in range(3) if not sup[j])))
# D06 full within-unit intrinsic covariance and two-sided LOO.
T=np.eye(2)*.01;M0=np.eye(2)*.001;mu=np.array([.6,.1,.3])
p0=copy.deepcopy(p);p0.update(center=mu.tolist(),tangent_cov=T.tolist(),mean_cov=M0.tolist(),precision=(U@np.linalg.inv(T+M0)@U.T).tolist());p0['diagnostics']['mean_information']=np.linalg.inv(M0).tolist();p0['diagnostics']['mean_score']=(np.linalg.inv(M0)@U.T@(mu-np.ones(3)/3)).tolist()
RB=x.RB; L=np.vstack([C,C]); Rc=np.block([[RB,np.zeros((2,2))],[np.zeros((2,2)),RB]])
A=L@U;V=A@T@A.T+Rc
check('D06','cross_repeat_intrinsic_nonzero',True,bool(np.max(abs(V[:2,2:]))>0))
P=np.linalg.inv(M0)+A.T@np.linalg.solve(V,A)
wrong=np.linalg.inv(M0)+2*(C@U).T@np.linalg.solve((C@U)@T@(C@U).T+RB,C@U)
unit={'unit_id':'x','D':L,'y':L@mu,'cov':Rc}
u=m.update_mean(p0,[unit])
check('D06','repeat_mean_cov',np.linalg.inv(P),u['mean_cov'],1e-12)
check('D06','wrong_independent_differs',True,float(np.max(abs(P-wrong)))>1)
unit2={'unit_id':'y','D':np.eye(3),'y':mu+U@np.array([.01,-.02]),'cov':Rcal}
for excluded,other in [('x',unit2),('y',unit)]:
    a=m.update_mean(p0,[unit,unit2],exclude_unit=excluded);b=m.update_mean(p0,[other])
    check('D06','LOO_'+excluded,b['center'],a['center'],1e-12)
    check('D06','LOO_M_'+excluded,b['mean_cov'],a['mean_cov'],1e-12)
# D08 independent tangent singular values and correlated objective.
for name,D0,cov in [('C',C,x.RB),('Ct',np.vstack([C,C[1]]),x.R4[:3,:3]),('Ch',D,x.R4[np.ix_([0,1,3],[0,1,3])])]:
    A=D0@U; e=np.linalg.eigvalsh(A.T@np.linalg.solve(cov,A)); sv=np.sqrt(np.maximum(e,0))[::-1]
    info=m.information(D0,cov)
    check('D08',name+'.tangent_singular',sv,info['singular_tangent'],1e-8)
q=m.estimate([.62,.39],C,x.RB,p,method='A2'); qdiag=m.estimate([.62,.39],C,np.diag(np.diag(x.RB)),p,method='A2')
check('D08','correlation_objective_diff',True,abs(q['objective']-qdiag['objective'])>1e-8)
# D09 independent 2D polygon half-plane vertex enumeration.
def polygon(D0,y0,cov,mult=3):
    width=mult*np.sqrt(np.diag(cov)); lo=np.array(y0)-width; hi=np.array(y0)+width
    # Coordinates (Q,A), R=1-Q-A.
    B=np.array([[1,0,0],[0,1,0],[0,0,1]])
    normals=[(np.array([-1.,0.]),0.),(np.array([0.,-1.]),0.),(np.array([1.,1.]),1.)]
    for row,l,h in zip(D0,lo,hi):
        coeff=np.array([row[0]-row[2],row[1]-row[2]])
        normals += [(coeff,h-row[2]),(-coeff,row[2]-l)]
    points=[]
    for j,(a,b) in enumerate(normals):
        for c,d in normals[j+1:]:
            mat=np.stack([a,c]);
            if abs(np.linalg.det(mat))<1e-12:continue
            v=np.linalg.solve(mat,[b,d])
            if all(n@v<=h+1e-10 for n,h in normals):points.append(np.array([v[0],v[1],1-sum(v)]))
    return np.min(points,axis=0),np.max(points,axis=0)
for name,D0,y0,cov in [('bulk',C,[.6,.4],x.RB),('phase',D,[.6,.4,.1],np.diag([.0001,.0001,.0004]))]:
    lo,hi=polygon(D0,y0,cov); b=m.abundance_bounds(y0,D0,cov)
    check('D09',name+'.lower',lo,b['lower'],1e-8);check('D09',name+'.upper',hi,b['upper'],1e-8)
b=m.abundance_bounds([.6,.4],C,x.RB);more=m.abundance_bounds([.6,.4,.1],D,np.diag([.0001,.0001,.0004]))
check('D09','nested_width',True,all(a<=b+1e-8 for a,b in zip(more['width'],b['width'])))
check('D09','hard_width_A',0,m.abundance_bounds([.6,.4],C,x.RB,support=(True,False,True))['width'][1],1e-8)
check('D09','fixedQ_width_Q',0,m.abundance_bounds([.6,.4],C,x.RB,fixed_quartz=.6)['width'][0],1e-8)
# D10 recompute frozen parent public API for matching deterministic cases.
parent_path=x.REPO/'research/emc-part2b/prior_guided/calibration_models.py'
spec=importlib.util.spec_from_file_location('frozen_parent',parent_path);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
for sup in [(True,True,True),(True,False,True)]:
  op=old.fit_prior(Y,Rcal,support=sup); np0=m.fit_initial(Y,Rcal,center_support=sup)
  check('D10','parent_T_'+str(sup),op['tangent_cov'],np0['tangent_cov'],1e-12)
  check('D10','parent_M_'+str(sup),op['mean_cov'],np0['mean_cov'],1e-12)
  for fixed in [None,.6]:
    if fixed is not None:
      op=old.fit_prior(Y,Rcal,support=sup,fixed_quartz=fixed)
      np0=copy.deepcopy(np0); np0['center']=[.6,0,.4] if not sup[1] else [.6,.1,.3]
    for method in ['A0','A1','A2']:
      for strength in ([0,.01,1] if method=='A2' else [0]):
        kwargs=dict(method=method,support=sup,fixed_quartz=fixed,strength=strength)
        oe=old.estimate(None if method=='A1' else [.62,.39],None if method=='A1' else x.RB,None if method=='A0' else op,**kwargs)
        ne=m.estimate(None if method=='A1' else [.62,.39],None if method=='A1' else C,None if method=='A1' else x.RB,None if method=='A0' else np0,**kwargs)
        check('D10',f'{sup}.{fixed}.{method}.{strength}.mass',oe['mass'],ne['mass'],1e-8)
# D11 immutable real design/source/inventory; temp negative gate without generator invocation.
cfg,review,freeze=x.design_gate(ROOT/'preregistration.json',ROOT/'PREEXECUTION_REVIEW.json')
check('D11','design_digest',freeze['design_digest'],review['design_digest'])
source=x.complete_source_manifest(cfg)
check('D11','source_file_count',5,len(source['files']))
check('D11','parent_nonimport','read-only reference; no import or call by study code',source['parent_reference']['use'])
check('D11','package_pin',x.PIN,source['public_package']['pin'])
seeds=x.seed_manifest(); oldset=set(seeds['historical_seed_set']); newset={z['seed'] for z in seeds['streams']}
check('D11','historical_paths',11,len(seeds['historical_manifests']))
check('D11','historical_seed_count',2009,len(oldset))
check('D11','new_seed_count',2000,len(newset))
check('D11','collision_count',0,len(oldset&newset))
for rec in seeds['historical_manifests']:
    check('D11','historical_hash.'+pathlib.Path(rec['path']).name,rec['sha256'],hashlib.sha256(pathlib.Path(rec['path']).read_bytes()).hexdigest())
# run gate rejects empty certification before any generation subprocess
with tempfile.TemporaryDirectory(prefix='ps-gate-') as td:
    calls=[]; orig=x.subprocess.run
    def trap(*a,**kw):calls.append(a);raise AssertionError('generator invoked')
    x.subprocess.run=trap
    try:
      try:x.execute(pathlib.Path(td),cfg,review,freeze);outcome='NO_EXCEPTION'
      except Exception as e:outcome=type(e).__name__
    finally:x.subprocess.run=orig
    check('D11','unfrozen_run_rejected','FileNotFoundError',outcome)
    check('D11','unfrozen_generator_calls',0,len(calls))
# D12 source-level flow invariants and seed schedule before data.
source_run=ast.get_source_segment((ROOT/'measurement_experiment.py').read_text(),next(n for n in ast.parse((ROOT/'measurement_experiment.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='run_predictions'))
check('D12','truth_not_opened_in_predict',False,'_truth.csv' in source_run)
check('D12','evaluation_design_bulk_only',True,'if mode == "B" or not measured' in source_run or 'if mode == "B" or not measured' in (ROOT/'measurement_experiment.py').read_text())
check('D12','nested_budgets',[0,2,5],cfg['budgets'])
check('D12','cell4_paired_support',['soft','hard'],cfg['cells'][3]['support_groups'])
check('D12','stream_unique',2000,len(newset))
# D16 preservation: unchanged accepted parent files via Git tree and new-only paths.
commit=freeze['label_commit']; changed=subprocess.check_output(['git','diff','--name-only',cfg['accepted_parent'],commit],cwd=x.REPO,text=True).splitlines()
check('D16','label_changed_files',sorted(['research/emc-part2b/prior_guided/FINITE_CALIBRATION_RESULTS.md','research/emc-part2b/prior_guided/PRIOR_SENSITIVITY.md']),sorted(changed))
parent_of_label=subprocess.check_output(['git','rev-parse',commit+'^'],cwd=x.REPO,text=True).strip()
check('D16','label_direct_child',cfg['accepted_parent'],parent_of_label)
parent_paths=subprocess.check_output(['git','diff','--name-only',cfg['accepted_parent'],'HEAD'],cwd=x.REPO,text=True).splitlines()
check('D16','all_diff_scoped',True,all(t.startswith('research/emc-part2b/phase_sensitive/') or t in changed for t in parent_paths))
check('D16','source_excludes_old_parent_import',True,'no import' in source['parent_reference']['use'])
check('D16','review_before_now',True,review['reviewed_utc']<=x.utc())
check('D16','parent_hash',source['parent_reference']['sha256'],x.digest(parent_path))
for name in ['phase_models.py','measurement_experiment.py','test_phase_models.py','test_experiment.py']:
    ast.parse((ROOT/name).read_text());check('D16','AST.'+name,'parse_ok','parse_ok')
# D11 independent negative review fixture matrix in an audit-owned temporary tree.
with tempfile.TemporaryDirectory(prefix='ps-review-') as td:
    tmp=pathlib.Path(td)
    for file in list(freeze['design_files'])+['design_freeze.json','PREEXECUTION_REVIEW.json','PREEXECUTION_REVIEW.md']:
        (tmp/file).write_bytes((ROOT/file).read_bytes())
    original_here=x.HERE;x.HERE=tmp
    try:
        config=tmp/'preregistration.json'; review_file=tmp/'PREEXECUTION_REVIEW.json'
        cases=[('STOP',{'verdict':'STOP'}),('PASS_WITH_NOTE',{'verdict':'PASS WITH NOTE'}),('self_review',{'reviewer':'scriber'}),('future',{'reviewed_utc':'2999-01-01T00:00:00+00:00'}),('stale_design',{'design_digest':'0'*64}),('stale_prereg',{'preregistration_sha256':'0'*64}),('missing_review_md',{'review_markdown_sha256':'0'*64})]
        for label,changes in cases:
            raw=json.loads((ROOT/'PREEXECUTION_REVIEW.json').read_text());raw.update(changes);review_file.write_text(json.dumps(raw))
            try:x.design_gate(config,review_file);result='ACCEPTED'
            except Exception as e:result=type(e).__name__
            check('D11','review_reject_'+label,'RuntimeError',result)
        review_file.write_bytes((ROOT/'PREEXECUTION_REVIEW.json').read_bytes())
        for filename in ['preregistration.json','MATHEMATICAL_DESIGN.md']:
            target=tmp/filename;old=target.read_bytes();target.write_bytes(old+b'\n')
            try:x.design_gate(config,review_file);result='ACCEPTED'
            except Exception as e:result=type(e).__name__
            check('D11','design_byte_reject_'+filename,'RuntimeError',result)
            target.write_bytes(old)
        check('D11','restored_review_accept','qar-phase-prereg-v1',x.design_gate(config,review_file)[0]['schema'])
    finally:x.HERE=original_here
orig_hist=x.historical_seeds
try:
    x.historical_seeds=lambda:([],{731900000+100000+100+1})
    try:x.seed_manifest();result='ACCEPTED'
    except Exception as e:result=type(e).__name__
    check('D11','seed_collision_reject','RuntimeError',result)
finally:x.historical_seeds=orig_hist
# Environment/version/source mutation frozen comparison is exercised after freeze; here validate bounds and policy.
check('D11','wall_cap_minutes',90,cfg['bounds']['run_wall_minutes'])
check('D11','output_cap_MB',500,cfg['bounds']['generated_output_MB'])
check('D11','cpu_workers',2,cfg['bounds']['cpu_workers'])
check('D11','actual_threads',True,all(os.environ.get(v)=='1' for v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')))
check('D11','original_data_csv_absent',True,not any((ROOT/'run'/'data').glob('*.csv')))
check('D11','run_results_absent',False,(ROOT/'run'/'results').exists())
# D12 deterministic sentinel changes truth independently from fit observations.
source=(ROOT/'measurement_experiment.py').read_text()
truth_reads=[n.name for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and '_truth.csv' in ast.get_source_segment(source,n)]
check('D12','truth_read_functions',['score','study_diagnostics'],truth_reads)
check('D12','whole_unit_exclusion_branch',True,'exclude = x["sample_id"] if stratum == "measured" else None' in source)
check('D12','N_zero_update_branch',True,'if update == "N":' in source)
check('D12','evaluation_only_bulk_branch',True,'("B",) if stratum == "unmeasured"' in source)
check('D12','selection_fixed_prefix',True,'cohort["pool"][:k]' in source)
check('D12','no_pool_unpurchased_scoring',True,'("measured", cohort["pool"][:k])' in source)
check('D12','predictions_hash_before_truth',True,source.index('prediction_hash = digest(output / "results" / "predictions.csv")')<source.index('counts.update(score(output, deadline))'))
check('D12','run_uses_distinct_observed_files',4,len({f'{k}_observed.csv' for k in ('calibration','direct','pool','evaluation')}))
(OUT/'tester_preflight_results.json').write_text(json.dumps(rows,indent=2,allow_nan=False,default=lambda v:v.item() if isinstance(v,np.generic) else str(v))+'\n')
failed=[r for r in rows if r['verdict']=='FAIL']
print(json.dumps({'n':len(rows),'passed':len(rows)-len(failed),'failed':failed},indent=2,allow_nan=False,default=lambda v:v.item() if isinstance(v,np.generic) else str(v)))
sys.exit(bool(failed))
