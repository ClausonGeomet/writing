import copy, json, math, pathlib, sys, traceback
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
import phase_models as m
import measurement_experiment as ex
U=np.array([[2/np.sqrt(6),0],[-1/np.sqrt(6),1/np.sqrt(2)],[-1/np.sqrt(6),-1/np.sqrt(2)]])
C=np.array([[1.,0,0],[0,1,1]])
mu=np.array([.6,.1,.3]); R=np.eye(3)*.0004
Y=mu+np.array([[.06,0],[-.06,0],[0,.09],[0,-.09]])@U.T
records=[]
def add(cid,name,expected,actual,tol='exact'):
    if isinstance(expected,(list,tuple,np.ndarray)):
        a=np.asarray(actual,dtype=float); e=np.asarray(expected,dtype=float)
        err=float(np.max(np.abs(a-e))) if a.shape==e.shape else float('inf')
        ok=err<=float(tol)
        actual={'value':np.asarray(actual).tolist(),'max_abs_error':err}
    elif isinstance(expected,(int,float)) and not isinstance(expected,bool) and isinstance(actual,(int,float)):
        err=abs(actual-expected); ok=err<=float(tol) if tol!='exact' else actual==expected
        actual={'value':actual,'abs_error':err}
    else: ok=actual==expected
    records.append(dict(check_id=cid,metric=name,expected=np.asarray(expected).tolist() if isinstance(expected,np.ndarray) else expected,actual=actual,tolerance=tol,verdict='PASS' if ok else 'FAIL'))
    return ok
def bad(cid,name,fn):
    try: fn(); outcome='NO_EXCEPTION'
    except Exception as e: outcome=type(e).__name__
    add(cid,name,'ValueError',outcome)

def prior(center=mu,T=None,M=None):
    T=np.eye(2)*.01 if T is None else np.asarray(T)
    M=np.eye(2)*.001 if M is None else np.asarray(M)
    p=m.fit_initial(Y,R)
    p['center']=list(center);p['tangent_cov']=T.tolist();p['mean_cov']=M.tolist()
    p['precision']=(U@np.linalg.inv(T+M)@U.T).tolist()
    p['diagnostics']['mean_information']=np.linalg.inv(M).tolist()
    p['diagnostics']['mean_score']=(np.linalg.inv(M)@U.T@(center-np.ones(3)/3)).tolist()
    return p
# D01: invalids independently supplied to each applicable API.
for name,v in [('ragged',[[1,2],[3]]),('nan',np.array(Y)*np.nan),('posinf',np.array(Y)+np.inf),('neginf',np.array(Y)-np.inf),('string',[['x']*3]*4),('bool',[[True]*3]*4),('complex',np.array(Y,dtype=complex)+1j),('wrongshape',np.zeros((4,2))),('n0',np.zeros((0,3))),('n1',np.zeros((1,3)))]:
    bad('D01','fit_initial.Y.'+name,lambda v=v:m.fit_initial(v,R))
for name,v in [('singular',np.zeros((3,3))),('negative',np.diag([1,1,-1])),('asymmetric',np.array([[1,1e-5,0],[0,1,0],[0,0,1]])),('nan',np.full((3,3),np.nan)),('complex',np.eye(3,dtype=complex)*1j)]:
    bad('D01','fit_initial.R.'+name,lambda v=v:m.fit_initial(Y,v))
for name,kw in [('floorzero',{'variance_floor':0}),('floornegative',{'variance_floor':-1}),('shrinknegative',{'shrinkage':-.01}),('shrinkhigh',{'shrinkage':1.01}),('supportnone',{'center_support':(False,False,False)}),('supportbad',{'center_support':(1,1,1)}),('supportshort',{'center_support':(True,True)})]:
    bad('D01','fit_initial.'+name,lambda kw=kw:m.fit_initial(Y,R,**kw))
p=m.fit_initial(Y,R)
for api,fn in [('estimate',lambda y,D,cov,**kw:m.estimate(y,D,cov,method='A0',**kw)),('bounds',lambda y,D,cov,**kw:m.abundance_bounds(y,D,cov,**kw))]:
    for name,v in [('nan',np.array([np.nan,.4])),('posinf',np.array([np.inf,.4])),('neginf',np.array([-np.inf,.4])),('string',['x','.4']),('bool',[True,False]),('complex',[.6+1j,.4]),('wrongshape',[.6]),('ragged',[[.6],[.4]])]:
        bad('D01',api+'.y.'+name,lambda v=v,fn=fn:fn(v,C,np.eye(2)))
    for name,v in [('singular',np.zeros((2,2))),('negative',np.diag([1,-1])),('asymmetric',[[1,.1],[0,1]]),('nan',np.full((2,2),np.nan))]:
        bad('D01',api+'.cov.'+name,lambda v=v,fn=fn:fn([.6,.4],C,v))
    for name,v in [('ragged',[[1,0,0],[0,1]]),('nan',np.full((2,3),np.nan)),('string',[['x']*3]*2),('bool',[[True]*3]*2),('complex',C+1j),('wrongshape',np.zeros((2,2)))]:
        bad('D01',api+'.D.'+name,lambda v=v,fn=fn:fn([.6,.4],v,np.eye(2)))
    for name,v in [('allfalse',(False,False,False)),('nonbool',(1,1,1)),('short',(True,False))]:
        bad('D01',api+'.support.'+name,lambda v=v,fn=fn:fn([.6,.4],C,np.eye(2),support=v))
    for name,v in [('low',-.1),('high',1.1),('conflict',.6)]:
        sup=(False,True,True) if name=='conflict' else (True,True,True)
        bad('D01',api+'.fixedQ.'+name,lambda v=v,sup=sup,fn=fn:fn([.6,.4],C,np.eye(2),support=sup,fixed_quartz=v))
for name,fn in [('unknownmethod',lambda:m.estimate([.6,.4],C,np.eye(2),method='X')),('A0prior',lambda:m.estimate([.6,.4],C,np.eye(2),p,method='A0')),('A1data',lambda:m.estimate([.6,.4],C,np.eye(2),p,method='A1')),('A2noprior',lambda:m.estimate([.6,.4],C,np.eye(2),method='A2')),('negstrength',lambda:m.estimate([.6,.4],C,np.eye(2),p,method='A2',strength=-1)),('nanstrength',lambda:m.estimate([.6,.4],C,np.eye(2),p,method='A2',strength=float('nan'))),('badprior',lambda:m.estimate([.6,.4],C,np.eye(2),{'status':'ok'},method='A2')),('duplicateunits',lambda:m.update_mean(p,[{'unit_id':'x'},{'unit_id':'x'}])),('unknownexclude',lambda:m.update_mean(p,[],exclude_unit='x'))]:bad('D01',name,fn)
add('D01','signed.estimate.status','ok',m.estimate([-.2,.4],C,np.eye(2),method='A0')['status'])
add('D01','signed.bounds.status',True,m.abundance_bounds([-.2,.4],C,np.eye(2))['status'] in ('ok','infeasible_envelope'))
# D02
for name,fn,inputs in [('fit',lambda:m.fit_initial(Y,R),[Y,R]),('update',lambda:m.update_mean(p,[{'unit_id':'x','D':C,'y':np.array([.6,.4]),'cov':np.eye(2)}]),[p,C]),('estimate',lambda:m.estimate(np.array([.6,.4]),C,np.eye(2),p,method='A2'),[p,C]),('information',lambda:m.information(C,np.eye(2)),[C]),('bounds',lambda:m.abundance_bounds(np.array([.6,.4]),C,np.eye(2)),[C])]:
    before=[copy.deepcopy(x) for x in inputs]; a=fn(); b=fn()
    add('D02',name+'.repeat',json.dumps(a,sort_keys=True),json.dumps(b,sort_keys=True))
    add('D02',name+'.immutable',True,all(np.array_equal(x,y) if isinstance(x,np.ndarray) else x==y for x,y in zip(inputs,before)))
# D03
S=np.diag([2*.06**2/3,2*.09**2/3]); G=S-.0004*np.eye(2); T=.75*G+.25*np.trace(G)*np.eye(2)/2; M=(T+.0004*np.eye(2))/4
add('D03','raw_cov',S,p['diagnostics']['raw_tangent_cov'],1e-12)
add('D03','intrinsic_T',T,p['tangent_cov'],1e-12)
add('D03','mean_M',M,p['mean_cov'],1e-12)
add('D03','precision_K',U@np.linalg.inv(T+M)@U.T,p['precision'],1e-12)
add('D03','center',mu,p['center'],1e-12)
ph=m.fit_initial(Y,R,center_support=(True,False,True))
add('D03','hard_center',[.65,0,.35],ph['center'],1e-12)
add('D03','hard_T_same',p['tangent_cov'],ph['tangent_cov'],1e-12)
ident=m.fit_initial(np.tile(mu,(4,1)),R)
add('D03','floor_identical',[.0001,.0001],ident['diagnostics']['floored_eigenvalues'],1e-12)
# rotated anisotropic covariance explicit scalar spectral polynomial
rot=np.array([[.8,-.6],[.6,.8]]); Rz=np.array([[.0004,.0001],[.0001,.0005]])
Rcal=U@Rz@U.T+.0002*np.ones((3,3))/3
Yrot=mu+np.array([[.06,0],[-.06,0],[0,.09],[0,-.09]])@rot.T@U.T
pr=m.fit_initial(Yrot,Rcal)
Srot=rot@S@rot.T; Grot=Srot-Rz
tr=np.trace(Grot); disc=math.sqrt((Grot[0,0]-Grot[1,1])**2+4*Grot[0,1]**2)
vals=np.maximum([(tr-disc)/2,(tr+disc)/2],.0001)
# 2x2 spectral polynomial for floor, no fit function oracle
lo,hi=(tr-disc)/2,(tr+disc)/2
Gf=vals[0]*np.eye(2)+(vals[1]-vals[0])*(Grot-lo*np.eye(2))/(hi-lo)
Trot=.75*Gf+.25*np.trace(Gf)*np.eye(2)/2; Mrot=(Trot+Rz)/4
add('D03','rotated_eigenvalues',vals,pr['diagnostics']['floored_eigenvalues'],1e-12)
add('D03','rotated_T',Trot,pr['tangent_cov'],1e-12)
add('D03','rotated_M',Mrot,pr['mean_cov'],1e-12)
# D04
for name,D,y,target in [('bulk',C,[.6,.4],[.6,.2,.2]),('phase',np.vstack((C,[0,1,0])),[.6,.4,.1],[.6,.1,.3]),('redundant',np.vstack((C,[0,1,1])),[.6,.4,.4],[.6,.2,.2])]:
    e=m.estimate(y,D,np.eye(len(y)),method='A0');add('D04',name+'.mass',target,e['mass'],1e-8);add('D05',name+'.kkt_bound',True,e['kkt_residual']<=1e-8)
add('D04','lambda0_equals_A0',m.estimate([.62,.39],C,np.eye(2),method='A0')['mass'],m.estimate([.62,.39],C,np.eye(2),p,method='A2',strength=0)['mass'],1e-8)
# Fixed-Q exact minimum-norm tie on rank-deficient bulk.
fixed=m.estimate([.62,.39],C,np.array([[.0001,.00003],[.00003,.0001]]),method='A0',fixed_quartz=.6)
add('D04','fixedQ_bulk_min_norm',[.6,.2,.2],fixed['mass'],1e-8)
fixed0=m.estimate([.62,.39],C,np.array([[.0001,.00003],[.00003,.0001]]),p,method='A2',strength=0,fixed_quartz=.6)
add('D04','fixedQ_lambda0_min_norm',[.6,.2,.2],fixed0['mass'],1e-8)
# D06
p0=prior(); y=mu+U@np.array([.01,-.02]); unit={'unit_id':'x','D':np.eye(3),'y':y,'cov':R}
pu=m.update_mean(p0,[unit]); mm=1/(1000+1/.0104); center=mu+U@(mm/.0104*np.array([.01,-.02]))
add('D06','oneunit_center',center,pu['center'],1e-12);add('D06','oneunit_M',np.eye(2)*mm,pu['mean_cov'],1e-12)
add('D06','empty_center',p0['center'],m.update_mean(p0,[])['center'],1e-12)
unit2={'unit_id':'z','D':np.eye(3),'y':mu+U@np.array([-.02,.01]),'cov':R}
loo=m.update_mean(p0,[unit,unit2],exclude_unit='x'); one=m.update_mean(p0,[unit2]); add('D06','wholeunit_LOO_center',one['center'],loo['center'],1e-12)
unit_changed=dict(unit,y=np.array([-100.,100.,0.]),D=C,cov=np.eye(2)); loo2=m.update_mean(p0,[unit_changed,unit2],exclude_unit='x')
add('D06','excluded_changes_no_effect',loo['center'],loo2['center'],1e-12)
# D07
softp=prior(np.array([.65,0,.35])); D=np.vstack((C,[0,1,0])); yy=np.array([.6,.4,.2]); RR=np.diag([.0001,.0001,.000001])
soft=m.estimate(yy,D,RR,softp,method='A2');hard=m.estimate(yy,D,RR,softp,method='A2',support=(True,False,True))
add('D07','soft_A_gt_.1',True,soft['mass'][1]>.1);add('D07','hard_A_zero',0,hard['mass'][1],1e-9)
add('D07','soft_hard_T_equal',softp['tangent_cov'],softp['tangent_cov'],1e-12)
# D08
for name,DD,rr in [('C',C,(2,2,1)),('Ct',np.vstack((C,[0,1,1])),(2,2,1)),('Ch',D,(3,3,2))]:
    info=m.information(DD,np.eye(len(DD)))
    add('D08',name+'.ranks',rr,[info['rank_raw'],info['rank_augmented'],info['rank_tangent']],0)
add('D08','hard_C_rank',1,m.information(C,np.eye(2),support=(True,False,True))['rank_support_tangent'])
perm=[1,0]; a=m.estimate([.62,.39],C,np.array([[.0001,.00003],[.00003,.0001]]),p,method='A2');b=m.estimate(np.array([.62,.39])[perm],C[perm],np.array([[.0001,.00003],[.00003,.0001]])[np.ix_(perm,perm)],p,method='A2')
add('D08','joint_permutation_mass',a['mass'],b['mass'],1e-8);add('D08','joint_permutation_objective',a['objective'],b['objective'],1e-12)
# D09
b0=m.abundance_bounds([.6,.4],C,np.eye(2),multiplier=1e-12)
add('D09','bulk_bounds_lo',[.6,0,0],b0['lower'],1e-8);add('D09','bulk_bounds_hi',[.6,.4,.4],b0['upper'],1e-8)
bh=m.abundance_bounds([.6,.4,.1],D,np.eye(3),multiplier=1e-12)
add('D09','phase_singleton',[.6,.1,.3],bh['lower'],1e-8)
bi=m.abundance_bounds([.6,.4,.9],D,np.eye(3),multiplier=1e-12)
add('D09','incompatible_status','infeasible_envelope',bi['status']);add('D09','incompatible_null',None,bi['lower'])
# D11 current pre-run certification must reject D13-D15 pending (lifecycle defect)
ids={f'D{i:02d}' for i in range(1,17)}
add('D11','pre_run_required_ids',','.join(sorted({f'D{i:02d}' for i in list(range(1,13))+[16]})),','.join(sorted(ids-{f'D13',f'D14',f'D15'})))
# D16
import ast
for name in ['phase_models.py','measurement_experiment.py','test_phase_models.py','test_experiment.py']:
    try:ast.parse((ROOT/name).read_text());out='parse_ok'
    except Exception as e:out=type(e).__name__
    add('D16','AST.'+name,'parse_ok',out)
path=pathlib.Path(__file__).with_name('tester_oracle_results.json');path.write_text(json.dumps(records,indent=2,allow_nan=False)+'\n')
failed=[r for r in records if r['verdict']=='FAIL']
print(json.dumps({'n':len(records),'passed':len(records)-len(failed),'failed':failed},indent=2,allow_nan=False))
