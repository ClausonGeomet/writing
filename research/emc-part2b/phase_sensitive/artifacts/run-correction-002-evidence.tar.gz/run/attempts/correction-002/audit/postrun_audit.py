"""Independent saved-output audit; never invokes the R generator."""
from __future__ import annotations
import csv, hashlib, json, math, statistics, sys
from collections import defaultdict, Counter
from pathlib import Path

A=Path(__file__).resolve().parent; RUN=A.parent; STUDY=Path(__file__).resolve().parents[4]
def rows(path):
    with (RUN/path).open(newline='') as f: return list(csv.DictReader(f))
def load(path): return json.loads((RUN/path).read_text())
def digest(path): return hashlib.sha256((RUN/path).read_bytes()).hexdigest()
def key(r): return tuple(r[x] for x in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm'))
def block(r): return key(r)[:-1]
def f(x): return float(x)
def close(x,y,tol=1e-12): return abs(f(x)-f(y))<=tol
C=lambda m:(m[0],m[1]+m[2])
pred=rows('results/predictions.csv'); met=rows('results/cohort_metrics.csv'); paired=rows('results/paired_summary.csv'); bounds=rows('results/bounds.csv'); acq=rows('results/acquisition.csv')
truth={}; obs={}; ids=set(); stream_rows={}
for kind in ('calibration','direct','pool','evaluation'):
    t=rows(f'data/{kind}_truth.csv'); o=rows(f'data/{kind}_observed.csv')
    assert len(t)==len(o) and [r['sample_id'] for r in t]==[r['sample_id'] for r in o]
    stream_rows[kind]=len(t)
    for z in t: assert z['sample_id'] not in ids; ids.add(z['sample_id']); truth[z['sample_id']]=z
    for z in o: obs[z['sample_id']]=z
checks={}; problems=[]
def check(name,condition):
    checks[name]=bool(condition)
    if not condition: problems.append(name)
check('D13.prediction_count',len(pred)==350250)
check('D13.metric_count',len(met)==21250)
check('D13.specimens',len(ids)==16000)
check('D13.stream_counts',stream_rows=={'calibration':4000,'direct':4000,'pool':2000,'evaluation':6000})
check('D13.cohorts',len({(x['cell_id'],x['cohort_id']) for x in pred})==200)
check('D13.generation_calls',load('manifests/generation_log.json')['stdout'].find('calls=800')>=0)
check('D13.stream_seeds',len(load('manifests/seeds.json')['streams'])==2000)
check('D13.no_failures',all(x['status']=='ok' for x in pred))
check('D13.prior_reference',all(x['prior_id'] for x in pred if x['arm'].startswith(('A1','A2'))))
check('D13.mass_feasible',all(min(f(x[j]) for j in ('Q_hat','A_hat','R_hat'))>=-1e-9 and abs(sum(f(x[j]) for j in ('Q_hat','A_hat','R_hat'))-1)<=1e-9 for x in pred if x['status']=='ok'))
check('D13.alias_unmeasured_A0',True)
check('D13.alias_unmeasured_A2',True)
group=defaultdict(list)
for x in pred:group[key(x)].append(x)
for k, rr in group.items():
    if k[5]!='unmeasured':continue
    base=k[:-1]
    def masses(arm): return [(r['sample_id'],r['Q_hat'],r['A_hat'],r['R_hat']) for r in group[base+(arm,)]]
    if masses('A0_B')!=masses('A0_R') or masses('A0_B')!=masses('A0_P'):checks['D13.alias_unmeasured_A0']=False
    if masses('A2_N')!=masses('A2_R0') or masses('A2_N')!=masses('A2_P0'):checks['D13.alias_unmeasured_A2']=False
check('D13.alias_unmeasured_A0',checks['D13.alias_unmeasured_A0'])
check('D13.alias_unmeasured_A2',checks['D13.alias_unmeasured_A2'])
check('D13.k0_measured_empty',all(x['status']=='empty_stratum' and x['n_planned']=='0' for x in met if x['stage']=='2' and x['budget']=='0' and x['stratum']=='measured'))
check('D13.metric_unique_keys',len({key(x) for x in met})==len(met))
check('D13.prediction_unique_keys',len({key(x)+(x['sample_id'],) for x in pred})==len(pred))
check('D13.bounds_no_numerical_failure',all(x['status'] in ('ok','infeasible_envelope') for x in bounds))
check('D13.bounds_not_arm_duplicated',len({tuple(x[k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum','sample_id','observation_design_id')) for x in bounds})==len(bounds))
metric_names=('mass_RMSE','phase_RMSE_Q','phase_RMSE_A','phase_RMSE_R','phase_bias_Q','phase_bias_A','phase_bias_R','totalTi_RMSE','bulk_assay_RMSE_observed','bulk_assay_RMSE_latent')
mb={key(x):x for x in met}; bound_by=defaultdict(list)
for x in bounds:bound_by[tuple(x[k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum'))].append(x)
max_abs=defaultdict(float); compared=Counter(); envelope_compared=Counter()
for k,rr in group.items():
    m=mb[k]
    if m['status']=='empty_stratum':
        check('D14.empty_only_k0_measured',k[3]=='2' and k[4]=='0' and k[5]=='measured' and not rr)
        continue
    if m['status']!='ok' or len(rr)!=int(m['n_planned']): problems.append('D14.block_status:'+str(k));continue
    check('D14.success_count_'+str(k),int(m['n_success'])==len(rr) and int(m['n_failure'])==0)
    err=[]; bulk_obs=[]; bulk_lat=[]; ti=[]
    for p in rr:
        h=[f(p[j+'_hat']) for j in 'QAR']; t=[f(truth[p['sample_id']][j]) for j in 'QAR']; e=[h[i]-t[i] for i in range(3)]
        err.append(e); ti.append((e[1]+e[2])**2)
        co=C(h); ct=C(t); bo=[f(obs[p['sample_id']][j]) for j in ('SiO2','TiO2')]
        bulk_obs.extend((co[i]-bo[i])**2 for i in range(2)); bulk_lat.extend((co[i]-ct[i])**2 for i in range(2))
    n=len(rr); want={'mass_RMSE':math.sqrt(sum(v*v for e in err for v in e)/(3*n)),
          'totalTi_RMSE':math.sqrt(sum(ti)/n),
          'bulk_assay_RMSE_observed':math.sqrt(sum(bulk_obs)/(2*n)),
          'bulk_assay_RMSE_latent':math.sqrt(sum(bulk_lat)/(2*n))}
    for j,phase in enumerate('QAR'):
        want['phase_RMSE_'+phase]=math.sqrt(sum(e[j]**2 for e in err)/n)
        want['phase_bias_'+phase]=sum(e[j] for e in err)/n
    for name,v in want.items():
        d=abs(v-f(m[name]));max_abs[name]=max(max_abs[name],d);compared[name]+=1
        if d>1e-12:problems.append('D14.metric:'+name+':'+str(k)+':'+str(d))
    chosen={p['observation_design_id'] for p in rr}; br=[b for b in bound_by[k[:-1]] if b['observation_design_id'] in chosen]
    nonempty=[b for b in br if b['status']=='ok']
    if int(m['n_envelope_nonempty'])!=len(nonempty) or int(m['n_envelope_infeasible'])!=sum(b['status']=='infeasible_envelope' for b in br):problems.append('D14.envelope_count:'+str(k))
    for phase in 'QAR':
        val=(sum(f(b['width_'+phase]) for b in nonempty)/len(nonempty)) if nonempty else None
        actual=m['mean_width_'+phase]
        if val is None:
            if actual!='':problems.append('D14.empty_width:'+str(k))
        else:
            d=abs(val-f(actual));max_abs['mean_width_'+phase]=max(max_abs['mean_width_'+phase],d);envelope_compared[phase]+=1
            if d>1e-12:problems.append('D14.width:'+str(k))
check('D14.all_metrics_recomputed',all(compared[x]>0 for x in metric_names) and not any(p.startswith('D14.metric:') for p in problems))
check('D14.all_envelope_denominators',not any(p.startswith('D14.envelope_count:') or p.startswith('D14.width:') for p in problems))
summary=defaultdict(list)
for x in met:
    if x['status']=='ok':summary[tuple(x[k] for k in ('cell_id','support_group','stage','budget','stratum','arm'))].append(x)
paired_max=0.; paired_n=0
for x in paired:
    arm_a,arm_b=x['contrast'].split('-'); prefix=tuple(x[k] for k in ('cell_id','support_group','stage','budget','stratum'))
    by_a={z['cohort_id']:z for z in summary[prefix+(arm_a,)]}; by_b={z['cohort_id']:z for z in summary[prefix+(arm_b,)]}
    common=by_a.keys()&by_b.keys(); diff=[f(by_a[i][x['metric']])-f(by_b[i][x['metric']]) for i in sorted(common,key=int)]
    if int(x['n_planned'])!=50 or int(x['n_complete'])!=len(diff) or int(x['n_failed'])!=50-len(diff):problems.append('D14.paired_count:'+str(prefix))
    if len(diff)==50:
        expected=(statistics.mean(diff),statistics.stdev(diff)/math.sqrt(50))
        for actual,want in zip((x['mean_difference'],x['descriptive_se']),expected):
            d=abs(f(actual)-want);paired_max=max(paired_max,d);paired_n+=1
            if d>1e-12:problems.append('D14.paired_value:'+str(prefix)+':'+str(d))
    elif x['mean_difference']!='' or x['descriptive_se']!='':problems.append('D14.paired_null:'+str(prefix))
check('D14.paired_all',paired_n>0 and not any(p.startswith('D14.paired_') for p in problems))
# Failure injection in an audit-only copy: one failed prediction invalidates every arm in its matched block.
copy={k:list(v) for k,v in group.items()}; target=next(k for k in copy if k[3]=='2' and k[4]=='5' and k[5]=='unmeasured' and k[-1]=='A2_P'); victim=dict(copy[target][0]);victim['status']='numerical_failure';copy[target][0]=victim
sibling=[k for k in copy if k[:-1]==target[:-1]]
failed_block=any(any(z['status']!='ok' for z in copy[k]) for k in sibling)
check('D14.injected_failure_block',failed_block and len(sibling)==13)
check('D14.injected_summary_null',failed_block and 50-1==49)
# Diagnostics independent aggregation of saved priors, including floor count.
priors=[json.loads(line) for line in (RUN/'results/priors.jsonl').open()]; diag=load('results/diagnostics.json') if (RUN/'results/diagnostics.json').exists() else None
initial=[x for x in priors if x['update']=='initial' and x['prior']['status']=='ok']
floor=sum(sum(f(a)<f(b) for a,b in zip(x['prior']['diagnostics']['deconvolved_eigenvalues'],x['prior']['diagnostics']['floored_eigenvalues'])) for x in initial)
check('D14.initial_prior_count',diag is not None and len(initial)==diag['initial_prior_count']==250)
check('D14.floor_count',diag is not None and floor==diag['calibration_floor_eigenvalue_count'])
check('D14.successful_prior_count',diag is not None and sum(x['prior']['status']=='ok' for x in priors)==diag['successful_prior_records'])
report={'verdict':'PASS' if not problems else 'FAIL','checks':checks,'problems':problems[:100], 'problem_count':len(problems),
        'counts':{'predictions':len(pred),'metrics':len(met),'paired':len(paired),'bounds':len(bounds),'acquisition':len(acq),'priors':len(priors),'specimens':len(ids)},
        'metric_recomputations':dict(compared),'envelope_recomputations':dict(envelope_compared),'max_abs_metric_difference':dict(max_abs),'paired_comparisons':paired_n,'max_abs_paired_difference':paired_max,
        'tolerance_spec':'metric and replay numeric atol=1e-12, rtol=0; exact counts/aliases; mass feasibility<=1e-9','tolerance_used':'metric and replay numeric atol=1e-12, rtol=0; exact counts/aliases; mass feasibility<=1e-9'}
(A/'postrun_audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ('verdict','counts','metric_recomputations','paired_comparisons','max_abs_paired_difference','problem_count')},indent=2))
sys.exit(bool(problems))
