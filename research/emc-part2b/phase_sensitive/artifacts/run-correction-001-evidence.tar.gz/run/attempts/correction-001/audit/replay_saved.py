"""Replay saved observations through fitting and scoring, with no R or RNG call."""
from __future__ import annotations
import hashlib,json,shutil,sys,time
from pathlib import Path
A=Path(__file__).resolve().parent; RUN=A.parent; STUDY=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(STUDY))
import measurement_experiment as m
out=A/'replay'; data=out/'data'; data.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original={}
for name in ('calibration','direct','pool','evaluation'):
    src=RUN/'data'/f'{name}_observed.csv'; original[src.name]=sha(src)
    shutil.copyfile(src,data/src.name)
cfg=json.loads((STUDY/'preregistration.json').read_text())
counts=m.run_predictions(out,cfg,time.monotonic()+5400)
pred_hash=sha(out/'results/predictions.csv')
# Truth is copied only after the replay predictions have closed and been hashed.
for name in ('direct','pool','evaluation'):
    src=RUN/'data'/f'{name}_truth.csv';shutil.copyfile(src,data/src.name)
counts.update(m.score(out,time.monotonic()+5400))
files=('predictions.csv','bounds.csv','priors.jsonl','information.jsonl','cohort_metrics.csv','paired_summary.csv')
hashes={name:{'original':sha(RUN/'results'/name),'replay':sha(out/'results'/name)} for name in files}
checks={name:entry['original']==entry['replay'] for name,entry in hashes.items()}
checks['input_observations_unchanged']=all(sha(RUN/'data'/name)==h for name,h in original.items())
checks['prediction_count']=counts['predictions']==350250
checks['metric_count']=counts['cohort_metrics']==21250
report={'verdict':'PASS' if all(checks.values()) else 'FAIL','method':'replay only saved observed CSVs; no R generator, no fresh random draws; truth copied after prediction hash','counts':counts,'prediction_sha256_before_truth_copy':pred_hash,'hashes':hashes,'checks':checks,'tolerance_spec':'numeric atol=1e-12, rtol=0','tolerance_used':'byte exact for identical saved inputs (stronger than numeric atol=1e-12, rtol=0)'}
(A/'replay_saved.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'verdict':report['verdict'],'counts':counts,'checks':checks},indent=2))
sys.exit(not all(checks.values()))
