"""Independently recalculate prior and observation diagnostics from saved records."""
import csv,json,math,sys
from collections import defaultdict
from pathlib import Path
import numpy as np
A=Path(__file__).resolve().parent; R=A.parent
def table(p):
 with (R/p).open(newline='') as h:return list(csv.DictReader(h))
prior=[json.loads(s) for s in (R/'results/priors.jsonl').open()]
d=json.loads((R/'results/diagnostics.json').read_text())
U=np.array([[2/np.sqrt(6),0],[-1/np.sqrt(6),1/np.sqrt(2)],[-1/np.sqrt(6),-1/np.sqrt(2)]])
centers={};eig_t=[];eig_m=[];diag_t=[];diag_m=[];corr=[];floor=0;successful=0
for x in prior:
 p=x['prior']
 if p['status']!='ok':continue
 successful+=1
 if x['update']=='initial':
  centers[(x['cell_id'],x['cohort_id'],x['support_group'])]=np.array(p['center'],float)
  z=p['diagnostics'];floor+=sum(float(a)<float(b) for a,b in zip(z['deconvolved_eigenvalues'],z['floored_eigenvalues']))
 T=np.array(p['tangent_cov'],float);M=np.array(p['mean_cov'],float)
 eig_t.append(np.linalg.eigvalsh(T));eig_m.append(np.linalg.eigvalsh(M))
 pt=U@T@U.T;pm=U@M@U.T
 diag_t.append(np.diag(pt));diag_m.append(np.diag(pm));corr.append(pt[1,2]/math.sqrt(pt[1,1]*pt[2,2]))
calc={'initial_prior_count':len(centers),'successful_prior_records':successful,'calibration_floor_eigenvalue_count':floor,
 'mean_T_eigenvalues':np.mean(eig_t,axis=0).tolist(),'mean_M_eigenvalues':np.mean(eig_m,axis=0).tolist(),
 'mean_T_physical_diagonal':np.mean(diag_t,axis=0).tolist(),'mean_M_physical_diagonal':np.mean(diag_m,axis=0).tolist(),
 'mean_learned_A_R_correlation':float(np.mean(corr))}
for kind in ('calibration','direct','pool','evaluation'):
 t=table(f'data/{kind}_observed.csv');cols=[c for c in t[0] if c not in ('cell_id','cohort_id','sample_id')]
 calc.setdefault('negative_observations_by_stream',{})[kind]=sum(float(x[c])<0 for x in t for c in cols if x[c]!='')
by=defaultdict(list)
for (s,r,g),v in centers.items():by[f'{s}:{g}'].append(v)
calc['learned_center_sd_by_cell_support']={k:np.std(v,axis=0,ddof=1).tolist() for k,v in by.items()}
truth={kind:table(f'data/{kind}_truth.csv') for kind in ('calibration','evaluation')}
latent={}
for kind,rr in truth.items():
 groups=defaultdict(list)
 for x in rr:groups[(int(x['cell_id']),int(x['cohort_id']))].append([float(x[p]) for p in 'QAR'])
 latent[kind]={k:np.mean(v,axis=0) for k,v in groups.items()}
retro=[]
for (s,r,g),v in centers.items():
 for kind in ('calibration','evaluation'):
  retro.append({'cell_id':s,'cohort_id':r,'support_group':g,'population':kind,'center_minus_latent_mean':(v-latent[kind][(s,r)]).tolist()})
recorded={(x['cell_id'],x['cohort_id'],x['support_group'],x['population']):x['center_minus_latent_mean'] for x in d['retrospective_center_errors']}
max_diff=0.;bad=[]
for x in retro:
 k=(x['cell_id'],x['cohort_id'],x['support_group'],x['population'])
 if k not in recorded:bad.append('missing_retrospective:'+str(k));continue
 max_diff=max(max_diff,float(np.max(np.abs(np.array(x['center_minus_latent_mean'])-recorded[k]))))
for k,v in calc.items():
 z=d.get(k)
 if isinstance(v,dict):
  if set(v)!=set(z):bad.append(k+'.keys');continue
  for j,w in v.items():
   if np.max(np.abs(np.asarray(w)-np.asarray(z[j])))>1e-12:bad.append(k+'.'+j)
 elif isinstance(v,list):
  if np.max(np.abs(np.asarray(v)-np.asarray(z)))>1e-12:bad.append(k)
 elif isinstance(v,float):
  if abs(v-z)>1e-12:bad.append(k)
 elif v!=z:bad.append(k)
if max_diff>1e-12:bad.append('retrospective_center_errors')
report={'verdict':'PASS' if not bad else 'FAIL','comparisons':len(calc)+len(retro),'retrospective_rows':len(retro),'max_abs_retrospective_difference':max_diff,'calculated':calc,'failures':bad,'tolerance_spec':'atol=1e-12, rtol=0; counts exact','tolerance_used':'atol=1e-12, rtol=0; counts exact'}
(A/'diagnostic_audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'verdict':report['verdict'],'comparisons':report['comparisons'],'max_abs_retrospective_difference':max_diff,'failures':bad},indent=2))
sys.exit(bool(bad))
