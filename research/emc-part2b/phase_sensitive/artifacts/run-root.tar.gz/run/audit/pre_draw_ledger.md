# Independent pre-draw certificate

Exact oracle rows: 379; PASS: 379; FAIL: 0.

|Check|Executed oracle rows|Verdict|
|---|---:|---|
|D01|155|PASS|
|D02|28|PASS|
|D03|16|PASS|
|D04|13|PASS|
|D05|40|PASS|
|D06|12|PASS|
|D07|3|PASS|
|D08|10|PASS|
|D09|12|PASS|
|D10|24|PASS|
|D11|39|PASS|
|D12|13|PASS|
|D16|14|PASS|

Evidence files: `tester_oracle_results.json` and `tester_preflight_results.json`. All numeric comparisons use the exact tolerances recorded in each row; `test-spec.md` mandates mass atol=1e-8, matrix/objective atol=1e-12, feasibility<=1e-9, KKT<=1e-8, and rtol=0. No tolerance was widened.

D13-D15 require saved data and remain PENDING. This certificate precedes --freeze and the first draw.

## Subsequent gate failure

The initial named oracle ledger above was followed by the public `--freeze` attempt. It BLOCKED before data on `measurement_experiment.py::environment` parsing `generation.R` as Python (`SyntaxError: invalid decimal literal`, R line 4). Thus D11 is now FAIL and no overall pre-draw PASS is asserted. `--run` has not been invoked. The original passing oracle rows are retained as their actual, narrower evidence.
