# Simulator post-execution correction handoff — 2026-10-27

Verdict: **SOURCE READY FOR INDEPENDENT SAVED-RESULT VALIDATION**. No generation, R call, new truth, replayed stochastic cohort, or full saved-result verification was performed by the simulator. Existing scientific STOP remains pending independent tester and reviewer work.

## Additive files and entry point

- `research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py` — draw-free CLI `--input-attempt PATH --evidence-output FRESH_PATH --verify-saved`; injected `non_generating_boundary(output, callback, preflight=...)`; complete failed-block metadata-only mask; saved-input source/provenance, prior, estimate, information, LP, acquisition, metrics, pairing and diagnostics checks.
- `research/emc-part2b/phase_sensitive/test_experiment_corrected.py` — eight focused deterministic tests of resource gates, masking, independent KKT and path isolation.
- Commit `bf1b508` contains exactly these two additive files, with no trailers. SHA256: harness `bb3e993bdd22e93811b0ada715e2604d0ca98c1e56e086d0bd9abdfafedd7eac`; tests `ee62e70709f8c0db88c7544e1fa412a9655ad8563794a19a1c9402dfbd5270da`.

Historical five source hashes remain those in correction-002 `manifests/source.json`; their byte hashes in the worktree are `measurement_experiment.py` `9577c4799d5ff8fbb8bbd14098cac23cafe8567fab91521ec46f0320c092d222`, `generation.R` `16432637b16c4a72eb07ec340d08cc96910d2d3172285d503b18e96428066610`, `test_experiment.py` `f1fc233065121554fd0e0aef85adb90dc036a03c40ae1cec43c304f8fe528e2e`, `phase_models.py` `2910f0f43c7effb392a8d71edf64c87e4b314712774b076738b127d324ead2e1`, `test_phase_models.py` `44d4bf7bb0057707ac58f8d8c6ddd4a5323c26eb1627c9dc06b0a2f18f480b4b`. The separate new source record is generated under the requested evidence output and binds these historical files, the additive files, correction spec, original manifests and data/results hashes, current Python environment and historical environment hash. It does not rebind the old execution to the new source.

## Deterministic checks performed

- `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/bif-v3-world1-validation-env-20261023/bin/python -m unittest discover -s research/emc-part2b/phase_sensitive -p test_experiment_corrected.py -v`: **8 passed**.
- `.../bin/python -m py_compile research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py research/emc-part2b/phase_sensitive/test_experiment_corrected.py`: **PASS**.
- Read-only historical source/manifest/seed/archive inventory gate on the main correction-002 tree: **PASS**. The seed manifest's absolute path labels identify the main checkout; the worktree counterpart bytes and values match.
- Focused read-only cohort 1/1: all **31** prior records independently reconstructed from saved calibration/purchased observations; all **1,401** estimate rows independently checked against reconstructed inputs, candidate KKT/objective and public `estimate()` tie behavior. No truth opened in this check. This is a focused check, not the all-row certificate.
- The 116-file historical source index and six archive index remained unchanged (`2876fedc6ebc72a3c9f83874ab5f717f51c4259eea6d1824e03b93a9bd9973dd` and `1b9dc5d6d824cf5bf9dc7856bc763aa5d6cf67e9912247b8167aab3a6eddd32a`). `git status --short` was clean after the commit.

## Independent tester command

From this worktree or the merged checkout, with the saved main attempt available at its original absolute path, run with an unused evidence directory:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
/tmp/bif-v3-world1-validation-env-20261023/bin/python \
research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py \
  --input-attempt /home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive/run/attempts/correction-002 \
  --evidence-output /tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive/correction-evidence/tester-001 \
  --verify-saved
```

This full run should authenticate all immutable inputs and check 350,250 estimates, 7,750 priors, 42,750 bounds, 26,250 information records, 600 acquisition rows, 21,250 metrics and 3,050 paired rows. It writes a distinct post-execution `source.json`, `start.json`, `validation.json` and `evidence-hashes.json` outside `run/`, with explicit zero draws and retrospective-key-inventory deviation. Nonzero exit and `BLOCK`/`INCOMPLETE` evidence mean no clearance. The historical `--verify` remains a separate unchanged-source artifact check.

The tester must inspect any discrepancy and exercise its independent negative probes. This handoff makes no claim of tester PASS or final scientific clearance.
