# Focused draw-free tester follow-up — R1

**Verdict: BLOCK.** The correction-002 numerical run and its original PASS audit remain historical evidence, but the mandatory D05/D11/D14 follow-up checks expose three simulator-owned source defects. No study data were generated, no study source or frozen run file was changed, and no tolerance was widened. This report supersedes the canonical audit verdict for scientific clearance. The original audit is preserved byte-for-byte as `audit-correction002-initial-pass.md` (SHA256 `bce68367751068132dbdcb9ef7245f6303a45e7713e8b17e3efb48b10c7c7b40`). Final scientific review R1 remains STOP.

## Execution and environment

Working tree: `/home/matt/Documents/GitHub/writing`; final saved run: `research/emc-part2b/phase_sensitive/run/attempts/correction-002`; evidence: this run directory's `followup-evidence/`. Python: `/tmp/bif-v3-world1-validation-env-20261023/bin/python`, Python 3.12.3, NumPy/SciPy from the final frozen environment. Commands below used `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1`. They wrote only to `followup-evidence/` and this workflow run directory:

```text
python followup-evidence/probe.py
python followup-evidence/diagnostics_probe.py
python followup-evidence/gate_probe.py
python followup-evidence/dataflow_probe.py
python followup-evidence/certificate_probe.py
python followup-evidence/contrast_inventory.py
python followup-evidence/aliases.py
```

Each `python` above means the absolute frozen-environment executable stated above. `probe.py` calls production `measurement_experiment.score()` on a copied prediction table with one status changed. `dataflow_probe.py` calls production `run_predictions()` on saved observations with a stop sentinel after first cohort; it never calls R or a generator. `certificate_probe.py` calls public `estimate()` and production `verify()` on an audit-owned fixture. `gate_probe.py` traps `subprocess.run`, records calls and raises before any R process starts. The full scripts and JSON outputs are in `followup-evidence/`, with byte hashes in `followup-evidence/followup-files.sha256`; the scripts regenerate temporary fixtures from the preserved correction-002 archive. The full original 379 named deterministic rows are indexed by exact expected, actual, tolerance, and source filename in `followup-evidence/inherited_named_case_index.json`.

## Decisive per-case results

| Case / metric | Expected from test-spec.md | Actual | Tolerance used = specified | Verdict / evidence |
| --- | --- | --- | --- | --- |
| D05 admissible ill-conditioned SPD covariance | min eigenvalue >1e-12; successful mass feasible <=1e-9, KKT <=1e-8 | min eigenvalue `1.0000000000008375e-08`; `estimate` `ok`; independent normalized KKT `0` | exact status; `1e-9`; `1e-8` | PASS; `certificate_rejection.json` |
| D05 perturbed estimator certificate | independent normalized KKT >1e-8, reject | `0.00619175780099868` | `1e-8` | PASS independent rejection; `certificate_rejection.json` |
| D05 fake `ok` row in verifier | production verifier rejects false certificate | production `verify()` returned `PASS` after one copied row was set to mass `[.99,.005,.005]`, `status=ok`, reported KKT `0`, and its copied execution output hash was updated. Feasible direction toward original has derivative `-4159.912855134839`; copied mass is not optimal. | exact rejection | **FAIL**, simulator verifier; `certificate_rejection.json` |
| D11 changed source | reject before sampling | `RuntimeError: source changed after freeze`; 0 subprocess calls | exact / zero | PASS; `gate_matrix.json` |
| D11 changed NumPy, matplotlib, R records | reject each before sampling | each `RuntimeError: environment changed after freeze`; 0 calls each | exact / zero | PASS; `gate_matrix.json` |
| D11 missing environment | reject before sampling | `FileNotFoundError`; 0 calls | exact / zero | PASS; `gate_matrix.json` |
| D11 occupied output | reject before sampling | `RuntimeError: existing data/results; use fresh correction attempt`; 0 calls | exact / zero | PASS; `gate_matrix.json` |
| D11 invalid config path | reject before sampling | `RuntimeError: config must be public frozen preregistration`; 0 calls | exact / zero | PASS; `gate_matrix.json` |
| D11 time cap already exhausted | reject before sampling | monotonic clock fixture advanced 6000 s after 90-minute deadline construction; `execute()` reached sampling-capable `subprocess.run` once, intercepted by `DrawTrap` | zero calls | **FAIL**, simulator gate; `gate_matrix.json` |
| D11 output cap already exceeded | reject before sampling | audit fixture held a sparse 501,000,000-byte file; `execute()` reached sampling-capable `subprocess.run` once, intercepted by `DrawTrap` | zero calls | **FAIL**, simulator gate; `gate_matrix.json` |
| D12 held-out truth sentinel | prediction/prior/acquisition unchanged; no truth read during fit | poisoned truth files produced identical SHA256 for first-cohort predictions, priors, acquisition; truth-read trap count 0 | exact bytes / zero | PASS; `dataflow_sentinels.json` |
| D12 purchased measurement sentinel | all-unit update responds, own whole-unit LOO does not | changed all seven pool-1 observed channels asymmetrically; k2 P all-unit center changed, excluded-pool-1 P center exactly unchanged; measured `A1_P` mass unchanged and measured `A2_P` mass changed through its local likelihood | exact equal / unequal | PASS; `dataflow_sentinels.json` |
| D12 unmeasured local input | bulk only | all first-cohort unmeasured prediction design IDs begin `B_`; exact negative-control alias check covered 45,000 triplets across saved output | exact | PASS; `dataflow_sentinels.json`, `negative_controls.json` |
| D13 full prediction/prior keys | 350250 / 7750 distinct exact keys | 350250 / 7750; 0 duplicates, 0 missing, 0 extra | exact | PASS retrospective inventory; `retrospective_inventory.json` |
| D13 acquisition/contrast keys | 600 / 3050 exact records | 600 / 3050; 0 content/key errors, 0 duplicate or denominator errors | exact | PASS; `retrospective_inventory.json`, `contrast_inventory.json` |
| D13 full provenance | every prior included/excluded unit set and every prediction prior/design ID matches frozen schedule | 7750 prior checks and 350250 prediction checks; 0 mismatches; 16000 unique observed specimens | exact | PASS retrospective inventory; `retrospective_inventory.json` |
| D14 own-channel RMSE | independent channel residual RMSE equals saved metric within 1e-12 | 12750 numeric rows, 5250 null A1 rows, max absolute difference `2.7755575615628914e-17`, 0 bad rows | atol `1e-12`, rtol `0` | PASS; `own_channel_rmse.json` |
| D14 full prior diagnostics | saved centers, SD, T/M eigenvalues and physical diagonals, A/R correlation, floors, retrospective errors | 7750 successful priors, 250 initials; all independently recomputed numeric differences `0` at serialized precision; 500 retrospective center-error rows | atol `1e-12`, rtol `0`; counts exact | PASS; `diagnostics_recomputation.json` |
| D14 production scorer failure propagation | all 13 affected arms unavailable, 50 planned/49 complete/1 failed, all affected contrast means/SE null, unaffected blocks unchanged | 13 unavailable statuses; 90 affected contrast metric rows each `50/49/1` with null mean/SE; 21237 unaffected metric rows and 2960 unaffected summary rows byte-field identical | exact | PASS for statuses/contrasts; `production_score_injection.json` |
| D14 all affected arm metrics unavailable | all numeric metric fields unavailable on all 13 affected rows | 10 common metrics null on 13/13, but own-channel RMSE remains numeric on 8/13 and envelope widths/counts on 12/13 | exact null | **FAIL**, simulator scorer; `production_score_injection.json` |

The injected status was `numerical_failure` for `ps1_s1_r1_eval_1`, cell 1/cohort 1/full/stage 2/budget 5/unmeasured/A2_P, in a copied prediction CSV. Production `score()` returned 21250 cohort rows, one matched failed block, and 3050 paired rows. The original saved run has zero failed predictions and is not changed by this defect; a future failed run would publish partial numeric metrics despite `unavailable_matched_failure` status.

The D05 fake-success fixture changes a copied row and updates only its copied output hash. It shows that verification checks consistency with the supplied manifest but does not independently certify reported `ok` estimates. The frozen original has independently checked KKT evidence and remains unaffected. The false-positive is material to the required verifier certificate-rejection contract, not evidence of a bad frozen estimate.

## D01–D16 subcase map

The prior 379 exact named rows are retained without relabeling. For each inherited row, `inherited_named_case_index.json` records the full metric name, expected, actual, exact tolerance and original evidence source. Counts below indicate inherited named rows, not an invented overall PASS. New results and remaining failures are separately stated.

| Case | Explicit covered subcases and exact evidence | Current status |
| --- | --- | --- |
| D01 validation | 155 inherited named rows covering five public APIs, shape/type/finite/covariance/support/strength/prior/duplicate/exclusion errors; per-row exceptions and expected `ValueError` in index | inherited PASS |
| D02 purity | 28 inherited named rows: nonmutation, repeated-call identity, alias checks and import/no-I/O/no-RNG; index | inherited PASS |
| D03 prior | 16 inherited named scalar/rotated/floor/hard-projection checks, matrices at `1e-12`; index | inherited PASS |
| D04 global QP | 13 inherited bulk/redundant/phase/correlated/fixed-Q/lambda-zero checks; mass `1e-8`, objective `1e-12`; index | inherited PASS |
| D05 KKT | 40 inherited interior/edge/vertex/rank-deficient/hard/fixed-Q rows; independent ill-conditioned LP and perturbation now pass; fake-success verifier acceptance fails | **BLOCK** |
| D06 update | 12 inherited finite-mean/full-covariance/empty/two-sided LOO rows; live whole-stack sentinel confirms P and B A1/A2 routing | PASS within tested conditions |
| D07 soft/hard | 3 inherited finite-soft/structural-hard/certificate rows; index | inherited PASS |
| D08 rank/covariance | 10 inherited raw/augmented/tangent/hard, permutation and correlation checks; index | inherited PASS |
| D09 LP | 12 inherited exact/endpoints/nesting/infeasible/hard/fixed-Q checks; index | inherited PASS |
| D10 parent compatibility | 24 inherited A0/A1/A2/full/hard/fixed-Q/strength rows; index | inherited PASS |
| D11 gates | 39 inherited review/seed/source provenance/thread/cap-value rows; live changed-source, changed-environment, missing-environment, occupied/config rejection passes; elapsed/output cap call-count checks fail | **BLOCK** |
| D12 dataflow | 13 inherited stream/selection/access assertions; live poisoned truth, actual purchased-unit substitution, LOO and first-cohort prediction comparisons; exhaustive saved IDs/provenance/first-k/negative controls in inventories | PASS for tested routing |
| D13 counts/schema | inherited postrun totals plus every predicted/prior/acquisition/contrast key and provenance now checked; detailed-key prospective manifest absent | PASS numerical; process deviation |
| D14 metrics/failures | inherited ten common metrics/paired/LP checks; new all-prior/own-channel diagnostics pass; production failure injection reveals partial fields | **BLOCK** |
| D15 replay | retained correction-002 saved-input selective replay and identical generation hashes in original audit; no replay or new draw in this follow-up | inherited PASS; not rerun per R1 scope |
| D16 preservation/tools | 14 inherited named rows, public frozen review/commit/source checks and prior tests; no source/run/archives changed in follow-up | inherited PASS |

The detailed expected prediction/prior/update-instance list was **not produced before draw**. Only aggregate planned counts existed then. `retrospective_inventory.json` derives full keys from the frozen schedule now and compares them exhaustively, but this does not backdate the missing prospective artifact. Record this as a process deviation for final scientific review even though the saved rows match. No design, seed, tolerance, numerical result or historical BLOCK/PASS record was altered.

## Routing and clearance

Route all three source defects to **simulator**: (1) `score()` must blank every numeric arm metric in a matched failed block, (2) `execute()` must enforce already-exhausted wall/output caps before invoking a generator, and (3) `verify()` must reject a false `ok` estimate/certificate rather than trusting an updated output hash alone. Corrections must preserve the frozen run and all attempts, use source-only review/freeze lineage, and require independent re-probing; no new comparative draw is authorized by this follow-up. The missing prospective detailed-key manifest is a **process deviation**, not a retrospective PASS. Scientific clearance stays **STOP/BLOCK** pending resolution and independent re-review.
