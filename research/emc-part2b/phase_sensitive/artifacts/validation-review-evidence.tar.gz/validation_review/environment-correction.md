# Simulator environment freeze correction — 2026-10-27

Status: source repair committed as local `f26dc06` in the simulator worktree; no freeze certificate and no draw by simulator. The independent tester retains control of the partial root run and the next source/environment certification.

`environment()` had parsed all five source files as Python while collecting import versions. `generation.R` contains `3L`, so Python `ast.parse` stopped `--freeze` before `environment.json`, `seeds.json`, or `freeze.json` existed. The one-line repair parses only `.py` paths for the Python import inventory. `source_manifest()` still hashes all five sources, including the exact bytes of `generation.R`; `parent_source_provenance()` and the pinned R source/install checks are unchanged. The Rscript probe still records actual R, RNGkind, loaded R package versions, BLAS/LAPACK, and library paths. No design, configuration, seed, model, tolerance, package, API, or old study file changed.

Draw-free evidence in the simulator worktree: 21 focused tests passed; the new test calls the actual mixed-source environment probe and checks numeric, plotting, test, R, RNG, package and thread fields. Public `--check` passed with reviewed design digest `7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad`. The 379 independent tester metric checks passed before this correction and must be recertified after merge. No `--freeze` was invoked here because the failed partial freeze is uncommitted in the main checkout and must be preserved first.

## Exact safe tester retry after merge

Run from the main target repository root, after the simulator commit has merged. Before invoking `--freeze`, archive the first failure's exact bytes and diagnostic with this one-time command. It aborts if a completed freeze, data, results, or prior archive exists. The known original hashes below are asserted to guard against accidentally archiving a later attempt.

```sh
python3 - <<'PY'
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root = Path('research/emc-part2b/phase_sensitive/run')
manifests = root / 'manifests'
archive = manifests / 'prefreeze_failure'
expected = {
    'design_freeze.json': '276d3f893aa0c969149aeb70e6e20cbd80d6c69ae43d8a437e5a11cb5d85848a',
    'source.json': 'a41d757626ef234e6acc73b912f634cd87e3adad55131a2334786c333ff583ca',
}
assert not archive.exists(), 'first failure already archived'
assert not (manifests / 'freeze.json').exists(), 'completed freeze must not be overwritten'
assert not (root / 'data').exists() and not (root / 'results').exists(), 'draw/output evidence exists'
assert all(not (manifests / name).exists() for name in ('environment.json', 'seeds.json'))
for name, sha in expected.items():
    assert hashlib.sha256((manifests / name).read_bytes()).hexdigest() == sha, name
archive.mkdir()
for name in expected:
    shutil.copy2(manifests / name, archive / name)
    assert hashlib.sha256((archive / name).read_bytes()).hexdigest() == expected[name]
record = {
    'schema': 'qar-phase-prefreeze-failure-v1',
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'failed_command': 'measurement_experiment.py --freeze',
    'verdict': 'BLOCK',
    'reason': 'environment() passed generation.R to Python ast.parse; invalid decimal literal at R integer 3L',
    'diagnostic_artifact': 'runs/REQ-20261027-phase-sensitive/audit-predraw-block-02.md',
    'archived_sha256': expected,
    'completed_freeze': False,
    'first_draw': False,
}
(archive / 'prefreeze_failure.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
for name in expected:
    (manifests / name).unlink()
PY
```

The archive is additive and permanent: `run/manifests/prefreeze_failure/` contains the original two files and `prefreeze_failure.json`. The new `design_freeze.json` and `source.json` may then be written by the harness; their new hashes must reflect the merged source correction. Do not call this a completed study freeze or use a correction attempt, since no `freeze.json` or draw was ever created.

Use the preinstalled `/tmp/bif-v3-world1-validation-env-20261023/bin/python`, with `PYTHONDONTWRITEBYTECODE=1`, `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and writable `MPLCONFIGDIR=/tmp/emc-phase-mpl`. Rerun the focused tests and all independent draw-free D01–D12/D16 checks in the main checkout. Then run the public `--check` and `--freeze` with `--config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json`. Inspect the complete source, environment and seeds manifests and the actual `freeze.json` hashes. Restore tester-owned PASS/evidence rows in `run/audit/checks.json` after `--freeze` (the harness creates pending rows there); require D01–D12/D16 PASS and D13–D15 PENDING before any `--run`. Only the tester can then start the single authorized bounded run. After saved-output checks D13–D15 pass, use `--verify`. Preserve all failure evidence and all attempts.
