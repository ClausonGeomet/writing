# R2 public report reproduction correction

Final scientific review R2 identified that the two report PNGs could only be reproduced with a runtime-only `results-plotting.py` and that the public reports still described the then-uncommitted output as present storage. This correction adds `research/emc-part2b/phase_sensitive/render_figures.py` as a public report renderer outside the frozen design and computational source inventory. Its required CLI inputs are `--paired-summary` and `--output-dir`. `REPRODUCING.md` gives the exact draw-free command after archive restoration; `RESULTS.md` and `REPRODUCING.md` link `artifacts/README.md`. `OUTCOME.md` and the other reports now state the final scientific STOP pending R1/R2 follow-up and independent re-review, distinct from numerical audit PASS and pre-execution PASS.

The original output was uncommitted when the first report was written. The six byte-preserving archives are now committed and contain all 116 regular run files, including the final paired summary and failed-attempt history. Existing original-path, historical-seed-input, and pinned-environment caveats remain in `REPRODUCING.md` and `artifacts/README.md`.

For a draw-free check, I streamed only `run/attempts/correction-002/results/paired_summary.csv` from the committed correction-002 results archive into `/tmp/emc-r2-plot-check/paired_summary.csv`, then ran the public renderer with the pinned Python environment and `/tmp/emc-r2-plot-check/figures` as output. Both new PNG SHA256 hashes match the tracked originals exactly:

| Figure | SHA256 | Comparison |
| --- | --- | --- |
| `direct_vs_transfer.png` | `4226978901035ef33594a1b926d19ebeee6860e7a271cd2ec9ac611e1c4b19f5` | byte-identical |
| `transfer_summary.png` | `b434e82be5c7a2bc35175cadb7a7d7ac77c68a03cd4c2076d123b70886326edf` | byte-identical |

No estimator, generator, replay, or simulation was run. The existing report PNGs, frozen six design files, five computational sources, raw outputs, manifests, archives, and root architecture remain unchanged. R1 is outside this scriber correction. The current final scientific status remains STOP until independent re-review.
