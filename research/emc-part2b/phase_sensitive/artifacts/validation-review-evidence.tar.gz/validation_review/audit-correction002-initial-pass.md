# Independent tester audit — phase-sensitive correction-002

## Verdict: PASS

The single correction-002 bounded run completed under the unchanged reviewed design, all 2,000 original seeds, and builder source fix `a82f70d`. All eight regenerated data CSVs are byte-identical to correction-001. The prior numerical defect no longer appears: 350,250/350,250 predictions and 7,750/7,750 prior records succeeded; zero matched blocks failed. Final public `--verify` returned PASS. At the original cell 1/cohort 50 full P-k5 witness, the corrected mean-information off-diagonals are both `-1340.6682940007818` (asymmetry `0`); `max|PM−I|=1.1102230246251565e-16`, versus correction-001 asymmetry `1.1368683772161603e-12` above the unchanged `1e-12` criterion. The correction-001 BLOCK and original first-generation BLOCK remain preserved. This is exploratory synthetic evidence, not field accuracy or calibrated posterior coverage.

## Provenance, freeze, and preservation

|Item|Observed|Criterion|Verdict|
|---|---|---|---|
|Design digest|7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad|7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad|PASS|
|Seed manifest SHA256|c759ec08ef7b2f7bb6ce497000dfabe783ec1d3c94ee880baadb16d2dfd1a195|c759ec08ef7b2f7bb6ce497000dfabe783ec1d3c94ee880baadb16d2dfd1a195|PASS|
|Historical collision count|0|0|PASS|
|Same new streams|2000|2000|PASS|
|Correction-001 CSV hashes equal|True|True|PASS|
|Review UTC|2026-10-27T03:58:25.724734+00:00|≤ freeze UTC|PASS|
|Freeze UTC|2026-10-27T05:03:34.122458+00:00|< first draw UTC|PASS|
|First draw UTC|2026-10-27T05:03:54.433577+00:00|after freeze|PASS|
|Source changed vs correction-001|phase_models.py; test_phase_models.py|exactly builder a82f70d files|PASS|
|Correction-001 execution|blocked|blocked|PASS|
|Correction-002 execution|complete|complete|PASS|

Original/root/correction-001 data, manifests, and audit evidence were read only. The correction-001 data hashes were captured before `--run` in `audit/correction001_data_before.json`; the byte comparison is `audit/data_replay_hashes.json`. The failed numerical audit was copied byte-exact to `audit-correction-001-block.md` before this audit was replaced. The public review predates freeze and draw; `manifests/correction.json` links the blocked root execution and source-only defect. Source and environment manifests were renewed after commit `a82f70d`. No model, package, design, seed, threshold, or prior-study file was edited by tester.

## Validation commands and exact outputs

All commands ran from repo root with `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/emc-phase-mpl` and `/tmp/bif-v3-world1-validation-env-20261023/bin/python`. Pytest also used `PYTHONPATH=research/emc-part2b/phase_sensitive PYTEST_ADDOPTS=-p no:cacheprovider COVERAGE_FILE=/tmp/emc-phase-correction002-coverage`. CLI base arguments were `research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --attempt correction-002`.

1. `python -m pytest -q research/emc-part2b/phase_sensitive/test_phase_models.py research/emc-part2b/phase_sensitive/test_experiment.py --cov=phase_models --cov=measurement_experiment --cov-report=term`:
```text
........................                                                 [100%]
================================ tests coverage ================================
_______________ coverage: platform linux, python 3.12.3-final-0 ________________

Name                                                            Stmts   Miss  Cover
-----------------------------------------------------------------------------------
research/emc-part2b/phase_sensitive/measurement_experiment.py     694    423    39%
research/emc-part2b/phase_sensitive/phase_models.py               339     47    86%
-----------------------------------------------------------------------------------
TOTAL                                                            1033    470    55%
24 passed in 4.16s
```
2. `python run/attempts/correction-002/audit/tester_oracles.py`: `{"n": 135, "passed": 135, "failed": []}`.
3. `python run/attempts/correction-002/audit/tester_preflight.py`: `{"n": 244, "passed": 244, "failed": []}`. An intentional invalid covariance fixture emitted `RuntimeWarning: invalid value encountered in multiply`; it is test input construction, not a source/validation warning. The initial tester-owned directory-existence assertion failed because the root contains an empty data directory; the assertion was corrected to check for data CSVs, then all 244 metrics were rerun. No frozen tolerance changed.
4. CLI `--check`: `verdict=PASS`, design digest `7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad`.
5. CLI `--correction-reason <source-only symmetry defect and lineage> --freeze`: `verdict=FROZEN`, output `/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive/run/attempts/correction-002`.
6. CLI `--run`: `verdict=RUN_COMPLETE_PENDING_POSTCHECKS`; R generator log: `generation_complete cohorts=200 calls=800 rng=Mersenne-Twister/Inversion/Rejection`, return code 0, empty stderr.
7. `python run/attempts/correction-002/audit/postrun_audit.py`: `verdict=PASS`, 350250 predictions, 21250 metric rows, 3050 paired rows, 42750 bounds, 600 acquisition rows, 7750 prior records, 16000 distinct specimens; 18000 recomputations per each of ten error metrics; 5200 paired mean/SE numeric comparisons, maximum absolute error `2.7755575615628914e-17`, zero problems.
8. `python run/attempts/correction-002/audit/selective_replay.py`: `{"verdict":"PASS","selected":4,"max_mass_error":0.0}`. Four saved cases include both cell 1/cohort 50 witness arms, a hard-support measured LOO case, and a direct phase case. No R calls or new draws; truth opened after all replay predictions for scoring.
9. CLI `--verify`: `verdict=PASS`, `verified_utc=2026-10-27T05:14:34.487445+00:00`.

AST parsing of the four new Python files passed. `ruff` and `mypy` were unavailable. This research directory has no package build target. Frozen environment: Python 3.12.3, NumPy 2.5.3, SciPy 1.18.1, matplotlib 3.11.2, pytest 9.1.1, R 4.3.3, simCoDaR 0.1.0.9000 from public pin `d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d`; OpenBLAS/OMP/MKL threads each 1. Exact package and BLAS details are in `manifests/environment.json`.

## Before/after correction

|Metric|Correction-001 blocked|Correction-002|Change|Interpretation|
|---|---:|---:|---:|---|
|Failed predictions|330|0|-330|Symmetry failure removed|
|Matched failed blocks|8|0|-8|All matched comparisons available|
|Unavailable arm-cohort metric rows|104|0|-104|All nonempty arm rows scored|
|Complete arm-cohort metric rows|17896|18000|+104|Restored eight matched blocks|
|Data CSV SHA256 differences|0|0|+0|Same saved observations and truth|

## Post-run correctness and simulation table

|Criterion|Target|Actual|At N|Tolerance|MC SE|Verdict|
|---|---|---|---:|---|---|---|
|Predictions|350250, zero failures|350250 ok|350250|exact|not applicable to correctness gate|PASS|
|Prior records|7750, zero failures|7750 ok|7750|exact|not applicable to correctness gate|PASS|
|Cohort metric rows|21250|18000 ok + 3250 planned empty|21250|exact|not applicable to correctness gate|PASS|
|Paired summaries|3050|2600 with n_complete=50 + 450 planned empty|3050|exact|not applicable to correctness gate|PASS|
|Bound rows|42750, no numerical failures|41586 nonempty + 1164 infeasible envelope|42750|exact|not applicable to correctness gate|PASS|
|Data replay hashes|8 equal|8 equal|8|SHA256 exact|not applicable to correctness gate|PASS|
|Independent metric recomputation|all ten metrics|18000 rows each, max abs 2.220446049250313e-16|18000|atol=1e-12,rtol=0|not applicable to correctness gate|PASS|
|Paired mean/SE recomputation|all complete contrasts|5200 numeric values, max abs 2.7755575615628914e-17|50|atol=1e-12,rtol=0|not applicable to correctness gate|PASS|
|Selected saved-output replay|all four cases|4 pass; max mass error 0|4|atol=1e-12,rtol=0|not applicable to correctness gate|PASS|

The 1,164 infeasible envelopes are valid outcomes of the prespecified marginal measurement box, not solver failures. k=0 measured is a planned empty stratum. Paired SE is sample SD of 50 cohort differences divided by √50; cohorts, not specimens, are the independent units. There is no directional success cutoff, consistency series, confidence interval, predictive coverage, or significance test in this fixed exploratory design.

## Scientific findings useful to results writing

Negative paired differences favor the first arm. Values below are mean **cohort-level** mass-RMSE differences with descriptive SE over 50 independent cohorts. The direct and independent unmeasured strata remain separate.

|Cell/support|Direct A0_H−A0_B|Direct A2_H−A2_B|Unmeasured k5 A2_P−A2_R|Measured k5 A2_P−A2_R|
|---|---:|---:|---:|---:|
|1/full|-0.074109 (SE 0.001450)|-0.016720 (SE 0.000852)|-0.000292 (SE 0.000098)|-0.019058 (SE 0.001576)|
|2/full|-0.075143 (SE 0.001132)|-0.014478 (SE 0.000841)|-0.000477 (SE 0.000158)|-0.018503 (SE 0.002084)|
|3/full|-0.076782 (SE 0.001310)|-0.146625 (SE 0.001829)|-0.031298 (SE 0.000817)|-0.160079 (SE 0.004518)|
|4/soft|-0.072605 (SE 0.001323)|-0.059575 (SE 0.001492)|-0.010900 (SE 0.000387)|-0.063447 (SE 0.002006)|
|4/hard|+0.000000 (SE 0.000000)|+0.000000 (SE 0.000000)|-0.000020 (SE 0.000001)|-0.003148 (SE 0.000113)|

The independent phase row substantially resolves the direct Anatase/Rutile ambiguity: in cell 1 direct A0_H mean mass RMSE was 0.016829 versus A0_B 0.090938, while redundant Ti gave 0.090934. On independent unmeasured specimens the k=5 phase-purchase gain over replicated bulk is much smaller for accurate and weak priors (cells 1–2), larger under the mismatched prior (cell 3), and material for the soft wrong-occurrence prior (cell 4). Cell 3 A2_P still has mean unmeasured RMSE 0.144813 versus A0_P 0.092592: the phase update mitigates but does not remove that mismatched-prior harm. The cell 4 hard-zero control remains around 0.092135 and cannot recover nonzero Anatase; the corresponding soft A2_P is 0.068114. Cell 4 soft and hard share observations, so their rows are paired model-assumption comparisons, not independent replications. Full prespecified contrast/metric tables are in `results/paired_summary.csv` and `results/cohort_metrics.csv`.

These results support considering phase-sensitive testwork in a next decision, especially to challenge a wrong but finite prior. They do not establish a field gain, a dollar cost benefit, predictive coverage, or general superiority. No additional experiment was run or authorized here.

## Per-test result table — all 379 fresh deterministic rows

Every tolerance shown was copied from the executed tester evidence and matches the frozen test specification. For arrays, relative error is maximum absolute error divided by maximum absolute expected magnitude. Exact comparisons have no relative error. The JSON evidence retains full values and all 379 verdicts; no failed row is omitted.

|Test|Metric|Expected|Actual|Tolerance specified/used|Rel. error|Verdict|
|---|---|---|---|---|---|---|
|D01|fit_initial.Y.ragged|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.nan|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.posinf|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.neginf|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.string|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.bool|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.complex|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.wrongshape|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.n0|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.Y.n1|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.R.singular|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.R.negative|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.R.asymmetric|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.R.nan|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.R.complex|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.floorzero|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.floornegative|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.shrinknegative|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.shrinkhigh|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.supportnone|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.supportbad|ValueError|ValueError|exact|—|PASS|
|D01|fit_initial.supportshort|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.nan|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.posinf|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.neginf|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.string|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.bool|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.complex|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.wrongshape|ValueError|ValueError|exact|—|PASS|
|D01|estimate.y.ragged|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.singular|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.negative|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.asymmetric|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.nan|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.ragged|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.nan|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.string|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.bool|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.complex|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.wrongshape|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.allfalse|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.nonbool|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.short|ValueError|ValueError|exact|—|PASS|
|D01|estimate.fixedQ.low|ValueError|ValueError|exact|—|PASS|
|D01|estimate.fixedQ.high|ValueError|ValueError|exact|—|PASS|
|D01|estimate.fixedQ.conflict|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.nan|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.posinf|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.neginf|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.string|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.bool|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.complex|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.wrongshape|ValueError|ValueError|exact|—|PASS|
|D01|bounds.y.ragged|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.singular|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.negative|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.asymmetric|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.nan|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.ragged|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.nan|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.string|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.bool|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.complex|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.wrongshape|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.allfalse|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.nonbool|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.short|ValueError|ValueError|exact|—|PASS|
|D01|bounds.fixedQ.low|ValueError|ValueError|exact|—|PASS|
|D01|bounds.fixedQ.high|ValueError|ValueError|exact|—|PASS|
|D01|bounds.fixedQ.conflict|ValueError|ValueError|exact|—|PASS|
|D01|unknownmethod|ValueError|ValueError|exact|—|PASS|
|D01|A0prior|ValueError|ValueError|exact|—|PASS|
|D01|A1data|ValueError|ValueError|exact|—|PASS|
|D01|A2noprior|ValueError|ValueError|exact|—|PASS|
|D01|negstrength|ValueError|ValueError|exact|—|PASS|
|D01|nanstrength|ValueError|ValueError|exact|—|PASS|
|D01|badprior|ValueError|ValueError|exact|—|PASS|
|D01|duplicateunits|ValueError|ValueError|exact|—|PASS|
|D01|unknownexclude|ValueError|ValueError|exact|—|PASS|
|D01|signed.estimate.status|ok|ok|exact|—|PASS|
|D01|signed.bounds.status|True|True|exact|—|PASS|
|D02|fit.repeat|{"center": [0.6000000000000001, 0.1, 0.30000000000000004], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": [], "mean_constraint_violation": 0.0, "mean_information": [[1441.4414414414416, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 3.469446951953615e-17, "mean_score": [470.7728034177882, -112.57421392024654], "n_cal": 4, "n_update": 0, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, "mean_cov": [[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]], "precision": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|{"center": [0.6000000000000001, 0.1, 0.30000000000000004], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": [], "mean_constraint_violation": 0.0, "mean_information": [[1441.4414414414416, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 3.469446951953615e-17, "mean_score": [470.7728034177882, -112.57421392024654], "n_cal": 4, "n_update": 0, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, "mean_cov": [[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]], "precision": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|exact|—|PASS|
|D02|fit.immutable|True|True|exact|—|PASS|
|D02|update.repeat|{"center": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": ["x"], "mean_constraint_violation": 2.220446049250313e-16, "mean_information": [[1442.7705658807172, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 2.2572225151953736e-17, "mean_score": [471.2068936419066, -112.57421392024654], "n_cal": 4, "n_update": 1, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], "update_projection_distance": 1.7554167342883506e-16}, "mean_cov": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], "precision": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|{"center": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": ["x"], "mean_constraint_violation": 2.220446049250313e-16, "mean_information": [[1442.7705658807172, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 2.2572225151953736e-17, "mean_score": [471.2068936419066, -112.57421392024654], "n_cal": 4, "n_update": 1, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], "update_projection_distance": 1.7554167342883506e-16}, "mean_cov": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], "precision": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|exact|—|PASS|
|D02|update.immutable|True|True|exact|—|PASS|
|D02|estimate.repeat|{"active_support": [0, 1, 2], "assay_loss": 6.162975822039155e-33, "constraint_violation": 0.0, "kkt_residual": 5.660956118940746e-17, "mass": [0.6, 0.10000000000000006, 0.30000000000000004], "objective": 2.2291317030190583e-30, "prior_loss": 2.2229687271970192e-30, "reason": "", "reconstructed": [0.6, 0.40000000000000013], "residual": [0.0, -1.1102230246251565e-16], "status": "ok"}|{"active_support": [0, 1, 2], "assay_loss": 6.162975822039155e-33, "constraint_violation": 0.0, "kkt_residual": 5.660956118940746e-17, "mass": [0.6, 0.10000000000000006, 0.30000000000000004], "objective": 2.2291317030190583e-30, "prior_loss": 2.2229687271970192e-30, "reason": "", "reconstructed": [0.6, 0.40000000000000013], "residual": [0.0, -1.1102230246251565e-16], "status": "ok"}|exact|—|PASS|
|D02|estimate.immutable|True|True|exact|—|PASS|
|D02|information.repeat|{"rank_augmented": 2, "rank_raw": 2, "rank_support_tangent": 1, "rank_tangent": 1, "singular_augmented": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], "singular_raw": [1.4142135623730951, 1.0], "singular_support_tangent": [1.1547005383792517, 2.1885947940466786e-19], "singular_tangent": [1.1547005383792517, 0.0]}|{"rank_augmented": 2, "rank_raw": 2, "rank_support_tangent": 1, "rank_tangent": 1, "singular_augmented": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], "singular_raw": [1.4142135623730951, 1.0], "singular_support_tangent": [1.1547005383792517, 2.1885947940466786e-19], "singular_tangent": [1.1547005383792517, 0.0]}|exact|—|PASS|
|D02|information.immutable|True|True|exact|—|PASS|
|D02|bounds.repeat|{"lower": [0.0, 0.0, 0.0], "max_constraint_violation": 0.0, "reason": "", "status": "ok", "upper": [1.0, 1.0, 1.0], "width": [1.0, 1.0, 1.0]}|{"lower": [0.0, 0.0, 0.0], "max_constraint_violation": 0.0, "reason": "", "status": "ok", "upper": [1.0, 1.0, 1.0], "width": [1.0, 1.0, 1.0]}|exact|—|PASS|
|D02|bounds.immutable|True|True|exact|—|PASS|
|D03|raw_cov|[[0.0024, 0.0], [0.0, 0.005399999999999999]]|[[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]|1e-12|3.08395e-14%|PASS|
|D03|intrinsic_T|[[0.0023749999999999995, 0.0], [0.0, 0.004624999999999999]]|[[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]|1e-12|2.70023e-14%|PASS|
|D03|mean_M|[[0.0006937499999999999, 0.0], [0.0, 0.0012562499999999998]]|[[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]]|1e-12|2.48567e-14%|PASS|
|D03|precision_K|[[217.24372029871023, -108.62186014935511, -108.62186014935511], [-108.62186014935511, 139.3268705635192, -30.705010414164104], [-108.62186014935511, -30.705010414164104, 139.3268705635192]]|[[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]]|1e-12|2.61657e-14%|PASS|
|D03|center|[0.6, 0.1, 0.3]|[0.6000000000000001, 0.1, 0.30000000000000004]|1e-12|1.85037e-14%|PASS|
|D03|hard_center|[0.65, 0, 0.35]|[0.6499999999999998, -4.606468600199157e-17, 0.34999999999999976]|1e-12|3.41607e-14%|PASS|
|D03|hard_T_same|[[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]|[[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]|1e-12|0%|PASS|
|D03|floor_identical|[0.0001, 0.0001]|[0.0001, 0.0001]|1e-12|0%|PASS|
|D03|rotated_eigenvalues|[0.001866175514774443, 0.005033824485225557]|[0.0018661755147744443, 0.005033824485225553]|1e-12|6.89227e-14%|PASS|
|D03|rotated_T|[[0.0031724999999999995, -0.001155], [-0.001155, 0.0037275]]|[[0.0031724999999999987, -0.001154999999999998], [-0.001154999999999998, 0.0037274999999999977]]|1e-12|5.81732e-14%|PASS|
|D03|rotated_M|[[0.0008931249999999999, -0.00026375], [-0.00026375, 0.001056875]]|[[0.0008931249999999997, -0.0002637499999999995], [-0.0002637499999999995, 0.0010568749999999994]]|1e-12|6.15514e-14%|PASS|
|D04|bulk.mass|[0.6, 0.2, 0.2]|[0.6, 0.20000000000000007, 0.20000000000000007]|1e-08|9.25186e-15%|PASS|
|D05|bulk.kkt_bound|True|True|exact|—|PASS|
|D04|phase.mass|[0.6, 0.1, 0.3]|[0.6000000000000001, 0.10000000000000014, 0.2999999999999999]|1e-08|2.31296e-14%|PASS|
|D05|phase.kkt_bound|True|True|exact|—|PASS|
|D04|redundant.mass|[0.6, 0.2, 0.2]|[0.6000000000000001, 0.2, 0.2]|1e-08|1.85037e-14%|PASS|
|D05|redundant.kkt_bound|True|True|exact|—|PASS|
|D04|lambda0_equals_A0|[0.615, 0.19250000000000003, 0.19250000000000003]|[0.615, 0.19250000000000003, 0.19250000000000003]|1e-08|0%|PASS|
|D04|fixedQ_bulk_min_norm|[0.6, 0.2, 0.2]|[0.5999999999999995, 0.19999999999999962, 0.19999999999999962]|1e-08|7.40149e-14%|PASS|
|D04|fixedQ_lambda0_min_norm|[0.6, 0.2, 0.2]|[0.5999999999999995, 0.19999999999999962, 0.19999999999999962]|1e-08|7.40149e-14%|PASS|
|D06|oneunit_center|[0.6007162250709892, 0.0984013492518974, 0.3008824256771134]|[0.6007162250709892, 0.09840134925189753, 0.30088242567711343]|1e-12|2.07919e-14%|PASS|
|D06|oneunit_M|[[0.000912280701754386, 0.0], [0.0, 0.000912280701754386]]|[[0.000912280701754386, -5.171207803974685e-22], [-5.171207803974685e-22, 0.000912280701754386]]|1e-12|5.66844e-17%|PASS|
|D06|empty_center|[0.6, 0.1, 0.3]|[0.6, 0.1, 0.3]|1e-12|0%|PASS|
|D06|wholeunit_LOO_center|[0.5985675498580215, 0.10133649417729329, 0.30009595596468525]|[0.5985675498580215, 0.10133649417729329, 0.30009595596468525]|1e-12|0%|PASS|
|D06|excluded_changes_no_effect|[0.5985675498580215, 0.10133649417729329, 0.30009595596468525]|[0.5985675498580215, 0.10133649417729329, 0.30009595596468525]|1e-12|0%|PASS|
|D07|soft_A_gt_.1|True|True|exact|—|PASS|
|D07|hard_A_zero|0|-4.7251753127059576e-17|1e-09|—|PASS|
|D07|soft_hard_T_equal|[[0.01, 0.0], [0.0, 0.01]]|[[0.01, 0.0], [0.0, 0.01]]|1e-12|0%|PASS|
|D08|C.ranks|[2, 2, 1]|[2, 2, 1]|0|0%|PASS|
|D08|Ct.ranks|[2, 2, 1]|[2, 2, 1]|0|0%|PASS|
|D08|Ch.ranks|[3, 3, 2]|[3, 3, 2]|0|0%|PASS|
|D08|hard_C_rank|1|1|exact|0%|PASS|
|D08|joint_permutation_mass|[0.614747697236684, 0.09262615138165695, 0.2926261513816592]|[0.6147476972366841, 0.0926261513816577, 0.2926261513816583]|1e-08|1.44479e-13%|PASS|
|D08|joint_permutation_objective|0.24637257016111222|0.24637257016111228|1e-12|2.25314e-14%|PASS|
|D09|bulk_bounds_lo|[0.6, 0, 0]|[0.599999999999, 0.0, 0.0]|1e-08|1.66663e-10%|PASS|
|D09|bulk_bounds_hi|[0.6, 0.4, 0.4]|[0.600000000001, 0.400000000001, 0.400000000001]|1e-08|1.66663e-10%|PASS|
|D09|phase_singleton|[0.6, 0.1, 0.3]|[0.599999999999, 0.099999999999, 0.29999999999800003]|1e-08|3.33326e-10%|PASS|
|D09|incompatible_status|infeasible_envelope|infeasible_envelope|exact|—|PASS|
|D09|incompatible_null|None|None|exact|—|PASS|
|D11|pre_run_required_ids|D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16|D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16|exact|—|PASS|
|D16|AST.phase_models.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.measurement_experiment.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.test_phase_models.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.test_experiment.py|parse_ok|parse_ok|exact|—|PASS|
|D01|estimate.D.empty|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.wrong|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.ragged|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.bool|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.inf|ValueError|ValueError|exact|—|PASS|
|D01|estimate.D.complex|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.bool|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.complex|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.inf|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.nonsym|ValueError|ValueError|exact|—|PASS|
|D01|estimate.cov.singular|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.(False, False, False)|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.(1, 1, 1)|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.(True, False)|ValueError|ValueError|exact|—|PASS|
|D01|estimate.support.bad|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.empty|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.wrong|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.ragged|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.bool|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.inf|ValueError|ValueError|exact|—|PASS|
|D01|bounds.D.complex|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.bool|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.complex|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.inf|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.nonsym|ValueError|ValueError|exact|—|PASS|
|D01|bounds.cov.singular|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.(False, False, False)|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.(1, 1, 1)|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.(True, False)|ValueError|ValueError|exact|—|PASS|
|D01|bounds.support.bad|ValueError|ValueError|exact|—|PASS|
|D01|info.D.empty|ValueError|ValueError|exact|—|PASS|
|D01|info.D.wrong|ValueError|ValueError|exact|—|PASS|
|D01|info.D.ragged|ValueError|ValueError|exact|—|PASS|
|D01|info.D.bool|ValueError|ValueError|exact|—|PASS|
|D01|info.D.inf|ValueError|ValueError|exact|—|PASS|
|D01|info.D.complex|ValueError|ValueError|exact|—|PASS|
|D01|info.cov.bool|ValueError|ValueError|exact|—|PASS|
|D01|info.cov.complex|ValueError|ValueError|exact|—|PASS|
|D01|info.cov.inf|ValueError|ValueError|exact|—|PASS|
|D01|info.cov.nonsym|ValueError|ValueError|exact|—|PASS|
|D01|info.cov.singular|ValueError|ValueError|exact|—|PASS|
|D01|info.support.(False, False, False)|ValueError|ValueError|exact|—|PASS|
|D01|info.support.(1, 1, 1)|ValueError|ValueError|exact|—|PASS|
|D01|info.support.(True, False)|ValueError|ValueError|exact|—|PASS|
|D01|info.support.bad|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.failed|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.failed|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.missing|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.missing|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.T_negative|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.T_negative|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.M_singular|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.M_singular|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.K_bad|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.K_bad|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.center_bad|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.center_bad|ValueError|ValueError|exact|—|PASS|
|D01|estimate.prior.diag_bad|ValueError|ValueError|exact|—|PASS|
|D01|update.prior.diag_bad|ValueError|ValueError|exact|—|PASS|
|D01|update.units.notlist|ValueError|ValueError|exact|—|PASS|
|D01|update.units.badunit|ValueError|ValueError|exact|—|PASS|
|D01|update.units.badID|ValueError|ValueError|exact|—|PASS|
|D01|update.units.badD|ValueError|ValueError|exact|—|PASS|
|D01|update.units.badY|ValueError|ValueError|exact|—|PASS|
|D01|update.units.badCov|ValueError|ValueError|exact|—|PASS|
|D01|bounds.multiplier.-1|ValueError|ValueError|exact|—|PASS|
|D01|bounds.multiplier.0|ValueError|ValueError|exact|—|PASS|
|D01|bounds.multiplier.nan|ValueError|ValueError|exact|—|PASS|
|D01|bounds.multiplier.True|ValueError|ValueError|exact|—|PASS|
|D01|bounds.multiplier.3|ValueError|ValueError|exact|—|PASS|
|D01|estimate.strength.True|ValueError|ValueError|exact|—|PASS|
|D01|estimate.strength.1|ValueError|ValueError|exact|—|PASS|
|D01|estimate.strength.(1+1j)|ValueError|ValueError|exact|—|PASS|
|D01|signed.calibration|ok|ok|exact|—|PASS|
|D02|fit.repeat|{"center": [0.6000000000000001, 0.1, 0.30000000000000004], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": [], "mean_constraint_violation": 0.0, "mean_information": [[1441.4414414414416, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 3.469446951953615e-17, "mean_score": [470.7728034177882, -112.57421392024654], "n_cal": 4, "n_update": 0, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, "mean_cov": [[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]], "precision": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|{"center": [0.6000000000000001, 0.1, 0.30000000000000004], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": [], "mean_constraint_violation": 0.0, "mean_information": [[1441.4414414414416, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 3.469446951953615e-17, "mean_score": [470.7728034177882, -112.57421392024654], "n_cal": 4, "n_update": 0, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, "mean_cov": [[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]], "precision": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|exact|—|PASS|
|D02|fit.input_unchanged|True|True|exact|—|PASS|
|D02|fit.no_return_alias|True|True|exact|—|PASS|
|D02|update.repeat|{"center": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": ["x"], "mean_constraint_violation": 2.220446049250313e-16, "mean_information": [[1442.7705658807172, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 2.2572225151953736e-17, "mean_score": [471.2068936419066, -112.57421392024654], "n_cal": 4, "n_update": 1, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], "update_projection_distance": 1.7554167342883506e-16}, "mean_cov": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], "precision": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|{"center": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], "diagnostics": {"deconvolved_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "excluded_unit_id": null, "floored_eigenvalues": [0.0019999999999999996, 0.004999999999999999], "included_unit_ids": ["x"], "mean_constraint_violation": 2.220446049250313e-16, "mean_information": [[1442.7705658807172, -3.582947094227032e-13], [-3.582947094227032e-13, 796.0199004975126]], "mean_kkt_residual": 2.2572225151953736e-17, "mean_score": [471.2068936419066, -112.57421392024654], "n_cal": 4, "n_update": 1, "projection_distance": 1.2412670766236366e-16, "raw_mean": [0.6, 0.1, 0.3], "raw_tangent_cov": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], "update_projection_distance": 1.7554167342883506e-16}, "mean_cov": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], "precision": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], "reason": "", "status": "ok", "tangent_cov": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}|exact|—|PASS|
|D02|update.input_unchanged|True|True|exact|—|PASS|
|D02|update.no_return_alias|True|True|exact|—|PASS|
|D02|estimate.repeat|{"active_support": [0, 1, 2], "assay_loss": 6.162975822039155e-33, "constraint_violation": 0.0, "kkt_residual": 5.660956118940746e-17, "mass": [0.6, 0.10000000000000006, 0.30000000000000004], "objective": 2.2291317030190583e-30, "prior_loss": 2.2229687271970192e-30, "reason": "", "reconstructed": [0.6, 0.40000000000000013], "residual": [0.0, -1.1102230246251565e-16], "status": "ok"}|{"active_support": [0, 1, 2], "assay_loss": 6.162975822039155e-33, "constraint_violation": 0.0, "kkt_residual": 5.660956118940746e-17, "mass": [0.6, 0.10000000000000006, 0.30000000000000004], "objective": 2.2291317030190583e-30, "prior_loss": 2.2229687271970192e-30, "reason": "", "reconstructed": [0.6, 0.40000000000000013], "residual": [0.0, -1.1102230246251565e-16], "status": "ok"}|exact|—|PASS|
|D02|estimate.input_unchanged|True|True|exact|—|PASS|
|D02|estimate.no_return_alias|True|True|exact|—|PASS|
|D02|info.repeat|{"rank_augmented": 2, "rank_raw": 2, "rank_support_tangent": 1, "rank_tangent": 1, "singular_augmented": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], "singular_raw": [1.4142135623730951, 1.0], "singular_support_tangent": [1.1547005383792517, 2.1885947940466786e-19], "singular_tangent": [1.1547005383792517, 0.0]}|{"rank_augmented": 2, "rank_raw": 2, "rank_support_tangent": 1, "rank_tangent": 1, "singular_augmented": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], "singular_raw": [1.4142135623730951, 1.0], "singular_support_tangent": [1.1547005383792517, 2.1885947940466786e-19], "singular_tangent": [1.1547005383792517, 0.0]}|exact|—|PASS|
|D02|info.input_unchanged|True|True|exact|—|PASS|
|D02|info.no_return_alias|True|True|exact|—|PASS|
|D02|bounds.repeat|{"lower": [0.0, 0.0, 0.0], "max_constraint_violation": 0.0, "reason": "", "status": "ok", "upper": [1.0, 1.0, 1.0], "width": [1.0, 1.0, 1.0]}|{"lower": [0.0, 0.0, 0.0], "max_constraint_violation": 0.0, "reason": "", "status": "ok", "upper": [1.0, 1.0, 1.0], "width": [1.0, 1.0, 1.0]}|exact|—|PASS|
|D02|bounds.input_unchanged|True|True|exact|—|PASS|
|D02|bounds.no_return_alias|True|True|exact|—|PASS|
|D02|isolated_import_exit|0|0|exact|—|PASS|
|D02|isolated_import_stdout|||exact|—|PASS|
|D02|isolated_import_stderr|||exact|—|PASS|
|D03|diagnostic.raw_mean|True|True|exact|—|PASS|
|D03|diagnostic.raw_tangent_cov|True|True|exact|—|PASS|
|D03|diagnostic.deconvolved_eigenvalues|True|True|exact|—|PASS|
|D03|diagnostic.floored_eigenvalues|True|True|exact|—|PASS|
|D03|diagnostic.projection_distance|True|True|exact|—|PASS|
|D04|fixedQ_fullrank|[0.6, 0.230989010989011, 0.16901098901098902]|[0.5999999999999995, 0.23098901098901087, 0.16901098901098838]|1e-08|1.06396e-13%|PASS|
|D04|fixedQ_boundary_0|[0, 0.5, 0.5]|[-1.1014039518277619e-17, 0.4999999999999998, 0.4999999999999998]|1e-08|4.44089e-14%|PASS|
|D04|fixedQ_boundary_1|[1, 0, 0]|[0.9999999999999996, -1.8445061867120456e-16, -1.8445061867120456e-16]|1e-08|4.44089e-14%|PASS|
|D04|fixedQ_positive_strength_center|[0.6000000000000001, 0.1, 0.30000000000000004]|[0.5999999999999995, 0.09999999999999992, 0.2999999999999993]|1e-08|1.20274e-13%|PASS|
|D05|interior.status|ok|ok|exact|—|PASS|
|D05|interior.feasible|True|True|exact|—|PASS|
|D05|interior.certified|True|True|exact|—|PASS|
|D05|interior.directional_min_gap|True|True|exact|—|PASS|
|D05|interior.perturbed_rejected|True|True|exact|—|PASS|
|D05|edge.status|ok|ok|exact|—|PASS|
|D05|edge.feasible|True|True|exact|—|PASS|
|D05|edge.certified|True|True|exact|—|PASS|
|D05|edge.directional_min_gap|True|True|exact|—|PASS|
|D05|edge.perturbed_rejected|True|True|exact|—|PASS|
|D05|vertex.status|ok|ok|exact|—|PASS|
|D05|vertex.feasible|True|True|exact|—|PASS|
|D05|vertex.certified|True|True|exact|—|PASS|
|D05|vertex.directional_min_gap|True|True|exact|—|PASS|
|D05|vertex.perturbed_rejected|True|True|exact|—|PASS|
|D05|hard.status|ok|ok|exact|—|PASS|
|D05|hard.feasible|True|True|exact|—|PASS|
|D05|hard.certified|True|True|exact|—|PASS|
|D05|hard.directional_min_gap|True|True|exact|—|PASS|
|D05|hard.perturbed_rejected|True|True|exact|—|PASS|
|D05|fixed.status|ok|ok|exact|—|PASS|
|D05|fixed.feasible|True|True|exact|—|PASS|
|D05|fixed.certified|True|True|exact|—|PASS|
|D05|fixed.directional_min_gap|True|True|exact|—|PASS|
|D05|fixed.perturbed_rejected|True|True|exact|—|PASS|
|D04|correlated_A2_stationary_mass|[0.6147476972366841, 0.09262615138165814, 0.29262615138165776]|[0.614747697236684, 0.09262615138165695, 0.2926261513816592]|1e-08|2.34778e-13%|PASS|
|D04|correlated_A2_objective|0.2463725701611168|0.24637257016111222|1e-12|1.85884e-12%|PASS|
|D04|correlated_A2_signed_residual|[0.005252302763315897, 0.004747697236684112]|[0.005252302763316008, 0.00474769723668389]|1e-12|4.22757e-12%|PASS|
|D05|interior.independent_kkt_lp|True|True|exact|—|PASS|
|D05|interior.primal|True|True|exact|—|PASS|
|D05|edge.independent_kkt_lp|True|True|exact|—|PASS|
|D05|edge.primal|True|True|exact|—|PASS|
|D05|vertex.independent_kkt_lp|True|True|exact|—|PASS|
|D05|vertex.primal|True|True|exact|—|PASS|
|D05|rankdef.independent_kkt_lp|True|True|exact|—|PASS|
|D05|rankdef.primal|True|True|exact|—|PASS|
|D05|hard.independent_kkt_lp|True|True|exact|—|PASS|
|D05|hard.primal|True|True|exact|—|PASS|
|D05|fixed.independent_kkt_lp|True|True|exact|—|PASS|
|D05|fixed.primal|True|True|exact|—|PASS|
|D06|cross_repeat_intrinsic_nonzero|True|True|exact|—|PASS|
|D06|repeat_mean_cov|[[0.0009093073347693006, 0.0], [0.0, 0.001]]|[[0.0009093073347693006, 0.0], [0.0, 0.001]]|1e-12|0%|PASS|
|D06|wrong_independent_differs|True|True|exact|—|PASS|
|D06|LOO_x|[0.6007162250709892, 0.09840134925189753, 0.30088242567711343]|[0.6007162250709892, 0.09840134925189753, 0.30088242567711343]|1e-12|0%|PASS|
|D06|LOO_M_x|[[0.000912280701754386, -5.171207803974685e-22], [-5.171207803974685e-22, 0.000912280701754386]]|[[0.000912280701754386, -5.171207803974685e-22], [-5.171207803974685e-22, 0.000912280701754386]]|1e-12|0%|PASS|
|D06|LOO_y|[0.6, 0.10000000000000012, 0.3]|[0.6, 0.10000000000000012, 0.3]|1e-12|0%|PASS|
|D06|LOO_M_y|[[0.0009093073347693006, 0.0], [0.0, 0.001]]|[[0.0009093073347693006, 0.0], [0.0, 0.001]]|1e-12|0%|PASS|
|D08|C.tangent_singular|[138.01311186847087, 0.0]|[138.01311186847084, 9.896688101312627e-16]|1e-08|2.05935e-14%|PASS|
|D08|Ct.tangent_singular|[140.7052941362897, 0.0]|[140.70529413628972, 2.272935496515929e-15]|1e-08|2.01995e-14%|PASS|
|D08|Ch.tangent_singular|[139.61674589653614, 34.94924862636929]|[139.61674589653617, 34.94924862636929]|1e-08|2.03569e-14%|PASS|
|D08|correlation_objective_diff|True|True|exact|—|PASS|
|D09|bulk.lower|[0.57, -0.0, 0.0]|[0.57, 0.0, 0.0]|1e-08|0%|PASS|
|D09|bulk.upper|[0.63, 0.43000000000000005, 0.43000000000000005]|[0.63, 0.43000000000000005, 0.43000000000000005]|1e-08|0%|PASS|
|D09|phase.lower|[0.57, 0.04000000000000001, 0.20999999999999996]|[0.57, 0.04000000000000001, 0.21]|1e-08|4.8694e-15%|PASS|
|D09|phase.upper|[0.63, 0.16, 0.39]|[0.63, 0.16, 0.39]|1e-08|0%|PASS|
|D09|nested_width|True|True|exact|—|PASS|
|D09|hard_width_A|0|0.0|1e-08|—|PASS|
|D09|fixedQ_width_Q|0|0.0|1e-08|—|PASS|
|D10|parent_T_(True, True, True)|[[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]|[[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]|1e-12|4.16417e-30%|PASS|
|D10|parent_M_(True, True, True)|[[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]]|[[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]]|1e-12|1.91767e-17%|PASS|
|D10|(True, True, True).None.A0.0.mass|[0.615, 0.1925, 0.1925]|[0.615, 0.1925000000000001, 0.19250000000000006]|1e-08|1.35393e-14%|PASS|
|D10|(True, True, True).None.A1.0.mass|[0.6, 0.1000000000000003, 0.30000000000000016]|[0.6000000000000001, 0.1, 0.30000000000000004]|1e-08|4.85723e-14%|PASS|
|D10|(True, True, True).None.A2.0.mass|[0.615, 0.1925, 0.1925]|[0.615, 0.1925000000000001, 0.19250000000000006]|1e-08|1.35393e-14%|PASS|
|D10|(True, True, True).None.A2.0.01.mass|[0.6149974342475013, 0.09250128287658656, 0.29250128287591204]|[0.6149974342475013, 0.09250128287622947, 0.29250128287626925]|1e-08|5.80839e-11%|PASS|
|D10|(True, True, True).None.A2.1.mass|[0.6147476972366848, 0.09262615138165119, 0.29262615138166526]|[0.614747697236684, 0.09262615138165695, 0.2926261513816592]|1e-08|9.8426e-13%|PASS|
|D10|(True, True, True).0.6.A0.0.mass|[0.6, 0.2, 0.2]|[0.5999999999999995, 0.19999999999999962, 0.19999999999999962]|1e-08|7.40149e-14%|PASS|
|D10|(True, True, True).0.6.A1.0.mass|[0.6000000000000004, 0.10000000000000003, 0.3000000000000001]|[0.6, 0.1, 0.3]|1e-08|7.40149e-14%|PASS|
|D10|(True, True, True).0.6.A2.0.mass|[0.6, 0.2, 0.2]|[0.5999999999999995, 0.19999999999999962, 0.19999999999999962]|1e-08|7.40149e-14%|PASS|
|D10|(True, True, True).0.6.A2.0.01.mass|[0.5999999999999851, 0.0999999999999653, 0.30000000000005433]|[0.5999999999999995, 0.10000000000009415, 0.2999999999999051]|1e-08|2.4869e-11%|PASS|
|D10|(True, True, True).0.6.A2.1.mass|[0.5999999999948382, 0.10000000000110289, 0.3000000000010307]|[0.5999999999999995, 0.10000000000000006, 0.2999999999999992]|1e-08|8.60219e-10%|PASS|
|D10|parent_T_(True, False, True)|[[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]|[[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]|1e-12|4.16417e-30%|PASS|
|D10|parent_M_(True, False, True)|[[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]]|[[0.0006937499999999999, 3.122622367941378e-19], [3.122622367941378e-19, 0.0012562499999999998]]|1e-12|1.91767e-17%|PASS|
|D10|(True, False, True).None.A0.0.mass|[0.615, 0.0, 0.385]|[0.6149999999999998, -4.690318705306234e-17, 0.38499999999999984]|1e-08|3.61048e-14%|PASS|
|D10|(True, False, True).None.A1.0.mass|[0.6499999999999995, -1.132993058676088e-16, 0.3499999999999998]|[0.6499999999999998, -4.606468600199157e-17, 0.34999999999999976]|1e-08|5.12411e-14%|PASS|
|D10|(True, False, True).None.A2.0.mass|[0.615, 0.0, 0.385]|[0.6149999999999998, -4.690318705306234e-17, 0.38499999999999984]|1e-08|3.61048e-14%|PASS|
|D10|(True, False, True).None.A2.0.01.mass|[0.6150070278138804, -1.4232839855673103e-15, 0.3849929721861204]|[0.6150070278138804, -4.6903018686510176e-17, 0.38499297218611916]|1e-08|2.23799e-13%|PASS|
|D10|(True, False, True).None.A2.1.mass|[0.615689083325587, -9.314921217736359e-16, 0.3843109166744108]|[0.6156890833255888, -4.688667856469715e-17, 0.38431091667441075]|1e-08|2.88515e-13%|PASS|
|D10|(True, False, True).0.6.A0.0.mass|[0.6, 0.0, 0.4]|[0.6, -1.2805796264108082e-16, 0.3999999999999999]|1e-08|2.1343e-14%|PASS|
|D10|(True, False, True).0.6.A1.0.mass|[0.6, 6.938893903907228e-17, 0.4]|[0.6, 0.0, 0.4]|1e-08|1.15648e-14%|PASS|
|D10|(True, False, True).0.6.A2.0.mass|[0.6, 0.0, 0.4]|[0.6, -1.2805796264108082e-16, 0.3999999999999999]|1e-08|2.1343e-14%|PASS|
|D10|(True, False, True).0.6.A2.0.01.mass|[0.5999999999999996, -1.792969616876736e-14, 0.40000000000001773]|[0.6, -1.2805796264108082e-16, 0.3999999999999999]|1e-08|2.96985e-12%|PASS|
|D10|(True, False, True).0.6.A2.1.mass|[0.5999999999999961, 3.519427571442324e-14, 0.39999999999999014]|[0.6, -1.2805796264108082e-16, 0.3999999999999999]|1e-08|5.88706e-12%|PASS|
|D11|design_digest|7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad|7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad|exact|—|PASS|
|D11|source_file_count|5|5|exact|—|PASS|
|D11|parent_nonimport|read-only reference; no import or call by study code|read-only reference; no import or call by study code|exact|—|PASS|
|D11|package_pin|d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d|d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d|exact|—|PASS|
|D11|historical_paths|11|11|exact|—|PASS|
|D11|historical_seed_count|2009|2009|exact|—|PASS|
|D11|new_seed_count|2000|2000|exact|—|PASS|
|D11|collision_count|0|0|exact|—|PASS|
|D11|historical_hash.source_manifest.json|d3ce9ada450f22eecf0195131f690508b3364bd7e9cf82ff68ee1264ca10670a|d3ce9ada450f22eecf0195131f690508b3364bd7e9cf82ff68ee1264ca10670a|exact|—|PASS|
|D11|historical_hash.manifest.json|21d87288b39cbc0acadf492150e19e9baa8a94e8337281f1ed1a6acd55edea36|21d87288b39cbc0acadf492150e19e9baa8a94e8337281f1ed1a6acd55edea36|exact|—|PASS|
|D11|historical_hash.fixture_manifest.json|b2f7be63c55e6f933152588721fd0477f531103dba6814ce81c666c389b6cf9d|b2f7be63c55e6f933152588721fd0477f531103dba6814ce81c666c389b6cf9d|exact|—|PASS|
|D11|historical_hash.baseline_freeze.json|02ea077d3c96d9fe682079d3253088c731878b0a2d80962be748c231fffdf7b4|02ea077d3c96d9fe682079d3253088c731878b0a2d80962be748c231fffdf7b4|exact|—|PASS|
|D11|historical_hash.manifest.json|359bf2b7a8f7ba3d1a1fcfab9852416976c5889ada19a56d9d53d572f8595e9a|359bf2b7a8f7ba3d1a1fcfab9852416976c5889ada19a56d9d53d572f8595e9a|exact|—|PASS|
|D11|historical_hash.preregistration.json|09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa|09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa|exact|—|PASS|
|D11|historical_hash.seeds.json|eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa|eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa|exact|—|PASS|
|D11|historical_hash.seeds.json|eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa|eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa|exact|—|PASS|
|D11|historical_hash.sim-spec.md|0faa538b659d532f46fdb203720ac451e197c246da2b108e4e910039c05bd711|0faa538b659d532f46fdb203720ac451e197c246da2b108e4e910039c05bd711|exact|—|PASS|
|D11|historical_hash.sim-spec.md|8c89c581ca1add70ffa0c7cca7ce20eef5dd9a5f7296c59b6afde848412f2b07|8c89c581ca1add70ffa0c7cca7ce20eef5dd9a5f7296c59b6afde848412f2b07|exact|—|PASS|
|D11|historical_hash.preregistration.json|09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa|09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa|exact|—|PASS|
|D11|unfrozen_run_rejected|FileNotFoundError|FileNotFoundError|exact|—|PASS|
|D11|unfrozen_generator_calls|0|0|exact|—|PASS|
|D12|truth_not_opened_in_predict|False|False|exact|—|PASS|
|D12|evaluation_design_bulk_only|True|True|exact|—|PASS|
|D12|nested_budgets|[0, 2, 5]|[0, 2, 5]|exact|—|PASS|
|D12|cell4_paired_support|["soft", "hard"]|["soft", "hard"]|exact|—|PASS|
|D12|stream_unique|2000|2000|exact|—|PASS|
|D16|label_changed_files|["research/emc-part2b/prior_guided/FINITE_CALIBRATION_RESULTS.md", "research/emc-part2b/prior_guided/PRIOR_SENSITIVITY.md"]|["research/emc-part2b/prior_guided/FINITE_CALIBRATION_RESULTS.md", "research/emc-part2b/prior_guided/PRIOR_SENSITIVITY.md"]|exact|—|PASS|
|D16|label_direct_child|07b3488dfbc6513ad9172655bebe2566fbeaa205|07b3488dfbc6513ad9172655bebe2566fbeaa205|exact|—|PASS|
|D16|all_diff_scoped|True|True|exact|—|PASS|
|D16|source_excludes_old_parent_import|True|True|exact|—|PASS|
|D16|review_before_now|True|True|exact|—|PASS|
|D16|parent_hash|e23a58cebeb954776c45877af66ed129dc28eba7fc1f1683a2a6575093f7bab2|e23a58cebeb954776c45877af66ed129dc28eba7fc1f1683a2a6575093f7bab2|exact|—|PASS|
|D16|AST.phase_models.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.measurement_experiment.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.test_phase_models.py|parse_ok|parse_ok|exact|—|PASS|
|D16|AST.test_experiment.py|parse_ok|parse_ok|exact|—|PASS|
|D11|review_reject_STOP|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_PASS_WITH_NOTE|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_self_review|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_future|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_stale_design|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_stale_prereg|RuntimeError|RuntimeError|exact|—|PASS|
|D11|review_reject_missing_review_md|RuntimeError|RuntimeError|exact|—|PASS|
|D11|design_byte_reject_preregistration.json|RuntimeError|RuntimeError|exact|—|PASS|
|D11|design_byte_reject_MATHEMATICAL_DESIGN.md|RuntimeError|RuntimeError|exact|—|PASS|
|D11|restored_review_accept|qar-phase-prereg-v1|qar-phase-prereg-v1|exact|—|PASS|
|D11|seed_collision_reject|RuntimeError|RuntimeError|exact|—|PASS|
|D11|wall_cap_minutes|90|90|exact|—|PASS|
|D11|output_cap_MB|500|500|exact|—|PASS|
|D11|cpu_workers|2|2|exact|—|PASS|
|D11|actual_threads|True|True|exact|—|PASS|
|D11|original_data_csv_absent|True|True|exact|—|PASS|
|D11|run_results_absent|False|False|exact|—|PASS|
|D12|truth_read_functions|["score", "study_diagnostics"]|["score", "study_diagnostics"]|exact|—|PASS|
|D12|whole_unit_exclusion_branch|True|True|exact|—|PASS|
|D12|N_zero_update_branch|True|True|exact|—|PASS|
|D12|evaluation_only_bulk_branch|True|True|exact|—|PASS|
|D12|selection_fixed_prefix|True|True|exact|—|PASS|
|D12|no_pool_unpurchased_scoring|True|True|exact|—|PASS|
|D12|predictions_hash_before_truth|True|True|exact|—|PASS|
|D12|run_uses_distinct_observed_files|4|4|exact|—|PASS|

## Named evidence and limits

- `audit/checks.json`: D01–D16 certifications and post-run evidence paths; `manifests/pre_run_checks.json`: immutable pre-draw D01–D12/D16 snapshot.
- `audit/tester_oracle_results.json` and `audit/tester_preflight_results.json`: all 379 independent deterministic metric records, including malformed external covariance/prior rejection, objective/KKT, LP, LOO, frozen review/seed, and source-preservation checks.
- `audit/postrun_audit.json`: all 18,000 nonempty cohort rows independently recomputed for ten metrics, LP denominators, paired differences/SE, prior diagnostics, negative controls, and injected failure propagation. No problem recorded.
- `audit/selective_replay.json`: four current-source saved-observation cases including the old witness. Earlier correction-001 already established a complete byte replay under its own source; this replay tests the corrected source without gratuitously repeating 350,250 saved fits.
- `audit/postchecks_summary.json`, `audit/data_replay_hashes.json`, `manifests/{source,environment,seeds,freeze,execution,correction}.json`: lineage, freeze, counts, exact data hashes and timing. `results/diagnostics.json` records floor counts, learned-center variability and prior covariance summaries.

No tester source edits, simulation redesign, tolerance relaxation, additional random seeds, prior-package changes, commits, or pushes occurred. Final independent scientific review remains a separate downstream workflow stage.
