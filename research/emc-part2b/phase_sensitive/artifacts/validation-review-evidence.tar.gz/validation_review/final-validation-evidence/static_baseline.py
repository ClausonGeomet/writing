import json,subprocess
from pathlib import Path
repo=Path('/home/matt/Documents/GitHub/writing')
out=Path(__file__).resolve().parent
files=['research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py','research/emc-part2b/phase_sensitive/test_experiment_corrected.py']
result={}
for name in files:
 old=subprocess.check_output(['git','show','HEAD^:'+name],cwd=repo)
 current=(repo/name).read_bytes()
 def lint(data):
  p=subprocess.run(['/tmp/bif-v3-world1-validation-env-20261023/bin/python','-m','ruff','check','--output-format','json','--stdin-filename',name,'-'],input=data,cwd=repo,capture_output=True)
  assert p.returncode in (0,1),p.stderr.decode()
  return sorted((x['code'],x['message']) for x in json.loads(p.stdout))
 result[name]={'parent':lint(old),'current':lint(current)}
 assert result[name]['parent']==result[name]['current'],result[name]
(out/'static_baseline.json').write_text(json.dumps({'ruff':result,'mypy_note':'All five mypy errors occur in unchanged phase_models.py; no corrected-source error in mypy output.','verdict':'NO_NEW_STATIC_FINDINGS'},indent=2,sort_keys=True)+'\n')
print(json.dumps({name:len(value['current']) for name,value in result.items()},sort_keys=True))
