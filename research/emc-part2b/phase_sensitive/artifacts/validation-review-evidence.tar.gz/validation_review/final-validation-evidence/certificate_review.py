import hashlib,json
from pathlib import Path
run=Path('/tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive')
root=Path('/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive')
prior=run/'corrected-harness-evidence/full-certification'
current=run/'final-validation-evidence/full-certificate'
out=current.parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old_source,old_validation=load(prior/'source.json'),load(prior/'validation.json')
source,validation,start,hashes=[load(current/f'{name}.json') for name in ('source','validation','start','evidence-hashes')]
checks={
 'new_source_harness':source['additive_sources'][str(root/'measurement_experiment_corrected.py')]==sha(root/'measurement_experiment_corrected.py')=='2a95a0bc777603e003cade593c1fbf5e00d30b1ef6da5ea2446b8df891b374a2',
 'new_source_tests':source['additive_sources'][str(root/'test_experiment_corrected.py')]==sha(root/'test_experiment_corrected.py')=='97e0767e2f7e3d074a8162c99a05a0f56b4d37e8f431d6cf1933d0d4650c8128',
 'changed_identity':sha(current/'source.json')!=sha(prior/'source.json'),
 'historical_sources_same':source['historical_sources']==old_source['historical_sources'],
 'historical_manifests_same':source['historical_manifests']==old_source['historical_manifests'],
 'saved_inputs_results_same':source['saved_inputs_results']==old_source['saved_inputs_results'],
 'historical_environment_same':source['historical_environment_sha256']==old_source['historical_environment_sha256'],
 'current_environment_same':source['validation_environment']==old_source['validation_environment'],
 'design_digest_same':source['design_digest']==old_source['design_digest']=='7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad',
 'counts_same':validation['counts']==old_validation['counts']=={'acquisition':600,'bounds':42750,'cohort_metrics':21250,'diagnostics':1,'estimates':350250,'information':26250,'paired_summary':3050,'priors':7750},
 'pass':validation['verdict']=='PASS',
 'zero_draws':validation['draw_count']==validation['generator_calls']==start['draw_count']==start['generator_calls']==0,
 'tolerances_same':validation['tolerances']==old_validation['tolerances']=={'feasibility':1e-9,'mass_oracle_atol':1e-8,'normalized_kkt':1e-8,'saved_numeric_atol':1e-12,'saved_numeric_rtol':0},
 'new_binding':start['source_sha256']==validation['source_sha256']==sha(current/'source.json'),
 'evidence_hashes_valid':hashes['source_sha256']==sha(current/'source.json') and hashes['start_sha256']==sha(current/'start.json') and hashes['validation_sha256']==sha(current/'validation.json'),
 'historical_execution_same':validation['historical_execution_sha256']==old_validation['historical_execution_sha256'],
 'not_backdated':validation['historical_execution_utc']<validation['started_utc']<validation['ended_utc'],
 'prospective_deviation_disclosed':'absent before draw' in validation['process_deviation'],
}
assert all(checks.values()),checks
result={'checks':checks,'counts':validation['counts'],'source_sha256':sha(current/'source.json'),'validation_sha256':sha(current/'validation.json'),'evidence_hashes_sha256':sha(current/'evidence-hashes.json'),'started_utc':validation['started_utc'],'ended_utc':validation['ended_utc'],'verdict':'PASS'}
(out/'certificate_review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
