import csv, hashlib, json, os, sys
from pathlib import Path
root=Path('/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive')
run=root/'run/attempts/correction-002'
out=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import measurement_experiment_corrected as corrected
cfg=json.loads((root/'preregistration.json').read_text())
copy=out.parent/'corrected-harness-evidence/failed-score-copy'
original=corrected.records
removed=[]
def omitted(path,*,jsonlines=False):
 for row in original(path,jsonlines=jsonlines):
  if str(path).endswith('results/predictions.csv') and row['sample_id']=='ps1_s1_r1_eval_1' and row['arm']=='A2_P' and row['budget']=='5' and row['stratum']=='unmeasured':
   removed.append(row); continue
  yield row
corrected.records=omitted
actual_mask=corrected.masked_record({},[{'status':'ok'}]*29,30)
(out/'score-gate').mkdir(exist_ok=True)
result=corrected.score_saved(copy,cfg,corrected.ResourceGate(out/'score-gate'))
metrics=list(csv.DictReader((copy/'results/cohort_metrics.csv').open(newline='')))
paired=list(csv.DictReader((copy/'results/paired_summary.csv').open(newline='')))
block=[row for row in metrics if row['cell_id']=='1' and row['cohort_id']=='1' and row['support_group']=='full' and row['stage']=='2' and row['budget']=='5' and row['stratum']=='unmeasured']
affected=[row for row in paired if row['cell_id']=='1' and row['support_group']=='full' and row['stage']=='2' and row['budget']=='5' and row['stratum']=='unmeasured']
metadata=set(corrected.METADATA)
checks={
 'removed_exactly_one':len(removed)==1,
 'removed_was_success':len(removed)==1 and removed[0]['status']=='ok',
 'mask_30_29_1':all(actual_mask[k]==v for k,v in {'n_planned':30,'n_success':29,'n_failure':1,'status':'unavailable_matched_failure'}.items()),
 'scorer_counts':result.get('cohort_metrics')==21250 and result.get('paired_summary')==3050,
 'affected_13':len(block)==13,
 'all_affected_masked':len(block)==13 and all(row['status']=='unavailable_matched_failure' and row['n_planned']=='30' and row['n_success']==('29' if row['arm']=='A2_P' else '30') and row['n_failure']==('1' if row['arm']=='A2_P' else '0') and all(value=='' for key,value in row.items() if key not in metadata) for row in block),
 'unaffected_21237':len(metrics)-len(block)==21237,
 'paired_90_masked':len(affected)==90 and all(row['n_planned']=='50' and row['n_complete']=='49' and row['n_failed']=='1' and row['mean_difference']==' ' for row in [])
}
# The file stores null mean/SE as empty CSV values.
checks['paired_90_masked']=len(affected)==90 and all(row['n_planned']=='50' and row['n_complete']=='49' and row['n_failed']=='1' and row['mean_difference']=='' and row['descriptive_se']=='' for row in affected)
checks['unaffected_2960']=len(paired)-len(affected)==2960
base_metrics=list(csv.DictReader((run/'results/cohort_metrics.csv').open(newline='')))
base_paired=list(csv.DictReader((run/'results/paired_summary.csv').open(newline='')))
metric_keys=('cell_id','cohort_id','support_group','stage','budget','stratum','arm')
paired_keys=('cell_id','support_group','stage','budget','stratum','contrast','metric')
def key(row,fields): return tuple(row[field] for field in fields)
affected_metric_keys={key(row,metric_keys) for row in block}
affected_paired_keys={key(row,paired_keys) for row in affected}
checks['unaffected_metric_exact']=sum(1 for i,row in enumerate(metrics) if key(row,metric_keys) not in affected_metric_keys and row==base_metrics[i])==21237
checks['unaffected_paired_exact']=sum(1 for i,row in enumerate(paired) if key(row,paired_keys) not in affected_paired_keys and row==base_paired[i])==2960
assert all(checks.values()),checks
report={'source_sha256':hashlib.sha256((root/'measurement_experiment_corrected.py').read_bytes()).hexdigest(),'scorer_result':result,'masked_record':actual_mask,'removed_row':removed,'checks':checks,'affected_numeric_field_names':sorted(k for k in block[0] if k not in metadata),'verdict':'PASS'}
(out/'missing_row_probe.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':checks,'result':result,'verdict':'PASS'},sort_keys=True))
