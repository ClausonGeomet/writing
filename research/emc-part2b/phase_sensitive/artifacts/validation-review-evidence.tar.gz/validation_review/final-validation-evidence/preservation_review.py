import hashlib,json,os
from pathlib import Path
root=Path('/tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive')
out=root/'final-validation-evidence'
def load(path):return json.loads(path.read_text())
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
before,after=load(out/'preservation-before.json'),load(out/'preservation-after.json')
assert before==after
assert before['indexed_files']==before['actual_run_files']==116
assert before['archive_count']==6
assert before['index_sha256']=='2876fedc6ebc72a3c9f83874ab5f717f51c4259eea6d1824e03b93a9bd9973dd'
rb,ra=load(out/'runtime-preservation-before.json'),load(out/'runtime-preservation-after.json')
for name,digest in rb['files'].items():
 if name=='audit.md':continue
 assert ra['files'][name]==digest,(name,ra['files'].get(name),digest)
assert rb['files']['audit.md']==sha(root/'audit-followup.md')
old=load(out/'corrected-evidence-before.json')
now={str(p.relative_to(root)):sha(p) for p in sorted((root/'corrected-harness-evidence').rglob('*')) if p.is_file() and not p.is_symlink()}
assert old['files']==now
res={'run_files':116,'archives':6,'old_runtime_files_preserved':len(rb['files'])-1,'canonical_audit_history_preserved':rb['files']['audit.md']==sha(root/'audit-followup.md'),'corrected_evidence_files_preserved':len(now),'source_hashes':before['source_hashes'],'verdict':'PASS'}
(out/'preservation_review.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,sort_keys=True))
