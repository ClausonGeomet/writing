import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive')
run=Path('/tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive')
out=Path(__file__).resolve().parent
old=json.loads((run/'corrected-harness-evidence/inherited_relevance.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
originals={name:sha(root/name) for name in old['original_sources']}
prior_refs={name:sha(run/'followup-evidence'/name) for name in old['inherited_evidence_sha256']}
old_cert=run/'corrected-harness-evidence/full-certification'
old_cert_hashes={name:sha(old_cert/name) for name in ('source.json','validation.json','start.json','evidence-hashes.json')}
old_probe_hashes={name:sha(run/'corrected-harness-evidence'/name) for name in ('resource_probes.json','counterfeit_result.json','certificate_edges.json','identity_probes.json','independent_mass_oracle.json','scorer_saved_failure_probe.json','failed_block_produced.json','inherited_relevance.json','missing_required_probe.json')}
base=subprocess.check_output(['git','show','HEAD^:research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py'],cwd=root.parents[2])
current=(root/'measurement_experiment_corrected.py').read_bytes()
assert originals==old['original_sources']
assert prior_refs==old['inherited_evidence_sha256']
assert current.replace(b'failure = n - success  # Required rows absent from the block are failures too.',b'failure = sum(row.get("status") != "ok" for row in rows)')==base
assert sha(root/'measurement_experiment_corrected.py')=='2a95a0bc777603e003cade593c1fbf5e00d30b1ef6da5ea2446b8df891b374a2'
assert sha(root/'test_experiment_corrected.py')=='97e0767e2f7e3d074a8162c99a05a0f56b4d37e8f431d6cf1933d0d4650c8128'
res={'original_source_hashes':originals,'inherited_evidence_hashes':prior_refs,'old_certificate_hashes':old_cert_hashes,'old_probe_hashes':old_probe_hashes,'current_harness_sha256':sha(root/'measurement_experiment_corrected.py'),'current_test_sha256':sha(root/'test_experiment_corrected.py'),'exact_source_delta':'masked_record failure=sum(present non-ok) changed to n_planned minus n_success; no other executable statement changed','inherited_current_relevance':{'D01_D10_D12_D16':'Five historical executable sources and saved observations unchanged; 379 R1 named cases and independent source probes apply.','D05_D11_D14':'Resource, KKT, counterfeit, identity, present-failure masks, and valid-row scoring code unchanged except one missing-row accounting line. Changed missing-row path is freshly executed; full new-source certificate is separate.','D13_D15':'Original full key inventory, all-row independent mass oracle, numeric replay and original hashes remain valid as historical evidence; fresh full corrected certificate rechecks valid saved inputs under new source identity.'},'verdict':'PASS'}
(out/'relevance.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps({'verdict':'PASS','original_sources':len(originals),'inherited_evidence':len(prior_refs),'prior_probes':len(old_probe_hashes)},sort_keys=True))
