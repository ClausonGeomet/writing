# Source-only numerical correction

Builder commit: `a82f70d` (`builder: preserve symmetry in phase mean updates`). Only `phase_models.py` and `test_phase_models.py` changed in the isolated worktree. No study design, generator, harness, frozen parent code, data, results, or tolerance changed.

## Defect and correction

`update_mean` accumulated `P = P + A.T @ solve(V, A)` without restoring the symmetry of that mathematically symmetric information matrix. Floating point evaluation can make its off-diagonal entries differ by more than the unchanged `1e-12` input-validation limit. It then returned `status='ok'` with diagnostics that `_validate_prior` rejected in a later A1/A2 call.

Internally constructed symmetric matrices now use `(X + X.T) / 2` after their construction: calibration covariance components, initial information, within-unit marginal covariance, each mean-information update, updated mean covariance, update Hessian, prior precision, and assay Hessian. This removes antisymmetric roundoff only; it does not alter the declared covariance floor, shrinkage, objective, constraints, solver certificates, or any tolerance. Externally supplied covariance and prior matrices still pass through `_symmetric`, which checks the original entries against `1e-12` **before** symmetrizing and rejects substantive asymmetry.

## Focused validation

- Deterministic five-unit, full-covariance, high-information regression: updated prior has exactly symmetric information/covariance/precision; `P M` agrees with identity within `1e-12`; precision agrees with `U(T+M)^-1U'` within `1e-12`; A1, A2, and a chained empty update consume it successfully. The same test checks external covariance and prior information perturbed by `2e-12` are rejected.
- Focused pytest selection (initial prior, whole-unit exclusion, new regression): **3 passed**.
- `py_compile` on both modified Python files and `git diff --check`: passed.

The stochastic study was not run. The blocked correction attempt and its evidence remain for tester/leader correction lineage; they must independently recertify the changed source and issue a new source/environment freeze before any authorized same-seed attempt.
