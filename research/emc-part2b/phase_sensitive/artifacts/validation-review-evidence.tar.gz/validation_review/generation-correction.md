# Simulator generation correction — 2026-10-27

**Disposition:** source-only repair committed locally as `413e927cb3d3b48fecfdbc638eb32d88658c38e9`; no generation, freeze, or correction attempt was run in this worktree. Tester owns independent recertification and the actual retry.

## Cause and scope

The first authorized run failed in its first cohort after drawing but before any CSV or prediction: the R export loop called `get("calibration")`, whereas its truth matrix was named `cal`. The original run is retained at the main checkout's `research/emc-part2b/phase_sensitive/run`: `execution.json` has `status=blocked` and `first_draw_utc=2026-10-27T04:31:24.555170+00:00`; `generation_log.json` has R return code 1 and the exact missing-object error. There are zero data CSV files and no results directory. The initial execution, freeze, seeds, source, generation log, and predraw certification hashes were read without alteration.

Only `generation.R` and `test_experiment.py` changed. The export now receives explicit named `truths` and `observed` maps for calibration, direct, pool and evaluation. It preserves the existing truth calls, their order, all seed resets/noise calls, IDs, channel order, row order, and CSV writer. No design, configuration, model, prior, laboratory law, threshold, package, metric, or old-study file changed.

## Draw-free checks

- Fifteen focused `test_experiment.py` tests passed. The new R export test parses and executes only `append` and `export_cohort` with hand-constructed matrices; it checks all eight CSV headers, four IDs, mapped truth/observed values, and null unpurchased pool channels. It does not call the generator or draw a population.
- A correction-freeze fixture with a blocked base execution and no CSVs passed. It checked lineage hashes for the original execution and freeze, identical seed manifest, fresh source certificate, no automatic retry, and preservation of the original blocked ledger.
- R source parsed, `git diff --check` passed, and public `--check` passed with the unchanged reviewed design digest `7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad` and unchanged planned 350250 predictions.

## Provenance and required new certificate

The original source commit was `f26dc062eada723e45bb7c747488116e2add0684`. Its frozen `generation.R` SHA256 is `e1223964a2cc5ca87ea5ffa1e949b87bcaecd3e23515d1e7f56f2444f87ea1e9`; the repaired file is `16432637b16c4a72eb07ec340d08cc96910d2d3172285d503b18e96428066610`. Original `source.json` and `freeze.json` SHA256 are respectively `b32d07d4c097a79218fdb2afa97b92ba95d9157bb6d8815348e248ecd782f8c5` and `a343af49d1127ac8a9122cebe5cc520d398adfcee84daffbc70e30133b5f0737`. The original seed manifest SHA256 is `c759ec08ef7b2f7bb6ce497000dfabe783ec1d3c94ee880baadb16d2dfd1a195`; it has 2000 study seeds and zero recorded historical collisions. These original hashes must remain available in the initial attempt. The new attempt needs its **own** source/environment/seed manifest and freeze certificate after the merged commit. A source hash change is expected; a design or seed inventory change is not.

## Exact tester retry sequence after merge-back

Run from the main target repository root with the independently frozen Python environment and one-thread settings. Do not move, delete, or overwrite the initial run directory or its evidence.

First, tester must independently rerun the focused tests and D01–D12/D16 predraw checks after merge. The earlier 379 predraw metric rows and 21 focused tests are valid historical evidence, not a substitute for recertification after this source change. Then execute `--check` and `--freeze`:

```sh
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/emc-phase-mpl
PHASE_PY=/tmp/bif-v3-world1-validation-env-20261023/bin/python
PHASE_SCRIPT=research/emc-part2b/phase_sensitive/measurement_experiment.py
PHASE_CONFIG=research/emc-part2b/phase_sensitive/preregistration.json
PHASE_OUTPUT=research/emc-part2b/phase_sensitive/run
PHASE_REVIEW=research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json

$PHASE_PY "$PHASE_SCRIPT" --config "$PHASE_CONFIG" --output "$PHASE_OUTPUT" --review "$PHASE_REVIEW" --attempt correction-001 --check
$PHASE_PY "$PHASE_SCRIPT" --config "$PHASE_CONFIG" --output "$PHASE_OUTPUT" --review "$PHASE_REVIEW" --attempt correction-001 --correction-reason 'First-cohort R export used get("calibration") but the truth matrix is cal; replaced it with explicit named truth/observed maps, preserving design and seeds.' --freeze
```

After `--freeze`, inspect `run/attempts/correction-001/manifests/{source,environment,seeds,freeze,correction}.json`; check source and environment hashes, package pin, exact design digest, unchanged seed inventory, and the `base_execution_sha256`/`base_freeze_sha256` links. The harness initially writes only its simulator-preflight PASS and D13–D15 PENDING in the new attempt's `audit/checks.json`. Tester must write genuine **new-attempt** D01–D12/D16 PASS rows, with existing evidence files and actual/expected values, before `--run`. Do not copy the first attempt's PASS verdicts as new evidence or mark D13–D15 PASS before saved outputs exist.

Then the tester may run the one correction attempt:

```sh
$PHASE_PY "$PHASE_SCRIPT" --config "$PHASE_CONFIG" --output "$PHASE_OUTPUT" --review "$PHASE_REVIEW" --attempt correction-001 --run
```

The harness requires the preserved base execution to be blocked, reads its freeze and seeds for correction lineage, checks exact current source/environment/design/seed hashes and D01–D12/D16 certifications, snapshots those checks, and writes the new execution start ledger before invoking R. A first-cohort failure with no CSVs satisfies its existing correction-lineage preconditions; the draw-free fixture verified `freeze()` on that state. If execution completes, tester must perform saved-output D13–D15 checks and only then call `--verify` with the same arguments plus `--attempt correction-001 --verify`. No post-run check is reported as PASS here.
