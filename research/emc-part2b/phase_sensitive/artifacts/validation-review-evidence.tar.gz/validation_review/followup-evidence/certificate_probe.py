import csv,json,sys,shutil,hashlib,math,os
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'));RUN=ROOT/'run/attempts/correction-002';E=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import measurement_experiment as h,phase_models as m
# Highly correlated admissible SPD assay covariance, actual public estimate and independent KKT LP.
C=np.array([[1.,0,0],[0,1,1]])
R=np.array([[1e-4,0.9999e-4],[0.9999e-4,1e-4]])
y=np.array([.62,.39]);r=m.estimate(y,C,R,method='A0');mass=np.array(r['mass']);H=C.T@np.linalg.solve(R,C);f=C.T@np.linalg.solve(R,y);g=H@mass-f
active=[j for j in range(3) if mass[j]<=1e-9];mat=np.column_stack([np.ones(3)]+[-np.eye(3)[j] for j in active]);n_eq=1
A=np.vstack([np.column_stack((mat,-np.ones(3))),np.column_stack((-mat,-np.ones(3)))]);b=np.r_[-g,g]
w=linprog(np.r_[np.zeros(mat.shape[1]),1.],A_ub=A,b_ub=b,bounds=[(None,None)]*n_eq+[(0,None)]*len(active)+[(0,None)],method='highs')
scale=max(1.,np.linalg.norm(H,np.inf)*max(1.,np.linalg.norm(mass,np.inf))+np.linalg.norm(f,np.inf))
pert=mass+np.array([.01,-.01,0]);gp=H@pert-f
activep=[j for j in range(3) if pert[j]<=1e-9];matp=np.column_stack([np.ones(3)]+[-np.eye(3)[j] for j in activep]);Ap=np.vstack([np.column_stack((matp,-np.ones(3))),np.column_stack((-matp,-np.ones(3)))]);bp=np.r_[-gp,gp]
wp=linprog(np.r_[np.zeros(matp.shape[1]),1.],A_ub=Ap,b_ub=bp,bounds=[(None,None)]+[(0,None)]*len(activep)+[(0,None)],method='highs')
out={'cov_eigenvalues':np.linalg.eigvalsh(R).tolist(),'estimate_status':r['status'],'mass':mass.tolist(),'feasibility':r['constraint_violation'],'reported_kkt':r['kkt_residual'],'independent_normalized_kkt':float(w.x[-1]/scale) if w.success else None,'perturbed_mass':pert.tolist(),'perturbed_independent_normalized_kkt':float(wp.x[-1]/scale) if wp.success else None,'tolerances':{'feasibility':1e-9,'KKT':1e-8,'cov_min_eigenvalue':1e-12}}
# Audit copy of full final output, using immutable source files via symlink. Alter one success mass and update its output hash, as a false-success certificate challenge.
p=E/'fake-success-copy'
if p.exists():shutil.rmtree(p)
ex=json.loads((RUN/'manifests/execution.json').read_text())
for rel in ex['output_hashes']:
 dst=p/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if rel!='results/predictions.csv':
  (shutil.copyfile(RUN/rel,dst) if rel.startswith('audit/') else dst.symlink_to(RUN/rel))
for rel in ('audit/checks.json','audit/postchecks_summary.json','audit/postrun_audit.json','audit/selective_replay.json'):
 dst=p/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(RUN/rel,dst)
# Do not copy the whole 100 MB prediction CSV twice; use the existing injection copy and alter a mass there.
src=RUN/'results/predictions.csv';dst=p/'results/predictions.csv';changed=0
with src.open(newline='') as f,dst.open('w',newline='') as g:
 rd=csv.DictReader(f);wr=csv.DictWriter(g,fieldnames=rd.fieldnames);wr.writeheader()
 for z in rd:
  if z['sample_id']=='ps1_s1_r1_direct_1' and z['arm']=='A0_B' and z['support_group']=='full':
   z['status']='ok';z['Q_hat']='0.99';z['A_hat']='0.005';z['R_hat']='0.005';z['constraint_violation']='0';z['kkt_residual']='0';changed+=1
  wr.writerow(z)
assert changed==1
ex['output_hashes']['results/predictions.csv']=hashlib.sha256(dst.read_bytes()).hexdigest()
(p/'manifests/execution.json').write_text(json.dumps(ex,indent=2,sort_keys=True)+'\n')
cfg=json.loads((ROOT/'preregistration.json').read_text());q=json.loads((ROOT/'PREEXECUTION_REVIEW.json').read_text());freeze=json.loads((ROOT/'design_freeze.json').read_text())
try:out['fake_success_verify_result']=h.verify(p,cfg,q,freeze)
except Exception as err:out['fake_success_verify_result']={'exception':type(err).__name__,'message':str(err)}
out['fake_success_changed_rows']=changed
with (RUN/'data/direct_observed.csv').open(newline='') as f:
 obs=next(z for z in csv.DictReader(f) if z['sample_id']=='ps1_s1_r1_direct_1')
y0=np.array([float(obs[z]) for z in ('SiO2','TiO2')]);fake=np.array([.99,.005,.005]);original=np.array([.6084283161321855,.19578584193390733,.19578584193390733]);cov0=np.array([[1e-4,3e-5],[3e-5,1e-4]])
g0=C.T@np.linalg.solve(cov0,C@fake-y0)
def objective(a):return .5*(C@a-y0)@np.linalg.solve(cov0,C@a-y0)
out.update({'fake_success_original_bulk_y':y0.tolist(),'fake_success_objective':float(objective(fake)),'original_objective':float(objective(original)),'fake_directional_derivative_toward_original':float(g0@(original-fake)),'fake_mass':fake.tolist(),'fake_status':'ok','fake_reported_kkt':0})
(E/'certificate_rejection.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ('estimate_status','independent_normalized_kkt','perturbed_independent_normalized_kkt','fake_success_verify_result')}))
