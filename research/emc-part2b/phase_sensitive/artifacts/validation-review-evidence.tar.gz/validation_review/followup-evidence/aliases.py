import csv,json,os
from pathlib import Path
R=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))/'run/attempts/correction-002';E=Path(__file__).resolve().parent
blocks={};errors=[];pairs=0
with (R/'results/predictions.csv').open(newline='') as f:
 for x in csv.DictReader(f):
  if x['stage']!='2' or x['stratum']!='unmeasured':continue
  k=tuple(x[z] for z in ('cell_id','cohort_id','support_group','budget','sample_id'));blocks.setdefault(k,{})[x['arm']]=tuple(x[z] for z in ('Q_hat','A_hat','R_hat'))
for k,b in blocks.items():
 for arms in (('A0_B','A0_R','A0_P'),('A2_N','A2_R0','A2_P0')):
  pairs+=1
  if len({b[a] for a in arms})!=1:errors.append([k,arms])
out={'unmeasured_unit_budget_blocks':len(blocks),'alias_triplets_compared':pairs,'nonidentical_triplets':len(errors),'examples':errors[:5],'tolerance':'exact CSV values'}
(E/'negative_controls.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
