import json,sys,shutil,time,copy,os
from pathlib import Path
from unittest.mock import patch
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'));RUN=ROOT/'run/attempts/correction-002';E=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import measurement_experiment as m
cfg=json.loads((ROOT/'preregistration.json').read_text());q=json.loads((ROOT/'PREEXECUTION_REVIEW.json').read_text());f=json.loads((ROOT/'design_freeze.json').read_text())
source=json.loads((RUN/'manifests/source.json').read_text());env=json.loads((RUN/'manifests/environment.json').read_text());seed=json.loads((RUN/'manifests/seeds.json').read_text())
results=[]
def fixture(name):
 p=E/'gate-fixtures'/name
 if p.exists():shutil.rmtree(p)
 (p/'manifests').mkdir(parents=True);(p/'audit').mkdir()
 for z in ('freeze','source','environment','seeds'):
  shutil.copyfile(RUN/'manifests'/f'{z}.json',p/'manifests'/f'{z}.json')
 shutil.copyfile(RUN/'manifests/pre_run_checks.json',p/'audit/checks.json')
 for z in ('tester_preflight_results','tester_oracle_results'):
  shutil.copyfile(RUN/'audit'/f'{z}.json',p/'audit'/f'{z}.json')
 return p
class DrawTrap(Exception): pass
class RunRecorder:
 def __init__(self):self.calls=0
 def __call__(self,*a,**kw):self.calls+=1;raise DrawTrap('sampling-capable subprocess trapped')
def case(name,mutate=None,patch_source=None,patch_env=None,config=None,gate=False):
 p=fixture(name);mutate and mutate(p)
 trap=RunRecorder();a=copy.deepcopy(source if patch_source is None else patch_source);b=copy.deepcopy(env if patch_env is None else patch_env)
 try:
  with patch.object(m,'complete_source_manifest',return_value=a),patch.object(m,'environment',return_value=b),patch.object(m,'seed_manifest',return_value=seed),patch.object(m.subprocess,'run',side_effect=trap):
   if gate:m.design_gate(config or ROOT/'preregistration.json',ROOT/'PREEXECUTION_REVIEW.json')
   else:m.execute(p,cfg,q,f)
  status='accepted'
 except Exception as ex:status=f'{type(ex).__name__}: {ex}'
 results.append({'case':name,'expected':'reject before generation','actual':status,'sampling_subprocess_calls':trap.calls,'pass':status!='accepted' and trap.calls==0})

def changed_record(record,path):
 x=copy.deepcopy(record);where=x
 for part in path[:-1]:where=where[part]
 value=where[path[-1]]
 if isinstance(value,dict):
  first=next(iter(value));value[first]=str(value[first])+'-AUDIT-MUTATION'
 else:where[path[-1]]=str(value)+'-AUDIT-MUTATION'
 return x
case('changed_source',patch_source=changed_record(source,['files','research/emc-part2b/phase_sensitive/measurement_experiment.py']))
for name,path in [('numpy',['packages','numpy']),('matplotlib',['packages','matplotlib']),('R',['R','R'])]:
 try:b=changed_record(env,path)
 except (KeyError,TypeError):b={**env,'audit_mutation_'+name:True}
 case('changed_'+name,patch_env=b)
case('missing_environment',mutate=lambda p:(p/'manifests/environment.json').unlink())
case('occupied_output',mutate=lambda p:(p/'data').mkdir())
case('invalid_config_path',config=E/'invalid-preregistration.json',gate=True)
# Adverse elapsed-time and output-size fixtures; the generation call must remain trapped.
def cap_case(name, mutate=None, elapsed=False):
 p=fixture(name);mutate and mutate(p);trap=RunRecorder()
 try:
  with patch.object(m,'complete_source_manifest',return_value=source),patch.object(m,'environment',return_value=env),patch.object(m,'seed_manifest',return_value=seed),patch.object(m.subprocess,'run',side_effect=trap):
   if elapsed:
    with patch.object(m.time,'monotonic',side_effect=[0.,6000.]):m.execute(p,cfg,q,f)
   else:m.execute(p,cfg,q,f)
  status='accepted'
 except Exception as ex:status=f'{type(ex).__name__}: {ex}'
 results.append({'case':name,'expected':'cap rejection before generation','actual':status,'sampling_subprocess_calls':trap.calls,'pass':status!='accepted' and trap.calls==0})
cap_case('elapsed_6000_seconds',elapsed=True)
def oversize(p):
 with (p/'audit/oversize.bin').open('wb') as f:f.truncate(501_000_000)
cap_case('output_501MB_before_draw',mutate=oversize)
(E/'gate_matrix.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
print(json.dumps(results,indent=2))
