import csv,json,sys,time,shutil,builtins,hashlib,os
from pathlib import Path
from unittest.mock import patch
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'));RUN=ROOT/'run/attempts/correction-002';E=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import measurement_experiment as m,phase_models as model
class StopAfterFirst(Exception):pass

def one(label,truth_files=False,pool_delta=0):
 out=E/'dataflow-fixtures'/label
 if out.exists():shutil.rmtree(out)
 (out/'data').mkdir(parents=True);(out/'results').mkdir()
 for kind in ('calibration','direct','pool','evaluation'):
  src=RUN/'data'/f'{kind}_observed.csv';dst=out/'data'/src.name
  if kind!='pool' or not pool_delta:dst.symlink_to(src)
  else:
   with src.open(newline='') as f, dst.open('w',newline='') as g:
    rd=csv.DictReader(f);wr=csv.DictWriter(g,fieldnames=rd.fieldnames);wr.writeheader()
    for x in rd:
     if x['sample_id']=='ps1_s1_r1_pool_1':
      for z,offset in {'SiO2':3,'TiO2':-2,'rep_SiO2':4,'rep_TiO2':-1,'QXRD_Q':2,'QXRD_A':8,'QXRD_R':-4}.items():
       x[z]=str(float(x[z])+pool_delta*offset)
     wr.writerow(x)
 if truth_files:
  for kind in ('direct','pool','evaluation'):(out/'data'/f'{kind}_truth.csv').write_text('INJECTED_BAD_TRUTH\n')
 calls=[];original_fit=model.fit_initial;original_update=model.update_mean
 def fit(*a,**kw):
  if calls and any(z['event']=='initial' for z in calls):raise StopAfterFirst
  calls.append({'event':'initial'});return original_fit(*a,**kw)
 def update(prior,units,*,support,exclude_unit=None):
  ids=[z['unit_id'] for z in units];p=original_update(prior,units,support=support,exclude_unit=exclude_unit)
  calls.append({'event':'update','ids':ids,'excluded':exclude_unit,'included':p['diagnostics']['included_unit_ids'],'n_update':p['diagnostics']['n_update'],'center':p['center']})
  return p
 orig_open=Path.open;reads=[]
 def guarded(self,*a,**kw):
  if self.name.endswith('_truth.csv'):reads.append(str(self));raise AssertionError('truth opened during prediction')
  return orig_open(self,*a,**kw)
 try:
  with patch.object(model,'fit_initial',side_effect=fit),patch.object(model,'update_mean',side_effect=update),patch.object(Path,'open',new=guarded):m.run_predictions(out,{'cells':[{'cell_id':1,'center_support':[True,True,True],'support_groups':['full'],'strength':1}]},time.monotonic()+600)
 except StopAfterFirst:pass
 ps=out/'results/predictions.csv';pred=ps.read_bytes();pr=(out/'results/priors.jsonl').read_bytes();acq=(out/'results/acquisition.csv').read_bytes()
 return {'prediction_sha256':hashlib.sha256(pred).hexdigest(),'prior_sha256':hashlib.sha256(pr).hexdigest(),'acquisition_sha256':hashlib.sha256(acq).hexdigest(),'prediction_rows':sum(1 for _ in ps.open())-1,'truth_reads':reads,'calls':calls}
base=one('no_truth');truth=one('poison_truth',True);changed=one('changed_pool',False,0.01)
# Compare exact prior centers for purchased pool_1 at k=2, full P; its own LOO excludes the entire stack.
def select(x,mode,ids,excluded):
 return next(z for z in x['calls'] if z.get('event')=='update' and z['ids']==ids and z['excluded']==excluded and x['calls'].index(z)>=0)
# mode disambiguation via order: at k2 there are B, R, P triplets; use last matching entry.
ids=['ps1_s1_r1_pool_1','ps1_s1_r1_pool_2']
for x in (base,truth,changed):
 x['k2_update_calls']=[z for z in x['calls'] if z.get('ids')==ids]
 x.pop('calls')
all0=base['k2_update_calls'][-3];loo0=base['k2_update_calls'][-2]
all1=changed['k2_update_calls'][-3];loo1=changed['k2_update_calls'][-2]
out={'baseline':base,'poison_truth':truth,'changed_pool':changed,'truth_prediction_equal':base['prediction_sha256']==truth['prediction_sha256'],'truth_prior_equal':base['prior_sha256']==truth['prior_sha256'],'truth_acquisition_equal':base['acquisition_sha256']==truth['acquisition_sha256'],'allowed_pool_changes_all_prior':all0['center']!=all1['center'],'excluded_own_whole_stack_prior_equal':loo0['center']==loo1['center'],'first_k2_ids':ids,'unmeasured_bulk_only_from_first_cohort':None}
# All unmeasured rows in first cohort use B design, including R0/P0 negative controls.
with (E/'dataflow-fixtures/no_truth/results/predictions.csv').open(newline='') as f:
 rr=[z for z in csv.DictReader(f) if z['stratum']=='unmeasured'];out['unmeasured_bulk_only_from_first_cohort']=all(z['observation_design_id'].startswith('B_') for z in rr)
def target(name,arm):
 with (E/'dataflow-fixtures'/name/'results/predictions.csv').open(newline='') as f:
  return next(z for z in csv.DictReader(f) if z['stage']=='2' and z['budget']=='2' and z['stratum']=='measured' and z['sample_id']=='ps1_s1_r1_pool_1' and z['arm']==arm)
for arm in ('A1_P','A2_P','A1_B','A2_B'):
 a,b=target('no_truth',arm),target('changed_pool',arm)
 out.setdefault('measured_target_changes',{})[arm]={'prior_id_same':a['prior_id']==b['prior_id'],'prior_id':a['prior_id'],'mass_same':tuple(a[z] for z in ('Q_hat','A_hat','R_hat'))==tuple(b[z] for z in ('Q_hat','A_hat','R_hat')),'baseline_mass':[a[z] for z in ('Q_hat','A_hat','R_hat')],'changed_mass':[b[z] for z in ('Q_hat','A_hat','R_hat')]}
(E/'dataflow_sentinels.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if not isinstance(v,dict)}))
