import csv,json,sys,math,os
from pathlib import Path
from collections import defaultdict
import numpy as np
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))/'run/attempts/correction-002'
E=Path(__file__).resolve().parent

def rows(p):
 with open(p,newline='') as f:return list(csv.DictReader(f))
def report(name,x): (E/name).write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def diff(a,b):
 if a is None or b is None:return 0 if a==b else float('inf')
 return float(np.max(np.abs(np.asarray(a,float)-np.asarray(b,float))))
pr=[json.loads(x) for x in (ROOT/'results/priors.jsonl').read_text().splitlines()]
D=json.loads((ROOT/'results/diagnostics.json').read_text())
U=np.array([[2/np.sqrt(6),0],[-1/np.sqrt(6),1/np.sqrt(2)],[-1/np.sqrt(6),-1/np.sqrt(2)]])
centers=defaultdict(list); initial=[];TE=[];ME=[];TD=[];MD=[];COR=[];floor=0
for x in pr:
 p=x['prior'];assert p['status']=='ok'
 T=np.array(p['tangent_cov']);M=np.array(p['mean_cov']);phys=U@T@U.T
 TE.append(np.linalg.eigvalsh(T));ME.append(np.linalg.eigvalsh(M));TD.append(np.diag(phys));MD.append(np.diag(U@M@U.T));COR.append(phys[1,2]/math.sqrt(phys[1,1]*phys[2,2]))
 if x['update']=='initial':
  initial.append(x);centers[f"{x['cell_id']}:{x['support_group']}"].append(p['center'])
  d=p['diagnostics'];floor+=sum(a<b for a,b in zip(d['deconvolved_eigenvalues'],d['floored_eigenvalues']))
calc={'successful_prior_records':len(pr),'initial_prior_count':len(initial),'calibration_floor_eigenvalue_count':floor,'learned_center_sd_by_cell_support':{k:np.std(v,axis=0,ddof=1).tolist() for k,v in centers.items()},'mean_T_eigenvalues':np.mean(TE,axis=0).tolist(),'mean_M_eigenvalues':np.mean(ME,axis=0).tolist(),'mean_T_physical_diagonal':np.mean(TD,axis=0).tolist(),'mean_M_physical_diagonal':np.mean(MD,axis=0).tolist(),'mean_learned_A_R_correlation':float(np.mean(COR))}
truth={}
for kind in ('calibration','evaluation'):
 G=defaultdict(list)
 for x in rows(ROOT/'data'/f'{kind}_truth.csv'):G[(int(x['cell_id']),int(x['cohort_id']))].append([float(x[z]) for z in 'QAR'])
 truth[kind]={k:np.mean(v,axis=0) for k,v in G.items()}
retro=[]
for x in initial:
 s=x['cell_id'];r=x['cohort_id'];g=x['support_group'];c=np.array(x['prior']['center'])
 for kind in ('calibration','evaluation'):
  retro.append({'cell_id':s,'cohort_id':r,'support_group':g,'population':kind,'center_minus_latent_mean':(c-truth[kind][(s,r)]).tolist()})
calc['retrospective_center_errors']=retro
checks={k:{'max_abs_diff':(0 if isinstance(calc[k],dict) else diff(calc[k],D[k])),'expected':D[k] if k in ('initial_prior_count','successful_prior_records','calibration_floor_eigenvalue_count') else 'saved diagnostics','actual':calc[k] if k in ('initial_prior_count','successful_prior_records','calibration_floor_eigenvalue_count') else 'independent recomputation'} for k in calc if k!='retrospective_center_errors'}
old={(x['cell_id'],x['cohort_id'],x['support_group'],x['population']):x['center_minus_latent_mean'] for x in D['retrospective_center_errors']}
checks['retrospective_center_errors']={'rows':len(retro),'saved_rows':len(old),'max_abs_diff':max(diff(x['center_minus_latent_mean'],old[(x['cell_id'],x['cohort_id'],x['support_group'],x['population'])]) for x in retro)}
for k,v in checks.items():
 if k=='learned_center_sd_by_cell_support':v['max_abs_diff']=max(diff(calc[k][q],D[k][q]) for q in calc[k])
checks['tolerance']={'all_numeric':'atol=1e-12,rtol=0','counts':'exact'}
report('diagnostics_recomputation.json',checks)
# Own-channel RMSE over every nonempty arm-cohort; direct saved per-prediction SSE and n are independently recomputed from observed channel vectors.
obs={}
for kind in ('direct','pool','evaluation'):
 for x in rows(ROOT/'data'/f'{kind}_observed.csv'):obs[x['sample_id']]=x
P=defaultdict(list)
for x in rows(ROOT/'results/predictions.csv'):
 k=tuple(x[z] for z in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm'));P[k].append(x)
M=rows(ROOT/'results/cohort_metrics.csv');n=0;maxdiff=0;bad=[];null=0
for x in M:
 if x['status']!='ok':continue
 k=tuple(x[z] for z in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm'))
 rr=P[k];sse=0;cnt=0
 for p in rr:
  if p['measurement_design_n']=='':continue
  o=obs[p['sample_id']];h=np.array([float(p[z]) for z in ('Q_hat','A_hat','R_hat')]);mode=p['observation_design_id'].split('_',1)[0]
  if p['stage']=='1':
   d=np.array([[1,0,0],[0,1,1],[0,1,1],[0,1,0]])
   v=np.array([float(o[z]) for z in ('SiO2','TiO2','redundant_Ti','H_A')]);inds={'B':[0,1],'T':[0,1,2],'H':[0,1,3]}[mode];err=d[inds]@h-v[inds]
  elif mode=='B':err=np.array([h[0]-float(o['SiO2']),h[1]+h[2]-float(o['TiO2'])])
  elif mode=='R':err=np.array([h[0]-float(o['SiO2']),h[1]+h[2]-float(o['TiO2']),h[0]-float(o['rep_SiO2']),h[1]+h[2]-float(o['rep_TiO2'])])
  else:err=np.array([h[0]-float(o['SiO2']),h[1]+h[2]-float(o['TiO2']),*[h[j]-float(o[z]) for j,z in enumerate(('QXRD_Q','QXRD_A','QXRD_R'))]])
  sse+=float(err@err);cnt+=len(err)
  if int(p['measurement_design_n'])!=len(err) or abs(float(p['measurement_design_sse'])-float(err@err))>1e-12:bad.append(k)
 expected=math.sqrt(sse/cnt) if cnt else None;actual=float(x['measurement_design_RMSE_observed']) if x['measurement_design_RMSE_observed'] else None
 if expected is None:null+=1
 else:
  n+=1;maxdiff=max(maxdiff,abs(expected-actual))
  if abs(expected-actual)>1e-12:bad.append(k)
report('own_channel_rmse.json',{'numeric_rows':n,'null_A1_rows':null,'max_abs_diff':maxdiff,'bad_count':len(bad),'bad_examples':bad[:5],'tolerance':'atol=1e-12,rtol=0'})
print(json.dumps({'diagnostics_max':max(v.get('max_abs_diff',0) for v in checks.values() if isinstance(v,dict)),'own_channel_max':maxdiff,'own_channel_rows':n,'bad':len(bad)}))
