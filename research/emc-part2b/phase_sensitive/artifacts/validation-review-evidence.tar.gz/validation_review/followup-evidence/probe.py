import csv, json, sys, hashlib, time, math, shutil, os
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002'
E=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment as m

def rows(p):
    with open(p,newline='') as f: return list(csv.DictReader(f))
def writej(name,obj): (E/name).write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n')
def key(p): return tuple(p[x] for x in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm','sample_id'))
def pkey(p): return (str(p['cell_id']),str(p['cohort_id']),p['support_group'],p['prior_id'])
def close(a,b,tol=1e-12): return abs(a-b)<=tol

# Audit-owned score copy: only prediction CSV is modified. Truth/bounds are read-only symlinks.
def failure_injection():
    copy=E/'score-copy'; (copy/'data').mkdir(parents=True,exist_ok=True); (copy/'results').mkdir(exist_ok=True)
    for kind in ('direct','pool','evaluation'):
      for suffix in ('truth','observed'):
        target=RUN/'data'/f'{kind}_{suffix}.csv'; link=copy/'data'/target.name
        if not link.exists(): link.symlink_to(target)
    link=copy/'results/bounds.csv'
    if not link.exists(): link.symlink_to(RUN/'results/bounds.csv')
    src=RUN/'results/predictions.csv'; dst=copy/'results/predictions.csv'
    injected=('1','1','full','2','5','unmeasured','A2_P','ps1_s1_r1_eval_1')
    changed=0
    with src.open(newline='') as f, dst.open('w',newline='') as g:
      rd=csv.DictReader(f); wr=csv.DictWriter(g,fieldnames=rd.fieldnames);wr.writeheader()
      for x in rd:
        if key(x)==injected:
          assert x['status']=='ok';x['status']='numerical_failure';x['reason']='audit copy injected failure';changed+=1
        wr.writerow(x)
    assert changed==1
    result=m.score(copy,time.monotonic()+600)
    actual=rows(copy/'results/cohort_metrics.csv'); orig=rows(RUN/'results/cohort_metrics.csv')
    base=('1','1','full','2','5','unmeasured')
    affected=[x for x in actual if tuple(x[z] for z in ('cell_id','cohort_id','support_group','stage','budget','stratum'))==base]
    origmap={tuple(x.items()):1 for x in []}
    lookup={tuple(x[z] for z in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm')):x for x in orig}
    unchanged=sum(x==lookup[tuple(x[z] for z in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm'))] for x in actual if x not in affected)
    total_unaffected=len(actual)-13
    summ=rows(copy/'results/paired_summary.csv'); asumm=[x for x in summ if all(x[z]==v for z,v in zip(('cell_id','support_group','stage','budget','stratum'),('1','full','2','5','unmeasured')))]
    other=rows(RUN/'results/paired_summary.csv'); omap={tuple(x[z] for z in ('cell_id','support_group','stage','budget','stratum','contrast','metric')):x for x in other}
    unaffected_summary=sum(x==omap[tuple(x[z] for z in ('cell_id','support_group','stage','budget','stratum','contrast','metric'))] for x in summ if x not in asumm)
    out={'injected_key':injected,'changed_predictions':changed,'production_score_return':result,'affected_arms':[{z:x[z] for z in ('arm','status','n_planned','n_success','n_failure')} for x in affected], 'affected_metric_null_counts':{v:sum(x[v]=='' for x in affected) for v in m.METRICS},'affected_contrasts':len(asumm),'contrast_counts':{str(k):v for k,v in Counter((x['n_planned'],x['n_complete'],x['n_failed'],x['mean_difference'],x['descriptive_se']) for x in asumm).items()},'unaffected_metric_rows_identical':unchanged,'unaffected_metric_rows_total':total_unaffected,'unaffected_summary_rows_identical':unaffected_summary,'unaffected_summary_rows_total':len(summ)-len(asumm)}
    out['affected_extra_numeric_fields']={k:{'non_null':sum(z[k]!='' for z in affected),'example':next((z[k] for z in affected if z[k]!=''),'')} for k in ('measurement_design_RMSE_observed','n_envelope_nonempty','n_envelope_infeasible','mean_width_Q','mean_width_A','mean_width_R')}
    writej('production_score_injection.json',out)
    return out

# Prospective formula reconstructed now, explicitly retrospective evidence.
def inventory():
    preds=rows(RUN/'results/predictions.csv'); pri=[json.loads(x) for x in (RUN/'results/priors.jsonl').read_text().splitlines()]; acq=rows(RUN/'results/acquisition.csv')
    obs={k:rows(RUN/'data'/f'{k}_observed.csv') for k in ('calibration','direct','pool','evaluation')}
    exp_pred=set();exp_prior=set();expected_prov={}; exp_acq={}
    for s in range(1,5):
      for r in range(1,51):
        pools=[f'ps1_s{s}_r{r}_pool_{i}' for i in range(1,11)]
        for k in (0,2,5): exp_acq[(str(s),str(r),str(k))]={'purchased_ids':'|'.join(pools[:k]),'n_calibration_QXRD':'20','n_pool_base_bulk':str(k),'n_replicate_bulk':str(k),'n_pool_QXRD':str(k),'coverage_pool':str(k/10)}
        for group in (('soft','hard') if s==4 else ('full',)):
          pref=f'ps1_s{s}_r{r}_{group}'
          initial=f'{pref}_initial';exp_prior.add((str(s),str(r),group,initial));expected_prov[initial]=([],None)
          for k in (0,2,5):
            for mode in ('B','R','P'):
              for exclude in [None]+pools[:k]:
                pid=f"{pref}_{mode}_k{k}_{exclude or 'all'}";exp_prior.add((str(s),str(r),group,pid));expected_prov[pid]=([x for x in pools[:k] if x!=exclude],exclude)
          for i in range(1,21):
            sample=f'ps1_s{s}_r{r}_direct_{i}'
            for arm in m.ARMS1: exp_pred.add((str(s),str(r),group,'1','-1','direct',arm,sample))
          for k in (0,2,5):
            for stratum,n,kind in (('unmeasured',30,'eval'),('measured',k,'pool')):
              for i in range(1,n+1):
                sample=f'ps1_s{s}_r{r}_{kind}_{i}'
                for arm in m.ARMS2: exp_pred.add((str(s),str(r),group,'2',str(k),stratum,arm,sample))
    act_pred=[key(x) for x in preds]; act_prior=[pkey(x) for x in pri]
    prov=[]
    for x in pri:
      pid=x['prior_id']; expected=expected_prov.get(pid)
      d=x['prior']['diagnostics']; got=(d['included_unit_ids'],d['excluded_unit_id'])
      if expected is None or got!=(expected[0],expected[1]) or x['excluded_unit']!=expected[1] or d['n_update']!=len(expected[0]):prov.append({'prior_id':pid,'expected':expected,'actual':got,'n_update':d['n_update']})
    predprov=[]
    prior_ids=set(expected_prov)
    for x in preds:
      s,r,g,stage,k,st,arm,sample=key(x); pid=x['prior_id'];did=x['observation_design_id']
      expected=None
      if arm.startswith('A0'): expected=''
      elif stage=='1':expected=f'ps1_s{s}_r{r}_{g}_initial'
      else:
        tag=arm.split('_',1)[1]; mode='N' if tag=='N' or tag.endswith('0') else tag
        if mode=='N': expected=f'ps1_s{s}_r{r}_{g}_initial'
        else:expected=f"ps1_s{s}_r{r}_{g}_{mode}_k{k}_{sample if st=='measured' else 'all'}"
      local='B' if stage=='2' and (st=='unmeasured' or arm.endswith('_N')) else (arm[-1] if stage=='1' and arm!='A1' else ('B' if stage=='1' else arm.split('_',1)[1][0]))
      if stage=='2' and st=='measured' and arm in ('A2_R0','A2_P0'): local=arm[3]
      edid=f'{local}_{sample}_{g}'
      if pid!=expected or did!=edid: predprov.append({'key':key(x),'expected_prior':expected,'actual_prior':pid,'expected_design':edid,'actual_design':did})
    acqerr=[]
    for x in acq:
      z=exp_acq[(x['cell_id'],x['cohort_id'],x['budget'])]
      if any(x[a]!=v for a,v in z.items()):acqerr.append({'key':(x['cell_id'],x['cohort_id'],x['budget']),'expected':z,'actual':x})
    ids={k:[x['sample_id'] for x in v] for k,v in obs.items()};allids=[i for v in ids.values() for i in v]
    out={'expected_prediction_keys':len(exp_pred),'actual_prediction_rows':len(preds),'duplicate_prediction_keys':len(preds)-len(set(act_pred)),'missing_prediction_keys':list(exp_pred-set(act_pred))[:10],'extra_prediction_keys':list(set(act_pred)-exp_pred)[:10], 'expected_prior_keys':len(exp_prior),'actual_prior_rows':len(pri),'duplicate_prior_keys':len(pri)-len(set(act_prior)),'missing_prior_keys':list(exp_prior-set(act_prior))[:10],'extra_prior_keys':list(set(act_prior)-exp_prior)[:10],'prior_provenance_errors':prov[:10],'prior_provenance_error_count':len(prov),'prediction_routing_errors':predprov[:10],'prediction_routing_error_count':len(predprov),'acquisition_rows':len(acq),'expected_acquisition_rows':len(exp_acq),'acquisition_errors':acqerr[:10],'acquisition_error_count':len(acqerr),'observed_stream_counts':{k:len(v) for k,v in ids.items()},'unique_specimens':len(set(allids)),'cross_stream_duplicate_specimens':len(allids)-len(set(allids)),'prospective_detailed_key_inventory':False,'deviation':'Detailed expected key and prior/update instance list reconstructed retrospectively on follow-up; pre-draw manifest held aggregate counts only.'}
    writej('retrospective_inventory.json',out);return out

if __name__=='__main__':
  print('scorer',failure_injection()['production_score_return'])
  print('inventory',inventory()['prediction_routing_error_count'])
