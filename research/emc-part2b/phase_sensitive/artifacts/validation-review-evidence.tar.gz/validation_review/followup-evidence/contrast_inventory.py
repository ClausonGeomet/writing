import csv,json,sys,os
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'));RUN=ROOT/'run/attempts/correction-002';E=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import measurement_experiment as m
expected=set()
for s in range(1,5):
 for group in (('soft','hard') if s==4 else ('full',)):
  for stage,budget,stratum,contrasts in [(1,-1,'direct',m.CONTRASTS1)]+[(2,k,st,m.CONTRASTS2) for k in (0,2,5) for st in ('unmeasured','measured')]:
   for c in contrasts:
    for metric in m.METRICS:expected.add((str(s),group,str(stage),str(budget),stratum,c,metric))
with (RUN/'results/paired_summary.csv').open(newline='') as f:actual=list(csv.DictReader(f))
keys=[tuple(z[x] for x in ('cell_id','support_group','stage','budget','stratum','contrast','metric')) for z in actual]
errors=[z for z in actual if z['n_planned']!='50' or (z['stratum']!='measured' or z['budget']!='0') and (z['n_complete']!='50' or z['n_failed']!='0') or (z['stratum']=='measured' and z['budget']=='0' and (z['n_complete']!='0' or z['n_failed']!='50' or z['mean_difference']!='' or z['descriptive_se']!=''))]
out={'expected_keys':len(expected),'actual_rows':len(actual),'duplicate_keys':len(actual)-len(set(keys)),'missing_keys':list(expected-set(keys))[:10],'extra_keys':list(set(keys)-expected)[:10],'denominator_or_null_errors':len(errors),'examples':errors[:3]}
(E/'contrast_inventory.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out)
