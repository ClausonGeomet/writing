import os,csv,json,hashlib,sys
from pathlib import Path
import numpy as np
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
def readcsv(p):
 with p.open(newline='') as f:yield from csv.DictReader(f)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
obs={x['sample_id']:x for kind in ('direct','pool','evaluation') for x in readcsv(RUN/f'data/{kind}_observed.csv')}
priors={x['prior_id']:x['prior'] for x in (json.loads(line) for line in (RUN/'results/priors.jsonl').read_text().splitlines())}
C=np.array([[1.,0,0],[0,1,1]])
D4=np.vstack((C,C[1],np.array([0.,1.,0.])))
R4=np.diag([.01,.01,.01,.02])@np.array([[1,.3,0,0],[.3,1,.5,0],[0,.5,1,0],[0,0,0,1]])@np.diag([.01,.01,.01,.02])
RB=np.array([[1e-4,3e-5],[3e-5,1e-4]])
RQ=np.eye(3)*.0004
plans={}
for kind,ix in [('B',[0,1]),('T',[0,1,2]),('H',[0,1,3])]:
 D=D4[ix];R=R4[np.ix_(ix,ix)];plans['direct_'+kind]=(D,np.linalg.inv(R),['SiO2','TiO2','redundant_Ti','H_A'])
plans['stage2_B']=(C,np.linalg.inv(RB),['SiO2','TiO2'])
plans['stage2_R']=(np.vstack([C,C]),np.linalg.inv(np.block([[RB,np.zeros((2,2))],[np.zeros((2,2)),RB]])),['SiO2','TiO2','rep_SiO2','rep_TiO2'])
plans['stage2_P']=(np.vstack([C,np.eye(3)]),np.linalg.inv(np.block([[RB,np.zeros((2,3))],[np.zeros((3,2)),RQ]])),['SiO2','TiO2','QXRD_Q','QXRD_A','QXRD_R'])
counts={'estimates':0,'A0':0,'A1':0,'A2':0,'hard':0,'measured':0,'unmeasured':0,'direct':0}
maxima={'feasibility':0.,'normalized_kkt':0.,'A1_center_abs':0.,'objective_abs':0.,'reported_kkt_abs':0.}
fail=[]
for z in readcsv(RUN/'results/predictions.csv'):
 counts['estimates']+=1;method=z['arm'][:2];counts[method]+=1;counts[z['stratum']]+=1
 if z['support_group']=='hard':counts['hard']+=1
 m=np.array([float(z[k+'_hat']) for k in 'QAR']);support=np.array([True,z['support_group']!='hard',True]);fre=np.flatnonzero(support)
 feas=max(abs(sum(m)-1.),max(0.,-min(m)),max(abs(m[~support])) if (~support).any() else 0.)
 maxima['feasibility']=max(maxima['feasibility'],feas)
 if feas>1e-9 or z['status']!='ok':fail.append((counts['estimates'],'feasibility',feas));break
 p=priors.get(z['prior_id']) if method!='A0' else None
 if method=='A1':
  d=float(np.max(np.abs(m-np.array(p['center']))));maxima['A1_center_abs']=max(maxima['A1_center_abs'],d)
  if d>1e-8:fail.append((counts['estimates'],'A1_center',d));break
  continue
 stage=int(z['stage']);mode=('B' if z['arm']=='A1' else z['arm'][-1]) if stage==1 else ('B' if z['stratum']=='unmeasured' or z['arm'].split('_')[1]=='N' else z['arm'].split('_')[1][0])
 D,W,names=plans[('direct_' if stage==1 else 'stage2_')+mode]
 sample=obs[z['sample_id']]
 if stage==1:y=np.array([float(sample[k]) for k in names])[[0,1,2] if mode=='T' else ([0,1,3] if mode=='H' else [0,1])]
 else:y=np.array([float(sample[k]) for k in names])
 lam=0. if method=='A0' else (0.01 if z['cell_id']=='2' else 1.)
 K=np.zeros((3,3)) if method=='A0' else np.array(p['precision'])
 mu=np.zeros(3) if method=='A0' else np.array(p['center'])
 H=D.T@W@D+lam*K;f=D.T@W@y+lam*K@mu;g=H@m-f
 positive=[j for j in fre if m[j]>1e-9];mult=float(np.mean(g[positive]))
 stat=max(abs(g[j]-mult) for j in positive)
 inactive=max([max(0.,mult-g[j]) for j in fre if j not in positive] or [0.])
 compl=max(abs(m[j]*max(0.,g[j]-mult)) for j in fre)
 scale=max(1.,np.linalg.norm(H,np.inf)*max(1.,np.linalg.norm(m,np.inf))+np.linalg.norm(f,np.inf))
 kkt=max(stat,inactive,compl)/scale;maxima['normalized_kkt']=max(maxima['normalized_kkt'],kkt)
 err=D@m-y;assay=float(err@W@err/2);pen=float(lam*((m-mu)@K@(m-mu))/2)
 delta=max(abs(float(z['assay_loss'])-assay),abs(float(z['prior_loss'])-pen),abs(float(z['objective'])-(assay+pen)))
 maxima['objective_abs']=max(maxima['objective_abs'],delta)
 if kkt>1e-8 or delta>1e-12:fail.append((counts['estimates'],'kkt_or_objective',kkt,delta));break
assert counts['estimates']==350250 and not fail,(counts,fail)
result={'counts':counts,'maxima':maxima,'failures':fail,'tolerances':{'feasibility':1e-9,'normalized_kkt':1e-8,'objective_atol':1e-12,'A1_center_atol':1e-8},'source':'independent saved-observation mass/likelihood oracle, no phase_models or corrected checker calls','saved_prediction_sha256':sha(RUN/'results/predictions.csv'),'verdict':'PASS'}
with (OUT/'independent_mass_oracle.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(result,sort_keys=True))
