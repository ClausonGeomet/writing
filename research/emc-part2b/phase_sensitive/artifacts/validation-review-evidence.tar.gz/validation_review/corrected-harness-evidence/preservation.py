import os,hashlib,json,sys
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
OUT=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
name=sys.argv[1]
index=ROOT/'artifacts/source-files.sha256';archives=ROOT/'artifacts/archive-files.sha256'
expected=dict((s.split('  ',1)[1],s.split('  ',1)[0]) for s in index.read_text().splitlines())
actual={rel:sha(ROOT/rel) for rel in expected}
runfiles={'run/'+p.relative_to(ROOT/'run').as_posix() for p in (ROOT/'run').rglob('*') if p.is_file()}
arch_expected=dict((s.split('  ',1)[1],s.split('  ',1)[0]) for s in archives.read_text().splitlines())
arch_actual={rel:sha(ROOT/'artifacts'/rel) for rel in arch_expected}
sources={p:sha(ROOT/p) for p in ('measurement_experiment.py','generation.R','test_experiment.py','phase_models.py','test_phase_models.py','measurement_experiment_corrected.py','test_experiment_corrected.py')}
result={'index_sha256':sha(index),'archive_index_sha256':sha(archives),'indexed_files':len(expected),'actual_run_files':len(runfiles),'index_missing':sorted(set(expected)-runfiles),'unindexed_run_files':sorted(runfiles-set(expected)),'mismatched_files':[k for k,v in expected.items() if actual[k]!=v],'archive_count':len(arch_expected),'mismatched_archives':[k for k,v in arch_expected.items() if arch_actual[k]!=v],'source_hashes':sources,'all_file_hashes':actual,'archive_hashes':arch_actual}
assert len(expected)==len(runfiles)==116 and len(arch_expected)==6 and not result['mismatched_files'] and not result['mismatched_archives'] and not result['index_missing'] and not result['unindexed_run_files']
with (OUT/f'preservation-{name}.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('all_file_hashes','archive_hashes','source_hashes')},sort_keys=True))
