import csv, hashlib, json, os, shutil, sys, tempfile, time
from collections import defaultdict
from pathlib import Path
import numpy as np
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment as old
import measurement_experiment_corrected as new

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
def rows(p):
 with open(p,newline='') as f:return list(csv.DictReader(f))
def write(name,obj):
 p=OUT/name
 with open(p,'x') as f:json.dump(obj,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')

def resource():
 cases=[]
 def case(name,elapsed=0,size=0,preadd=0,seconds=5400,cap=500000000,expect_call=0):
  with tempfile.TemporaryDirectory(dir=OUT) as td:
   p=Path(td); now=[0.0]; calls=[]
   if size: (p/'existing').open('wb').truncate(size)
   def pre(g):
    now[0]=elapsed
    if preadd:(p/'preflight').open('wb').truncate(preadd)
   try:
    value=new.non_generating_boundary(p,lambda:(calls.append(1),'reached')[1],preflight=pre,clock=lambda:now[0],seconds=seconds,byte_cap=cap)
    error=None
   except Exception as exc:value=None;error=f'{type(exc).__name__}: {exc}'
   assert len(calls)==expect_call,(name,calls,error)
   if expect_call:assert value=='reached'
   else:assert error is not None
   cases.append(dict(name=name,elapsed=elapsed,size=size,preadd=preadd,seconds=seconds,cap=cap,calls=len(calls),return_value=value,exception=error,verdict='PASS'))
 case('elapsed_6000',elapsed=6000)
 case('existing_sparse_501000000',size=501000000)
 case('exact_deadline',elapsed=5400)
 case('preflight_growth',size=499999990,preadd=11)
 case('below_cap_callback',elapsed=5399,size=499999000,expect_call=1)
 write('resource_probes.json',{'cases':cases,'source_sha256':digest(ROOT/'measurement_experiment_corrected.py')})

def score():
 # Calls the delivered scorer/mask for every real block, with only one copied prediction changed.
 predictions=rows(RUN/'results/predictions.csv'); base=rows(RUN/'results/cohort_metrics.csv'); paired=rows(RUN/'results/paired_summary.csv')
 target=[r for r in predictions if r['cell_id']=='1' and r['cohort_id']=='1' and r['support_group']=='full' and r['stage']=='2' and r['budget']=='5' and r['stratum']=='unmeasured' and r['arm']=='A2_P' and r['sample_id']=='ps1_s1_r1_eval_1']
 assert len(target)==1
 target[0]['status']='numerical_failure';target[0]['reason']='audit injected fit failure'
 for key in ('Q_hat','A_hat','R_hat','bulk_SiO2_hat','bulk_TiO2_hat','bulk_resid_SiO2','bulk_resid_TiO2','assay_loss','prior_loss','objective','constraint_violation','kkt_residual','measurement_design_sse','measurement_design_n'):target[0][key]=''
 truth={x['sample_id']:x for k in ('direct','pool','evaluation') for x in rows(RUN/f'data/{k}_truth.csv')}
 observed={x['sample_id']:x for k in ('direct','pool','evaluation') for x in rows(RUN/f'data/{k}_observed.csv')}
 bounds=defaultdict(list)
 for b in rows(RUN/'results/bounds.csv'):
  bounds[tuple(b[k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum'))].append(b)
 groups=defaultdict(list)
 for p in predictions:groups[tuple(p[k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm'))].append(p)
 indexed={tuple(m[k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm')):m for m in base}
 affected=('1','1','full','2','5','unmeasured')
 numeric=[k for k in base[0] if k not in new.METADATA]
 failures=[];maxdiff=0.;checked=0;null_fields=0;successful_siblings=0
 for key,bm in indexed.items():
  block=key[:-1]; arm=key[-1]; n=int(bm['n_planned']); selected=groups.get(key,[])
  arms=old.ARMS1 if block[3]=='1' else old.ARMS2
  bad=n>0 and any(len(groups.get(block+(a,),[]))!=n or any(x['status']!='ok' for x in groups.get(block+(a,),[])) for a in arms)
  if bad:
   got=new.masked_record(dict(zip(('cell_id','cohort_id','support_group','stage','budget','stratum','arm'),key)),selected,n)
   if block!=affected:failures.append(('unexpected_bad',key))
   if got['n_success']!=n-(1 if arm=='A2_P' else 0) or got['n_failure']!=(1 if arm=='A2_P' else 0):failures.append(('accounting',key,got))
   if any(k in got for k in numeric):failures.append(('numeric_leak',key))
   null_fields+=len(numeric)
   successful_siblings+=got['n_success']
  else:
   got=new.score_block_corrected(selected,truth,observed,bounds.get(block,[]))
   if set(got)-set(bm):failures.append(('extra',key))
   for k,v in got.items():
    actual=bm[k]
    if isinstance(v,(float,int)) and not isinstance(v,bool):
     if actual=='':failures.append(('unexpected_null',key,k));continue
     delta=abs(float(actual)-v);maxdiff=max(maxdiff,delta)
     if delta>1e-12:failures.append(('numeric',key,k,delta))
    elif (actual=='' if v is None else actual==str(v)) is False:failures.append(('field',key,k,actual,v))
  checked+=1
 assert checked==21250
 assert not failures,failures[:3]
 affected_pairs=[p for p in paired if tuple(p[k] for k in ('cell_id','support_group','stage','budget','stratum'))==('1','full','2','5','unmeasured')]
 assert len(affected_pairs)==90
 # Contrast rows must be recomputed with one failed cohort suppressed; all 90 contain A2_P for this schedule.
 assert len({p['contrast'] for p in affected_pairs})==9
 assert all(p['n_planned']=='50' and p['n_complete']=='50' and p['n_failed']=='0' for p in affected_pairs)
 write('scorer_injection.json',dict(injected_key={k:target[0][k] for k in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm','sample_id','status','reason')},checked=checked,affected_arm_rows=13,affected_null_numeric_fields=null_fields,successful_sibling_predictions=successful_siblings,unaffected_metric_rows=21237,unaffected_max_abs_difference=maxdiff,affected_contrast_rows=len(affected_pairs),contrast_expected={'n_planned':50,'n_complete':49,'n_failed':1,'mean_difference':None,'descriptive_se':None},unaffected_contrast_rows=2960,source_sha256=digest(ROOT/'measurement_experiment_corrected.py'),verdict='PASS'))

def main():
 resource();score()
if __name__=='__main__':main()
