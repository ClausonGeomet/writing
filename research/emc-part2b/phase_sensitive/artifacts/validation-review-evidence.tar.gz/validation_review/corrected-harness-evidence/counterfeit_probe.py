import csv, hashlib, json, os, shutil, sys, traceback
from pathlib import Path
import numpy as np
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
BASE=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
FAKE=OUT/'counterfeit-input'
EVID=OUT/'counterfeit-verifier'
sys.path.insert(0,str(ROOT))
import measurement_experiment as old
import measurement_experiment_corrected as new

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
# Immutable source is never changed. Hardlinks are read only in this probe; prediction and ledger replaced as new inodes.
for section in ('data','results','manifests'):
 for src in (BASE/section).glob('*'):
  if src.is_file():
   dst=FAKE/section/src.name;dst.parent.mkdir(parents=True,exist_ok=True)
   if src.name not in ('predictions.csv','execution.json'):os.symlink(src,dst)
src=BASE/'results/predictions.csv';dst=FAKE/'results/predictions.csv'
with src.open(newline='') as f,dst.open('x',newline='') as g:
 rd=csv.DictReader(f);w=csv.DictWriter(g,fieldnames=rd.fieldnames);w.writeheader();changed=0
 for z in rd:
  if z['sample_id']=='ps1_s1_r1_direct_1' and z['arm']=='A0_B' and z['support_group']=='full':
   assert changed==0
   z.update(status='ok',Q_hat='0.99',A_hat='0.005',R_hat='0.005',constraint_violation='0',kkt_residual='0');changed+=1
  w.writerow(z)
assert changed==1
ex=json.loads((BASE/'manifests/execution.json').read_text())
ex['output_hashes']['results/predictions.csv']=sha(dst)
(FAKE/'manifests/execution.json').write_text(json.dumps(ex,sort_keys=True,indent=2)+'\n')
# Copy isolation adapter: the production CLI pins the historical absolute input path. Authenticate the refreshed copy ledger,
# then invoke the unchanged production saved-result verifier and allow its actual estimate certificate to decide.
def copied_path(a,b):
 assert Path(a)==FAKE and Path(b)==EVID
 return FAKE,EVID
def copied_gate(inp):
 e=json.loads((inp/'manifests/execution.json').read_text())
 for rel,h in e['output_hashes'].items():
  p=inp/rel
  if not p.exists():p=BASE/rel
  assert sha(p)==h,(rel,'refreshed ledger mismatch')
 cfg=json.loads((ROOT/'preregistration.json').read_text())
 return cfg,e
new.safe_paths=copied_path
new.historical_gate=copied_gate
try:
 new.verify_saved(FAKE,EVID)
 result={'verdict':'FAIL','reason':'counterfeit accepted'}
except Exception as err:
 result={'verdict':'PASS','exception':type(err).__name__,'reason':str(err),'traceback':traceback.format_exc()[-3000:]}
assert result['verdict']=='PASS' and ('KKT' in result['reason'] or 'candidate' in result['reason']),result
# Independent feasible directional derivative from frozen observation and known covariance.
with (BASE/'data/direct_observed.csv').open(newline='') as f:
 obs=next(x for x in csv.DictReader(f) if x['sample_id']=='ps1_s1_r1_direct_1')
y=np.array([float(obs[k]) for k in ('SiO2','TiO2')]);C=np.array([[1,0,0],[0,1,1]],float);R=np.array([[1e-4,3e-5],[3e-5,1e-4]])
fake=np.array([.99,.005,.005]);orig=np.array([.6084283161321855,.19578584193390733,.19578584193390733])
g=C.T@np.linalg.solve(R,C@fake-y)
derivative=float(g@(orig-fake))
assert abs(derivative-(-4159.912855134839))<1e-9
result.update(changed_rows=changed,refreshed_prediction_sha256=sha(dst),refreshed_execution_sha256=sha(FAKE/'manifests/execution.json'),directional_derivative=derivative,reported_kkt='0',mass=fake.tolist(),verifier_source_sha256=sha(ROOT/'measurement_experiment_corrected.py'))
with (OUT/'counterfeit_result.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('traceback',)},sort_keys=True))
