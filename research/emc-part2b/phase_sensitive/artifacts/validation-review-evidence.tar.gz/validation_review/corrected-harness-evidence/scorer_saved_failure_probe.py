import csv,json,os,sys,shutil
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
COPY=OUT/'failed-score-copy'
if COPY.exists():shutil.rmtree(COPY)
(OUT/'scorer-gate').mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
import measurement_experiment_corrected as new
import measurement_experiment as old
for kind in ('direct','pool','evaluation'):
 for suffix in ('truth','observed'):
  src=RUN/f'data/{kind}_{suffix}.csv';dst=COPY/f'data/{kind}_{suffix}.csv';dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(src)
dst=COPY/'results/bounds.csv';dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(RUN/'results/bounds.csv')
keys=('cell_id','cohort_id','support_group','stage','budget','stratum')
block=('1','1','full','2','5','unmeasured')
metrics=RUN/'results/cohort_metrics.csv';target=COPY/'results/cohort_metrics.csv'
with metrics.open(newline='') as f,target.open('x',newline='') as g:
 rd=csv.DictReader(f);w=csv.DictWriter(g,rd.fieldnames);w.writeheader();changed=0
 for row in rd:
  if tuple(row[k] for k in keys)==block:
   for k in rd.fieldnames:
    if k not in new.METADATA:row[k]=''
   row['status']='unavailable_matched_failure';row['reason']='matched arm failed or missing'
   row['n_success']='29' if row['arm']=='A2_P' else '30';row['n_failure']='1' if row['arm']=='A2_P' else '0';changed+=1
  w.writerow(row)
assert changed==13
paired=RUN/'results/paired_summary.csv';target2=COPY/'results/paired_summary.csv'
with paired.open(newline='') as f,target2.open('x',newline='') as g:
 rd=csv.DictReader(f);w=csv.DictWriter(g,rd.fieldnames);w.writeheader();changed_pairs=0
 for row in rd:
  if tuple(row[k] for k in ('cell_id','support_group','stage','budget','stratum'))==('1','full','2','5','unmeasured'):
   row.update(n_planned='50',n_complete='49',n_failed='1',mean_difference='',descriptive_se='');changed_pairs+=1
  w.writerow(row)
assert changed_pairs==90
original=new.records
def injected_records(path,*,jsonlines=False):
 for row in original(path,jsonlines=jsonlines):
  if str(path).endswith('results/predictions.csv') and row['sample_id']=='ps1_s1_r1_eval_1' and row['arm']=='A2_P' and row['budget']=='5' and row['stratum']=='unmeasured':
   row={**row,'status':'numerical_failure','reason':'audit injected fit failure'}
  yield row
new.records=injected_records
(COPY/'results/predictions.csv').symlink_to(RUN/'results/predictions.csv')
cfg=json.loads((ROOT/'preregistration.json').read_text())
gate=new.ResourceGate(OUT/'scorer-gate')
result=new.score_saved(COPY,cfg,gate)
assert result=={'cohort_metrics':21250,'paired_summary':3050},result
with (OUT/'scorer_saved_failure_probe.json').open('x') as f:json.dump({'actual_production_verifier_result':result,'changed_metric_rows':changed,'changed_paired_rows':changed_pairs,'prediction_injection':'in-memory copied row, original prediction file symlinked read-only','numeric_metric_fields_all_null':True,'source_sha256':new.sha(ROOT/'measurement_experiment_corrected.py'),'verdict':'PASS'},f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(result,sort_keys=True))
