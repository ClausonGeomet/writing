import os,csv,json,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002';OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment as old
import measurement_experiment_corrected as new
import phase_models as model
C=np.array([[1.,0,0],[0,1,1]])
R=np.array([[1e-4,0.9999e-4],[0.9999e-4,1e-4]])
y=np.array([.62,.39]);est=model.estimate(y,C,R,method='A0');m=np.array(est['mass']);H=C.T@np.linalg.solve(R,C);f=C.T@np.linalg.solve(R,y)
feas,kkt=new.kkt_certificate(m,H,f,(True,True,True))
assert np.linalg.eigvalsh(R)[0]>1e-12 and feas<=1e-9 and kkt<=1e-8
cases={'ill_conditioned_spd':{'min_eigenvalue':float(np.linalg.eigvalsh(R)[0]),'mass':m.tolist(),'feasibility':feas,'normalized_kkt':kkt,'verdict':'PASS'}}
def bad(name,fn,part):
 try:fn();cases[name]={'verdict':'FAIL','reason':'accepted'}
 except Exception as e:
  cases[name]={'verdict':'PASS' if part in str(e) else 'FAIL','reason':str(e),'exception':type(e).__name__}
bad('nonfinite_mass',lambda:new.kkt_certificate([float('nan'),.5,.5],H,f,(True,True,True)),'malformed')
with (RUN/'results/predictions.csv').open(newline='') as f:row=next(csv.DictReader(f))
with (RUN/'data/direct_observed.csv').open(newline='') as f:sample=next(csv.DictReader(f))
D=old.C;yv=old.array(sample,('SiO2','TiO2'));cov=old.RB
bad('fabricated_objective',lambda:new.estimate_certificate({**row,'objective':'0'},D,yv,cov,None,(True,True,True),1.),'objective')
prior=next(json.loads(line)['prior'] for line in (RUN/'results/priors.jsonl').read_text().splitlines())
with (RUN/'results/predictions.csv').open(newline='') as f:a1=next(z for z in csv.DictReader(f) if z['arm']=='A1' and z['stage']=='1' and z['cell_id']=='1' and z['cohort_id']=='1')
bad('A1_wrong_center',lambda:new.estimate_certificate({**a1,'Q_hat':'0.9','A_hat':'0.05','R_hat':'0.05'},D,yv,cov,prior,(True,True,True),1.),'A1 center')
bad('wrong_prior_id',lambda:new.expected_prediction({'support_groups':['full'],'strength':1.},(1,1),{**a1,'prior_id':'wrong'},{'direct':[sample]},{}),'prior/design')
bad('wrong_design_id',lambda:new.expected_prediction({'support_groups':['full'],'strength':1.},(1,1),{**row,'observation_design_id':'wrong'},{'direct':[sample]},{}),'prior/design')
assert all(x['verdict']=='PASS' for x in cases.values()),cases
with (OUT/'certificate_edges.json').open('x') as f:json.dump({'cases':cases,'source_sha256':new.sha(ROOT/'measurement_experiment_corrected.py')},f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(cases,sort_keys=True))
