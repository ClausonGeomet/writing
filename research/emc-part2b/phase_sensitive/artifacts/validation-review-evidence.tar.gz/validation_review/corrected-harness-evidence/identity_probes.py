import hashlib,json,os,sys
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
INP=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment_corrected as c
r=c.source_record(INP)
cases={}
cases['unaltered_source_and_input_identity']=c.source_record_identity(r,INP)
for field in ('additive_sources','historical_sources','correction_spec_sha256','historical_manifests','saved_inputs_results','historical_environment_sha256'):
 forged={**r,field:{} if isinstance(r[field],dict) else '0'*64}
 cases['altered_'+field+'_rejected']=not c.source_record_identity(forged,INP)
def reject(name,a,b):
 try:c.safe_paths(a,b);cases[name]=False
 except RuntimeError as e:cases[name]=str(e)
reject('overlapping_output',INP,INP/'audit-copy')
reject('relocated_input',OUT/'counterfeit-input',OUT/'new-output')
reject('existing_output',INP,OUT/'full-certification')
assert all(v for v in cases.values()),cases
with (OUT/'identity_probes.json').open('x') as f:json.dump({'cases':cases,'verdict':'PASS'},f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(cases,sort_keys=True))
