import hashlib,json,os
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
R=Path('/tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive')
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
saved=json.loads((ROOT/'run/attempts/correction-002/manifests/source.json').read_text())
source={n:sha(ROOT/n) for n in ('measurement_experiment.py','generation.R','test_experiment.py','phase_models.py','test_phase_models.py')}
refs={n:sha(R/'followup-evidence'/n) for n in ('inherited_named_case_index.json','retrospective_inventory.json','contrast_inventory.json','dataflow_sentinels.json','diagnostics_recomputation.json','own_channel_rmse.json','negative_controls.json')}
result={'original_sources':source,'original_source_manifest_sha256':sha(ROOT/'run/attempts/correction-002/manifests/source.json'),'corrected_harness_sha256':sha(ROOT/'measurement_experiment_corrected.py'),'corrected_tests_sha256':sha(ROOT/'test_experiment_corrected.py'),'inherited_evidence_sha256':refs,'current_relevance':'Original five sources and correction-002 saved data are byte identical; D01-D10 and D12 mathematical/dataflow probes exercise unchanged source and observations. R1 failures in old score/execute/verify are not inherited as passes; new corrected behavior is re-probed. Full changed verifier is independently executed.'}
assert source['phase_models.py']=='2910f0f43c7effb392a8d71edf64c87e4b314712774b076738b127d324ead2e1'
assert result['corrected_harness_sha256']=='bb3e993bdd22e93811b0ada715e2604d0ca98c1e56e086d0bd9abdfafedd7eac'
with (OUT/'inherited_relevance.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'original_sources':source,'corrected_harness_sha256':result['corrected_harness_sha256']},sort_keys=True))
