import hashlib,json,sys
from pathlib import Path
R=Path('/tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive')
OUT=R/'corrected-harness-evidence'
paths=set()
for pattern in ('audit*.md','review*.md','*spec.md','PREEXECUTION_REVIEW.json','pre_execution_review.md','source-freeze*.md','environment-correction.md'):
 paths.update(p for p in R.glob(pattern) if p.is_file())
for sub in ('followup-evidence',):
 paths.update(p for p in (R/sub).rglob('*') if p.is_file())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
res={str(p.relative_to(R)):h(p) for p in sorted(paths)}
name=sys.argv[1]
with (OUT/f'runtime-preservation-{name}.json').open('x') as f:json.dump({'count':len(res),'files':res},f,indent=2,sort_keys=True);f.write('\n')
print(len(res))
