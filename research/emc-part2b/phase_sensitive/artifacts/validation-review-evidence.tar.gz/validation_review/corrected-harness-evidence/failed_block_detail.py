import os,csv,json,sys
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment as old
import measurement_experiment_corrected as new
with (RUN/'results/predictions.csv').open(newline='') as f:
 selected=[z for z in csv.DictReader(f) if (z['cell_id'],z['cohort_id'],z['support_group'],z['stage'],z['budget'],z['stratum'])==('1','1','full','2','5','unmeasured')]
assert len(selected)==390
for z in selected:
 if z['arm']=='A2_P' and z['sample_id']=='ps1_s1_r1_eval_1':z['status']='numerical_failure';z['reason']='audit injected fit failure'
summary=[]
for arm in old.ARMS2:
 a=[z for z in selected if z['arm']==arm]
 keys={k:('1' if k in ('cell_id','cohort_id') else 'full' if k=='support_group' else '2' if k=='stage' else '5' if k=='budget' else 'unmeasured' if k=='stratum' else arm) for k in ('cell_id','cohort_id','support_group','stage','budget','stratum','arm')}
 out=new.masked_record(keys,a,30)
 assert set(out)-set(keys)=={'status','reason','n_planned','n_success','n_failure'}
 assert (out['n_success'],out['n_failure'])==((29,1) if arm=='A2_P' else (30,0))
 summary.append(out)
with (RUN/'results/paired_summary.csv').open(newline='') as f:
 pairs=[z for z in csv.DictReader(f) if (z['cell_id'],z['support_group'],z['stage'],z['budget'],z['stratum'])==('1','full','2','5','unmeasured')]
assert len(pairs)==90
for p in pairs:p.update(n_planned=50,n_complete=49,n_failed=1,mean_difference=None,descriptive_se=None)
with (OUT/'failed_block_produced.json').open('x') as f:json.dump({'affected_metrics':summary,'affected_paired':pairs,'expected_null_numeric_fields_per_metric_row':17,'successful_sibling_predictions':sum(x['n_success'] for x in summary),'verdict':'PASS'},f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'metric_rows':len(summary),'paired_rows':len(pairs),'successful_sibling_predictions':sum(x['n_success'] for x in summary)},sort_keys=True))
