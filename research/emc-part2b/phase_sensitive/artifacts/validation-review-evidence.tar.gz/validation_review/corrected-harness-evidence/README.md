# Corrected harness independent tester evidence

This directory is the tester-owned, post-execution evidence surface. It does not alter the frozen study design, original run, archives, or five original source files. No command here invokes R or generates a cohort. `counterfeit-input/results/predictions.csv` is an actual 109 MiB disposable audit copy; its other file symlinks point to immutable original inputs. `failed-score-copy/` contains actual copied metric and paired tables with read-only input symlinks. These bulky audit copies stay in runtime and are omitted from portable source packaging.

The original source files can be restored from the six archives under `research/emc-part2b/phase_sensitive/artifacts/` using the repository `artifacts/README.md`. The source SHA index has 116 entries and the archive index has six. The historical verification command requires the original absolute checkout path and its recorded Python/R/package/seed prerequisites. The corrected CLI also binds the original attempt path. A relocated copy must not rewrite those historical paths to appear valid.

To rerun independent scripts in a *fresh* directory after restoring those archives, copy only the `.py` files and this README there. Set `PHASE_STUDY_ROOT` to the restored study root if it is at the required original path. Set `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1`, then use the recorded Python executable `/tmp/bif-v3-world1-validation-env-20261023/bin/python`. Each script writes results beside itself and refuses to overwrite existing results. Run `preservation.py before`, `tester_probes.py`, `counterfeit_probe.py`, `independent_mass_oracle.py`, `scorer_saved_failure_probe.py`, `certificate_edges.py`, `identity_probes.py`, and `preservation.py after`. The counterfeit script's path adapter is limited to its disposable copied input; it authenticates the refreshed copy ledger and then invokes the delivered `verify_saved` numerical path.

The complete official saved-result CLI is:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/tmp/bif-v3-world1-validation-env-20261023/bin/python \
research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py \
 --input-attempt /home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive/run/attempts/correction-002 \
 --evidence-output NEW_EMPTY_EVIDENCE_DIR --verify-saved
```

`full-certification/` contains that command's original post-execution certificate and source record. `independent_mass_oracle.py` is a separate all-row KKT/likelihood calculation that imports neither the corrected checker nor `phase_models`. Earlier D01–D16 named-case evidence remains at `../followup-evidence/`; `inherited_relevance.json` records its exact hashes and current-source relevance. The missing prospective detailed-key inventory remains a disclosed process deviation.
