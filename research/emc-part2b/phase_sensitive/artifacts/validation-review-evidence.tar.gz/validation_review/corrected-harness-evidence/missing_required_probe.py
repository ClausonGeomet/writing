import csv,json,os,sys
from pathlib import Path
ROOT=Path(os.environ.get('PHASE_STUDY_ROOT','/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive'))
RUN=ROOT/'run/attempts/correction-002';OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import measurement_experiment_corrected as n
cfg=json.loads((ROOT/'preregistration.json').read_text())
obs={kind:[] for kind in ('calibration','pool')}
for kind in obs:
 with (RUN/f'data/{kind}_observed.csv').open(newline='') as f:
  obs[kind]=[x for x in csv.DictReader(f) if x['cell_id']=='1' and x['cohort_id']=='1']
with (RUN/'results/priors.jsonl').open() as f:
 saved=[json.loads(x) for x in f if json.loads(x)['cell_id']==1 and json.loads(x)['cohort_id']==1]
assert len(saved)==31
bad=[dict(x) for x in saved];bad[0]={**bad[0],'prior':{**bad[0]['prior'],'status':'numerical_failure'}}
try:n.expected_priors(cfg['cells'][0],(1,1),obs,bad);prior_result='accepted'
except Exception as e:prior_result=f'{type(e).__name__}: {e}'
assert prior_result!='accepted'
# The copied metric and contrast records already represent one failed required prediction.
# With the target prediction missing entirely, the production scorer must accept only the same matched-failure accounting.
copy=OUT/'failed-score-copy';orig=n.records
def omitted(path,*,jsonlines=False):
 for x in orig(path,jsonlines=jsonlines):
  if str(path).endswith('results/predictions.csv') and x['sample_id']=='ps1_s1_r1_eval_1' and x['arm']=='A2_P' and x['budget']=='5' and x['stratum']=='unmeasured':continue
  yield x
n.records=omitted
try:
 result=n.score_saved(copy,cfg,n.ResourceGate(OUT/'scorer-gate'))
 exception=None
except Exception as e:
 result=None;exception=f'{type(e).__name__}: {e}'
actual=n.masked_record({},[{'status':'ok'}]*29,30)
assert actual['n_success']==29 and actual['n_failure']==0 and exception is not None
report={'failed_required_prior_rejection':prior_result,'missing_prediction_scorer_result':result,'missing_prediction_verifier_exception':exception,'masked_record_actual':actual,'expected':{'n_planned':30,'n_success':29,'n_failure':1},'verdict':'BLOCK','route':'simulator'}
with (OUT/'missing_required_probe.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(report,sort_keys=True))
