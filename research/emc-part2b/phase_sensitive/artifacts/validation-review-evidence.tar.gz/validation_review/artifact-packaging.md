# Simulator artifact packaging — 2026-10-27

## Scope and result

Packaging only; no study execution, fitting, source, design, seed, tolerance, freeze or manifest changes. Read source files from the absolute main checkout path `/home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive/run`. The source tree's root blocked attempt, correction-001 blocked attempt and saved replay, and correction-002 final PASS attempt are all included. No source file was removed or edited. No raw `run/` file was added to Git.

Created six deterministic gzip tar archives under `research/emc-part2b/phase_sensitive/artifacts/`, plus `source-files.sha256`, `archive-files.sha256`, and `README.md`. The README contains exact packaging, restoration and verifier commands, archive format rules, and the verifier's legacy absolute-path/environment prerequisites. This is a packaging handoff for final reviewer inspection before any push, **not final clearance**.

| Archive | Bytes | SHA256 |
| --- | ---: | --- |
| `run-correction-001-evidence.tar.gz` | 1,071,050 | `d13166d435b54d5d76516640b6232fe00962073bcd194afc0b75cb49b7cf6216` |
| `run-correction-001-replay.tar.gz` | 22,948,055 | `1b9a6e308d98c7a8991a2e56aa68b2affaa86e64c7d044b8a14fddc895d332c8` |
| `run-correction-001-results.tar.gz` | 22,128,935 | `73c93f70b09dfbb058e1a9a43eaea2a32585318343254e40b07727f3b1c3e1e1` |
| `run-correction-002-evidence.tar.gz` | 1,173,763 | `62fa8b68adee37341bd8b41dc96fb9cf41ea8f0c2e7804b2462d788c2274a527` |
| `run-correction-002-results.tar.gz` | 22,179,400 | `258f86684f7eb284850a5707176130f6a3b91d5f169517a413dd55e88c50af10` |
| `run-root.tar.gz` | 77,869 | `5e2f167f8e842317b50c3b447321deb87e0f91b784086e15b2187087307daed2` |

Total compressed bytes: **69,579,072**. Largest archive: **22,948,055 bytes**, below the 90 MiB cap. Source inventory: **116 files**, **475,212,777 bytes**. SHA256 of the complete, lexically ordered source file list (`source-files.sha256`): `2876fedc6ebc72a3c9f83874ab5f717f51c4259eea6d1824e03b93a9bd9973dd`. SHA256 of `archive-files.sha256`: `1b9dc5d6d824cf5bf9dc7856bc763aa5d6cf67e9912247b8167aab3a6eddd32a`.

## Reproduction and verification commands

From the isolated worktree repository root, reproduce archives from the original absolute source by running the exact `python3 - <<'PY' ... PY` block in `research/emc-part2b/phase_sensitive/artifacts/README.md`. It asserts archive size, checks every decompressed member's SHA256 and byte count against the complete source index, checks no missing/duplicate/unsafe members, and rehashes source files after packaging. Its only writes are within `artifacts/`.

From the repository root, restore into an empty study `run/` and verify every file byte:

```bash
set -euo pipefail
study=research/emc-part2b/phase_sensitive
(cd "$study/artifacts" && sha256sum -c archive-files.sha256)
for archive in "$study"/artifacts/*.tar.gz; do tar -xzf "$archive" -C "$study"; done
(cd "$study" && sha256sum -c artifacts/source-files.sha256)
```

At the original main checkout path with the recorded Python/R/pinned-package and historical run prerequisites, verify the restored final attempt read-only:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
/tmp/bif-v3-world1-validation-env-20261023/bin/python \
research/emc-part2b/phase_sensitive/measurement_experiment.py \
  --config research/emc-part2b/phase_sensitive/preregistration.json \
  --output research/emc-part2b/phase_sensitive/run \
  --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json \
  --attempt correction-002 --verify
```

## Checks actually performed

- Indexed source before packaging and rehashed every source file afterward; all 116 SHA256/size pairs remained identical. Running `sha256sum -c source-files.sha256` from the original main study directory again after packaging yielded 116/116 OK. This is the unchanged-source proof.
- Independently decompressed and streamed every tar member against the complete source SHA256/size map. All 116 members matched exactly once; all member names are relative under `run/`, with no `..` component.
- Restored all six archives in the isolated worktree, then ran `sha256sum -c artifacts/source-files.sha256`: 116/116 OK. Removed only that temporary restored copy afterward; archives remain.
- Ran the exact final `--verify` command read-only in the original main checkout: `PASS`, 350,250 predictions, 21,250 cohort metric rows, zero prediction failures. A `--verify` attempt on the relocated worktree copy reached `BLOCK: seed inventory changed after freeze`, because the frozen historical seed records embed absolute main checkout paths. The restored bytes themselves passed 116/116 SHA256 checks. Restoration at the original path with the recorded prerequisites yields the same file inputs as the successful main check.

The final independent reviewer should inspect these artifacts and packaging evidence before push. No scientific verdict or publication clearance is asserted here.

Local packaging-only worktree commit: `f76ae5a` (`simulator: package phase-sensitive run evidence`), with no authorship footer. Worktree is clean; nothing was pushed.
