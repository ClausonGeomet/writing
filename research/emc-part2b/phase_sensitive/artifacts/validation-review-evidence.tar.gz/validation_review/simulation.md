# Simulator handoff — phase-sensitive QAR measurement study

**Status: IMPLEMENTED; NO DRAWS.** The independent public pre-execution review is strict PASS for design digest `7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad`. No comparative generation, smoke study, metric table, or scientific acceptance claim was run in this isolated simulator worktree. The builder's `phase_models.py` is absent until merge; the complete `--check` therefore returns `BLOCK: merged builder source or simulator test absent` here, as the source gate requires. The tester must execute the study only after merge and independent deterministic certification.

## Frozen design implemented

The design has four cells and 50 independent cohorts per cell. Each cohort has 20 calibration, 20 direct, 10 pool, and 30 independent evaluation specimens. Cell 4 has soft and hard support analyses on the same observations. There are seven direct arms, thirteen stage-2 arms, and fixed nested budgets 0/2/5. Planned totals are 800 public truth calls, 16,000 unique specimens, 350,250 predictions, and 21,250 cohort metric records. The primary contrast is A2_P minus A2_R for unmeasured evaluation specimens at budget 5, within each cell/support group. No pilot outcomes are reused.

The R generator makes independent stream-scoped truth and laboratory error draws. It converts public numeric truth data-frame columns to a double matrix before finite checks. It uses the exact frozen covariance matrices, package pin, local TiO2 mineral formulas, 2,000 named seed streams, and no eval phase observation. The Python harness calls the declared five `phase_models` APIs as black boxes, performs whole-unit leave-one-out updates for measured specimens, and uses only bulk observations on unmeasured evaluation targets. All fitting uses observed files; the scored truth files are first opened after predictions are closed and SHA256-hashed. Repeated tests form one stacked unit with complete covariance in the model update. The harness writes all declared data/result/manifests/audit areas, three figures, matched cohort differences and descriptive SEs, LP statuses, and explicit failure/empty denominators. It has one worker, one required BLAS thread, a 90-minute run cap and a 500 MB output cap.

## Source files

- `research/emc-part2b/phase_sensitive/generation.R`: sole stochastic generator and data CSV writer.
- `research/emc-part2b/phase_sensitive/measurement_experiment.py`: exact-byte design/review gate; historical seed, public package, source and environment freeze; `--check`, `--freeze`, `--run`, `--verify`; correction-attempt lineage; prediction, scoring, figure, and manifest paths.
- `research/emc-part2b/phase_sensitive/test_experiment.py`: deterministic checks of gate, historical streams, channels/covariances, fit/truth separation, matrix-conversion order, failure retention and metric formulas.

## Ready commands after merge

Use one Python environment with NumPy, SciPy, matplotlib and pytest. Export `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`; run from the repository root. Replace `python3` with the chosen frozen environment executable in every command if the system Python lacks dependencies.

```sh
python3 research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --check
python3 research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --freeze
python3 research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --run
python3 research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --verify
```

`--check`, `--freeze`, and `--verify` draw no observations. Only `--run` starts the R generator, after rechecking frozen design, strict public review, source bytes, environment, exhaustive historical seed inventory, and tester-owned PASS records with evidence for D01–D12 and D16 in `run/audit/checks.json`. D13–D15 are explicitly PENDING before the run; `--verify` requires all D01–D16 to PASS with actual output evidence. The initial simulator-preflight row is not a substitute. The pre-run audit is snapshotted and hashed before the start ledger and generator invocation. An existing data/result directory is rejected. For a source-only correction to a blocked run, retain the original and use `--attempt correction-001 --correction-reason 'specific cause' --freeze`, then the same attempt with `--run`; the new freeze checks unchanged design and seed inventory. No automatic retry or design amendment is implemented. A scientific design change requires a new public freeze and independent review before any draw.

The tester is expressly authorized to write declared `run/{data,results,figures,manifests,audit,attempts}` through this harness and tester-owned audit evidence, without editing source or configuration. Tester should execute independent D01-D16 analytical and dataflow checks, then freeze, run once, verify, and report any blocked attempt with original records intact. Numerical/LP failure blocks completion; an infeasible envelope and the budget-0 measured empty stratum are retained as scientific/structural statuses. No grid shrink, additional seed, rerun of the accepted pilot, or outcome-based adjustment is authorized.

## Deterministic evidence in simulator worktree

- Public design/review byte and digest gate: PASS on read-only check.
- Historical seed inventory: 2,000 new streams, no collisions with inventoried old manifest/master/search values.
- Public `d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d` source export: all Git blob IDs match the public commit; installed package and source provenance files agree. No package edit.
- `Rscript parse(file=...)`: PASS; no R simulation call.
- `pytest -q .../test_experiment.py`: 10 passed; no draw.
- CLI `--check`: expected BLOCK in this isolated worktree because builder source has not merged. This is a source-availability gate, not permission to copy builder code.

Full metrics, MCSE/paired SE values and scientific gains are unassessed until tester executes the preregistered run. The numerical correctness gate and later independent scientific results review remain required.

## Gate lifecycle correction

The original handoff's pre-run D01–D16 PASS statement was incorrect: D13 counts, D14 saved metrics/failure copies, and D15 replay require outputs from the authorized run. The focused source correction requires D01–D12 and D16 before generation, preserves D13–D15 as unexecuted pending rows, and returns `RUN_COMPLETE_PENDING_POSTCHECKS` from `--run`. Final `--verify` requires all sixteen PASS rows and evidence, the unchanged pre-run certification snapshot, frozen source/environment/design/review and output hashes. No study draw occurred during this correction. See `gate-correction.md` for the focused check and commit.

## Source freeze and accepted history correction — 2026-10-27

Local simulator commit `bcf089b` completes the five-file source hash set and records the read-only parent model hash/non-import status, together with pinned public source and installation provenance. The historical seed inventory is restricted to accepted PR4/PR5 repository evidence and prior workflow run schedules, including master, derived and search seed values. Its complete per-path SHA256, scope and integer values are saved in `historical-seed-inventory.json`; see `source-freeze-correction.md` for the correction evidence. Twelve focused draw-free tests and the CLI `--check` passed. No freeze, generation, comparative outputs or draw occurred. Tester must rerun D01–D12 and D16 after both writer fixes, freeze source/environment/seeds, then execute the sole authorized bounded run; D13–D15 remain post-run.

## Mixed-source environment freeze correction — 2026-10-27

The next `--freeze` exposed a source-only parser defect: `environment()` fed `generation.R` to Python `ast.parse` while inventorying imports, causing `invalid decimal literal` at R's `3L`. Local commit `f26dc06` makes the Python import inventory parse only `.py` source paths. The R file remains in the five-file byte-hash manifest, and actual R version/package/RNG/BLAS probing and pinned source/install provenance are unchanged. A narrow regression invokes the real environment probe with mixed Python/R paths and checks NumPy, SciPy, matplotlib, pytest, R, RNGkind, simCoDaR, jsonlite, BLAS/LAPACK and thread fields. Twenty-one focused tests and public `--check` passed without draws. The earlier 379 independent tester checks remain pre-correction evidence; tester must recertify them after merge.

The main checkout retains the first failed freeze's uncommitted `run/manifests/design_freeze.json` and `source.json`; `environment.json`, `seeds.json`, `freeze.json`, data and results are absent. The simulator did not touch those bytes or call `--freeze` in this worktree. `environment-correction.md` gives exact hash-asserted, one-time archive instructions to preserve the first failed freeze and diagnostic before tester retries. The resulting source hash must be refrozen after merge. Verdict remains **READY FOR TESTER PRE-DRAW CERTIFICATION; NO SIMULATION RESULTS**.

# Source-only generation correction (2026-10-27)

After the first authorized run failed before any CSV export, simulator commit `413e927` replaced the fragile R truth lookup with explicit calibration/direct/pool/evaluation truth and observed maps. Fifteen draw-free focused tests and public `--check` passed. The initial run and its source/freeze/start/generation evidence remain preserved; no corrected draw or result was produced by simulator. Tester owns independent D01–D12/D16 recertification, `correction-001` source/environment freeze and run, then real D13–D15 saved-output checks. See `generation-correction.md` for cause, hashes and exact retry commands.

## Post-run artifact packaging handoff — 2026-10-27

The completed root/correction-001/correction-002 run tree is packaged byte-for-byte into six deterministic archives under `phase_sensitive/artifacts/`. The complete 116-file index, restoration recipe, archive hashes, size evidence, unchanged-source checks and final read-only verifier result are in `artifact-packaging.md` and the artifact `README.md`. This packaging-only task made no study execution or source/design change. Final independent artifact review is still required before any push.

## Post-execution source-only correction — 2026-10-27

Commit `bf1b508` adds only `measurement_experiment_corrected.py` and `test_experiment_corrected.py`. The new draw-free CLI owns corrected pre-invocation resource checks, complete matched-failure masking, and mathematical verification of the saved correction-002 attempt under a separate post-execution source certificate. It never calls the historical generator or changes the five executed sources, frozen design, original run files or archives. Eight focused tests passed, and a read-only first-cohort check reconstructed 31 priors and checked 1,401 saved estimates; the full 350,250-row certificate is reserved for the independent tester. See `simulator-correction.md` for hashes, exact command and remaining validation gate. Existing scientific STOP remains in force.
