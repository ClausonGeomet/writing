# Tester audit — phase-sensitive study

## Verdict: BLOCK before any draw

The repaired fixed-Quartz minimum-norm oracle and 20 focused tests pass. The public `--freeze` command fails in `measurement_experiment.py::environment` because it parses `generation.R` with Python `ast.parse`. The first R integer literal `3L` raises `SyntaxError: invalid decimal literal`. No freeze certificate, data, results, or first draw exists. D11 is FAIL; D13–D15 are PENDING. Failure routed to simulator in `mailbox.md`. The existing partial `design_freeze.json` and `source.json` are retained as failed-freeze evidence.

## Commands and exact outputs

From repository root, with `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/emc-phase-mpl` and `/tmp/bif-v3-world1-validation-env-20261023/bin/python`:

1. `python -m pytest -q research/emc-part2b/phase_sensitive/test_phase_models.py research/emc-part2b/phase_sensitive/test_experiment.py --cov=phase_models --cov=measurement_experiment --cov-report=term` with `COVERAGE_FILE=/tmp/emc-phase-coverage PYTHONPATH=research/emc-part2b/phase_sensitive PYTEST_ADDOPTS="-p no:cacheprovider"`:

```text
....................                                                     [100%]
================================ tests coverage ================================
_______________ coverage: platform linux, python 3.12.3-final-0 ________________

Name                                                            Stmts   Miss  Cover
-----------------------------------------------------------------------------------
research/emc-part2b/phase_sensitive/measurement_experiment.py     694    464    33%
research/emc-part2b/phase_sensitive/phase_models.py               337     50    85%
-----------------------------------------------------------------------------------
TOTAL                                                            1031    514    50%
20 passed in 1.12s
```

2. `python research/emc-part2b/phase_sensitive/run/audit/tester_oracles.py`: `{"n": 135, "passed": 135, "failed": []}`.

3. `python research/emc-part2b/phase_sensitive/run/audit/tester_preflight.py`: `{"n": 244, "passed": 244, "failed": []}`. One expected invalid-input NumPy construction warning was printed; it did not suppress a test failure.

4. `python research/emc-part2b/phase_sensitive/measurement_experiment.py --config research/emc-part2b/phase_sensitive/preregistration.json --output research/emc-part2b/phase_sensitive/run --review research/emc-part2b/phase_sensitive/PREEXECUTION_REVIEW.json --check`:

```json
{"checked_utc": "2026-10-27T04:26:15.139686+00:00", "design_digest": "7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad", "planned": {"analysis_blocks": 250, "budgets": [0, 2, 5], "cells": [1, 2, 3, 4], "cohort_metrics": 21250, "cohorts": 200, "predictions": 350250, "specimens": 16000, "stage1_arms": ["A0_B", "A1", "A2_B", "A0_T", "A2_T", "A0_H", "A2_H"], "stage1_predictions": 35000, "stage2_arms": ["A0_B", "A0_R", "A0_P", "A1_N", "A2_N", "A1_B", "A2_B", "A1_R", "A2_R", "A1_P", "A2_P", "A2_R0", "A2_P0"], "stage2_predictions": 315250, "truth_calls": 800}, "review_sha256": "eb8621367868a09c04bae1949ac1fe33bb100b6784f7ffdf331824b03d930a0c", "schema": "qar-phase-check-v1", "verdict": "PASS"}
```

5. Same command with `--freeze`:

```text
BLOCK: invalid decimal literal (<unknown>, line 4)
```

The independent direct probe `x.environment(cfg)` produced:

```text
File "research/emc-part2b/phase_sensitive/measurement_experiment.py", line 272, in environment
    for node in ast.walk(ast.parse(path.read_text())):
SyntaxError: invalid decimal literal
    if (length(args) != 3L) stop("usage: generation.R CONFIG OUTPUT ISOLATED_LIBRARY")
```

## Named check state

|ID|Executed oracle rows|State|Evidence|
|---|---:|---|---|
|D01|155|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D02|28|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D03|16|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D04|13|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D05|40|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D06|12|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D07|3|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D08|10|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D09|12|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D10|24|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D11|39|FAIL — public freeze parser|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json` and failed `--freeze`|
|D12|13|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D13|0|PENDING — post-run|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D14|0|PENDING — post-run|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D15|0|PENDING — post-run|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|
|D16|14|PASS — draw-free cases|`run/audit/tester_oracle_results.json`, `tester_preflight_results.json`|

D11's 39 narrower oracle rows passed, but its required actual environment freeze failed. They cannot make D11 pass. D12 was checked through no-truth source flow, whole-unit LOO, fixed selection, distinct stream/schedule probes; exhaustive saved-record mapping awaits the run and cannot be asserted now. D13–D15 were not run.

## Per-test result table

The following is every executed metric row from both independent oracle files. Exact expected and actual values and tolerances are retained in those JSON files. `Rel. error` is calculated only for scalar numeric comparisons with nonzero expected value. No value was rounded for comparison.

|Check|Metric|Expected|Actual|Tolerance|Rel. error|Verdict|
|---|---|---|---|---|---:|---|
|D01|fit_initial.Y.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.posinf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.neginf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.string|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.wrongshape|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.n0|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.Y.n1|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.R.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.R.negative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.R.asymmetric|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.R.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.R.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.floorzero|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.floornegative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.shrinknegative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.shrinkhigh|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.supportnone|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.supportbad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|fit_initial.supportshort|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.posinf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.neginf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.string|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.wrongshape|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.y.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.negative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.asymmetric|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.string|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.wrongshape|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.allfalse|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.nonbool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.short|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.fixedQ.low|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.fixedQ.high|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.fixedQ.conflict|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.posinf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.neginf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.string|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.wrongshape|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.y.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.negative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.asymmetric|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.string|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.wrongshape|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.allfalse|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.nonbool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.short|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.fixedQ.low|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.fixedQ.high|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.fixedQ.conflict|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|unknownmethod|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|A0prior|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|A1data|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|A2noprior|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|negstrength|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|nanstrength|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|badprior|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|duplicateunits|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|unknownexclude|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|signed.estimate.status|"ok"|"ok"|"exact"|—|PASS|
|D01|signed.bounds.status|true|true|"exact"|—|PASS|
|D02|fit.repeat|"{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"exact"|—|PASS|
|D02|fit.immutable|true|true|"exact"|—|PASS|
|D02|update.repeat|"{\"center\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 2.220446049250313e-16, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 2.2572225151953736e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 1.7554167342883506e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"{\"center\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 2.220446049250313e-16, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 2.2572225151953736e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 1.7554167342883506e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"exact"|—|PASS|
|D02|update.immutable|true|true|"exact"|—|PASS|
|D02|estimate.repeat|"{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 0.0, \"kkt_residual\": 5.660956118940746e-17, \"mass\": [0.6, 0.10000000000000006, 0.30000000000000004], \"objective\": 2.2291317030190583e-30, \"prior_loss\": 2.2229687271970192e-30, \"reason\": \"\", \"reconstructed\": [0.6, 0.40000000000000013], \"residual\": [0.0, -1.1102230246251565e-16], \"status\": \"ok\"}"|"{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 0.0, \"kkt_residual\": 5.660956118940746e-17, \"mass\": [0.6, 0.10000000000000006, 0.30000000000000004], \"objective\": 2.2291317030190583e-30, \"prior_loss\": 2.2229687271970192e-30, \"reason\": \"\", \"reconstructed\": [0.6, 0.40000000000000013], \"residual\": [0.0, -1.1102230246251565e-16], \"status\": \"ok\"}"|"exact"|—|PASS|
|D02|estimate.immutable|true|true|"exact"|—|PASS|
|D02|information.repeat|"{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}"|"{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}"|"exact"|—|PASS|
|D02|information.immutable|true|true|"exact"|—|PASS|
|D02|bounds.repeat|"{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}"|"{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}"|"exact"|—|PASS|
|D02|bounds.immutable|true|true|"exact"|—|PASS|
|D03|raw_cov|[[0.0024,0.0],[0.0,0.005399999999999999]]|{"max_abs_error":1.6653345369377347e-18,"value":[[0.0024,1.6653345369377347e-18],[1.6653345369377347e-18,0.005399999999999999]]}|1e-12|—|PASS|
|D03|intrinsic_T|[[0.0023749999999999995,0.0],[0.0,0.004624999999999999]]|{"max_abs_error":1.2488567692835508e-18,"value":[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]}|1e-12|—|PASS|
|D03|mean_M|[[0.0006937499999999999,0.0],[0.0,0.0012562499999999998]]|{"max_abs_error":3.1250314361757125e-19,"value":[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]]}|1e-12|—|PASS|
|D03|precision_K|[[217.24372029871023,-108.62186014935511,-108.62186014935511],[-108.62186014935511,139.3268705635192,-30.705010414164104],[-108.62186014935511,-30.705010414164104,139.3268705635192]]|{"max_abs_error":5.684341886080802e-14,"value":[[217.24372029871023,-108.62186014935517,-108.62186014935506],[-108.62186014935517,139.32687056351926,-30.705010414164114],[-108.62186014935506,-30.705010414164114,139.32687056351918]]}|1e-12|—|PASS|
|D03|center|[0.6,0.1,0.3]|{"max_abs_error":1.1102230246251565e-16,"value":[0.6000000000000001,0.1,0.30000000000000004]}|1e-12|—|PASS|
|D03|hard_center|[0.65,0,0.35]|{"max_abs_error":2.220446049250313e-16,"value":[0.6499999999999998,-4.606468600199157e-17,0.34999999999999976]}|1e-12|—|PASS|
|D03|hard_T_same|[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]|{"max_abs_error":0.0,"value":[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]}|1e-12|—|PASS|
|D03|floor_identical|[0.0001,0.0001]|{"max_abs_error":0.0,"value":[0.0001,0.0001]}|1e-12|—|PASS|
|D03|rotated_eigenvalues|[0.001866175514774443,0.005033824485225557]|{"max_abs_error":3.469446951953614e-18,"value":[0.0018661755147744443,0.005033824485225553]}|1e-12|—|PASS|
|D03|rotated_T|[[0.0031724999999999995,-0.001155],[-0.001155,0.0037275]]|{"max_abs_error":2.168404344971009e-18,"value":[[0.0031724999999999987,-0.001154999999999998],[-0.0011549999999999983,0.0037274999999999977]]}|1e-12|—|PASS|
|D03|rotated_M|[[0.0008931249999999999,-0.00026375],[-0.00026375,0.001056875]]|{"max_abs_error":6.505213034913027e-19,"value":[[0.0008931249999999997,-0.0002637499999999995],[-0.00026374999999999955,0.0010568749999999994]]}|1e-12|—|PASS|
|D04|bulk.mass|[0.6,0.2,0.2]|{"max_abs_error":5.551115123125783e-17,"value":[0.6,0.20000000000000007,0.20000000000000007]}|1e-08|—|PASS|
|D05|bulk.kkt_bound|true|true|"exact"|—|PASS|
|D04|phase.mass|[0.6,0.1,0.3]|{"max_abs_error":1.3877787807814457e-16,"value":[0.6000000000000001,0.10000000000000014,0.2999999999999999]}|1e-08|—|PASS|
|D05|phase.kkt_bound|true|true|"exact"|—|PASS|
|D04|redundant.mass|[0.6,0.2,0.2]|{"max_abs_error":1.1102230246251565e-16,"value":[0.6000000000000001,0.2,0.2]}|1e-08|—|PASS|
|D05|redundant.kkt_bound|true|true|"exact"|—|PASS|
|D04|lambda0_equals_A0|[0.615,0.19250000000000003,0.19250000000000003]|{"max_abs_error":0.0,"value":[0.615,0.19250000000000003,0.19250000000000003]}|1e-08|—|PASS|
|D04|fixedQ_bulk_min_norm|[0.6,0.2,0.2]|{"max_abs_error":4.440892098500626e-16,"value":[0.5999999999999995,0.19999999999999962,0.19999999999999962]}|1e-08|—|PASS|
|D04|fixedQ_lambda0_min_norm|[0.6,0.2,0.2]|{"max_abs_error":4.440892098500626e-16,"value":[0.5999999999999995,0.19999999999999962,0.19999999999999962]}|1e-08|—|PASS|
|D06|oneunit_center|[0.6007162250709892,0.0984013492518974,0.3008824256771134]|{"max_abs_error":1.249000902703301e-16,"value":[0.6007162250709892,0.09840134925189753,0.30088242567711343]}|1e-12|—|PASS|
|D06|oneunit_M|[[0.000912280701754386,0.0],[0.0,0.000912280701754386]]|{"max_abs_error":6.899993029142859e-22,"value":[[0.000912280701754386,-6.899993029142859e-22],[-3.4424225788065094e-22,0.000912280701754386]]}|1e-12|—|PASS|
|D06|empty_center|[0.6,0.1,0.3]|{"max_abs_error":0.0,"value":[0.6,0.1,0.3]}|1e-12|—|PASS|
|D06|wholeunit_LOO_center|[0.5985675498580215,0.10133649417729329,0.30009595596468525]|{"max_abs_error":0.0,"value":[0.5985675498580215,0.10133649417729329,0.30009595596468525]}|1e-12|—|PASS|
|D06|excluded_changes_no_effect|[0.5985675498580215,0.10133649417729329,0.30009595596468525]|{"max_abs_error":0.0,"value":[0.5985675498580215,0.10133649417729329,0.30009595596468525]}|1e-12|—|PASS|
|D07|soft_A_gt_.1|true|true|"exact"|—|PASS|
|D07|hard_A_zero|0|{"abs_error":4.7251753127059576e-17,"value":-4.7251753127059576e-17}|1e-09|—|PASS|
|D07|soft_hard_T_equal|[[0.01,0.0],[0.0,0.01]]|{"max_abs_error":0.0,"value":[[0.01,0.0],[0.0,0.01]]}|1e-12|—|PASS|
|D08|C.ranks|[2,2,1]|{"max_abs_error":0.0,"value":[2,2,1]}|0|—|PASS|
|D08|Ct.ranks|[2,2,1]|{"max_abs_error":0.0,"value":[2,2,1]}|0|—|PASS|
|D08|Ch.ranks|[3,3,2]|{"max_abs_error":0.0,"value":[3,3,2]}|0|—|PASS|
|D08|hard_C_rank|1|{"abs_error":0,"value":1}|"exact"|0%|PASS|
|D08|joint_permutation_mass|[0.614747697236684,0.09262615138165695,0.2926261513816592]|{"max_abs_error":8.881784197001252e-16,"value":[0.6147476972366841,0.0926261513816577,0.2926261513816583]}|1e-08|—|PASS|
|D08|joint_permutation_objective|0.24637257016111222|{"abs_error":5.551115123125783e-17,"value":0.24637257016111228}|1e-12|2.25314e-14%|PASS|
|D09|bulk_bounds_lo|[0.6,0,0]|{"max_abs_error":9.999778782798785e-13,"value":[0.599999999999,0.0,0.0]}|1e-08|—|PASS|
|D09|bulk_bounds_hi|[0.6,0.4,0.4]|{"max_abs_error":9.999778782798785e-13,"value":[0.600000000001,0.400000000001,0.400000000001]}|1e-08|—|PASS|
|D09|phase_singleton|[0.6,0.1,0.3]|{"max_abs_error":1.999955756559757e-12,"value":[0.599999999999,0.099999999999,0.29999999999800003]}|1e-08|—|PASS|
|D09|incompatible_status|"infeasible_envelope"|"infeasible_envelope"|"exact"|—|PASS|
|D09|incompatible_null|null|null|"exact"|—|PASS|
|D11|pre_run_required_ids|"D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16"|"D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16"|"exact"|—|PASS|
|D16|AST.phase_models.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.measurement_experiment.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.test_phase_models.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.test_experiment.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D01|estimate.D.empty|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.wrong|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.D.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.nonsym|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.cov.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.(False, False, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.(1, 1, 1)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.(True, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.support.bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.empty|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.wrong|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.D.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.nonsym|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.cov.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.(False, False, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.(1, 1, 1)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.(True, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.support.bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.empty|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.wrong|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.ragged|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.D.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.cov.bool|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.cov.complex|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.cov.inf|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.cov.nonsym|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.cov.singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.support.(False, False, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.support.(1, 1, 1)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.support.(True, False)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|info.support.bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.failed|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.failed|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.missing|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.missing|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.T_negative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.T_negative|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.M_singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.M_singular|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.K_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.K_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.center_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.center_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.prior.diag_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.prior.diag_bad|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.notlist|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.badunit|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.badID|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.badD|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.badY|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|update.units.badCov|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.multiplier.-1|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.multiplier.0|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.multiplier.nan|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.multiplier.True|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|bounds.multiplier.3|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.strength.True|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.strength.1|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|estimate.strength.(1+1j)|"ValueError"|"ValueError"|"exact"|—|PASS|
|D01|signed.calibration|"ok"|"ok"|"exact"|—|PASS|
|D02|fit.repeat|"{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"exact"|—|PASS|
|D02|fit.input_unchanged|true|true|"exact"|—|PASS|
|D02|fit.no_return_alias|true|true|"exact"|—|PASS|
|D02|update.repeat|"{\"center\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 2.220446049250313e-16, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 2.2572225151953736e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 1.7554167342883506e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"{\"center\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 2.220446049250313e-16, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 2.2572225151953736e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 1.7554167342883506e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}"|"exact"|—|PASS|
|D02|update.input_unchanged|true|true|"exact"|—|PASS|
|D02|update.no_return_alias|true|true|"exact"|—|PASS|
|D02|estimate.repeat|"{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 0.0, \"kkt_residual\": 5.660956118940746e-17, \"mass\": [0.6, 0.10000000000000006, 0.30000000000000004], \"objective\": 2.2291317030190583e-30, \"prior_loss\": 2.2229687271970192e-30, \"reason\": \"\", \"reconstructed\": [0.6, 0.40000000000000013], \"residual\": [0.0, -1.1102230246251565e-16], \"status\": \"ok\"}"|"{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 0.0, \"kkt_residual\": 5.660956118940746e-17, \"mass\": [0.6, 0.10000000000000006, 0.30000000000000004], \"objective\": 2.2291317030190583e-30, \"prior_loss\": 2.2229687271970192e-30, \"reason\": \"\", \"reconstructed\": [0.6, 0.40000000000000013], \"residual\": [0.0, -1.1102230246251565e-16], \"status\": \"ok\"}"|"exact"|—|PASS|
|D02|estimate.input_unchanged|true|true|"exact"|—|PASS|
|D02|estimate.no_return_alias|true|true|"exact"|—|PASS|
|D02|info.repeat|"{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}"|"{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}"|"exact"|—|PASS|
|D02|info.input_unchanged|true|true|"exact"|—|PASS|
|D02|info.no_return_alias|true|true|"exact"|—|PASS|
|D02|bounds.repeat|"{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}"|"{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}"|"exact"|—|PASS|
|D02|bounds.input_unchanged|true|true|"exact"|—|PASS|
|D02|bounds.no_return_alias|true|true|"exact"|—|PASS|
|D02|isolated_import_exit|0|0|"exact"|—|PASS|
|D02|isolated_import_stdout|""|""|"exact"|—|PASS|
|D02|isolated_import_stderr|""|""|"exact"|—|PASS|
|D03|diagnostic.raw_mean|true|true|"exact"|—|PASS|
|D03|diagnostic.raw_tangent_cov|true|true|"exact"|—|PASS|
|D03|diagnostic.deconvolved_eigenvalues|true|true|"exact"|—|PASS|
|D03|diagnostic.floored_eigenvalues|true|true|"exact"|—|PASS|
|D03|diagnostic.projection_distance|true|true|"exact"|—|PASS|
|D04|fixedQ_fullrank|[0.6,0.230989010989011,0.16901098901098902]|[0.5999999999999995,0.23098901098901087,0.16901098901098838]|1e-08|—|PASS|
|D04|fixedQ_boundary_0|[0,0.5,0.5]|[-1.1014039518277619e-17,0.4999999999999998,0.4999999999999998]|1e-08|—|PASS|
|D04|fixedQ_boundary_1|[1,0,0]|[0.9999999999999996,-1.8445061867120456e-16,-1.8445061867120456e-16]|1e-08|—|PASS|
|D04|fixedQ_positive_strength_center|[0.6000000000000001,0.1,0.30000000000000004]|[0.5999999999999995,0.09999999999999992,0.2999999999999993]|1e-08|—|PASS|
|D05|interior.status|"ok"|"ok"|"exact"|—|PASS|
|D05|interior.feasible|true|true|"exact"|—|PASS|
|D05|interior.certified|true|true|"exact"|—|PASS|
|D05|interior.directional_min_gap|true|true|"exact"|—|PASS|
|D05|interior.perturbed_rejected|true|true|"exact"|—|PASS|
|D05|edge.status|"ok"|"ok"|"exact"|—|PASS|
|D05|edge.feasible|true|true|"exact"|—|PASS|
|D05|edge.certified|true|true|"exact"|—|PASS|
|D05|edge.directional_min_gap|true|true|"exact"|—|PASS|
|D05|edge.perturbed_rejected|true|true|"exact"|—|PASS|
|D05|vertex.status|"ok"|"ok"|"exact"|—|PASS|
|D05|vertex.feasible|true|true|"exact"|—|PASS|
|D05|vertex.certified|true|true|"exact"|—|PASS|
|D05|vertex.directional_min_gap|true|true|"exact"|—|PASS|
|D05|vertex.perturbed_rejected|true|true|"exact"|—|PASS|
|D05|hard.status|"ok"|"ok"|"exact"|—|PASS|
|D05|hard.feasible|true|true|"exact"|—|PASS|
|D05|hard.certified|true|true|"exact"|—|PASS|
|D05|hard.directional_min_gap|true|true|"exact"|—|PASS|
|D05|hard.perturbed_rejected|true|true|"exact"|—|PASS|
|D05|fixed.status|"ok"|"ok"|"exact"|—|PASS|
|D05|fixed.feasible|true|true|"exact"|—|PASS|
|D05|fixed.certified|true|true|"exact"|—|PASS|
|D05|fixed.directional_min_gap|true|true|"exact"|—|PASS|
|D05|fixed.perturbed_rejected|true|true|"exact"|—|PASS|
|D04|correlated_A2_stationary_mass|[0.6147476972366841,0.09262615138165814,0.29262615138165776]|[0.614747697236684,0.09262615138165695,0.2926261513816592]|1e-08|—|PASS|
|D04|correlated_A2_objective|0.2463725701611168|0.24637257016111222|1e-12|1.85884e-12%|PASS|
|D04|correlated_A2_signed_residual|[0.005252302763315897,0.004747697236684112]|[0.005252302763316008,0.00474769723668389]|1e-12|—|PASS|
|D05|interior.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|interior.primal|true|true|"exact"|—|PASS|
|D05|edge.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|edge.primal|true|true|"exact"|—|PASS|
|D05|vertex.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|vertex.primal|true|true|"exact"|—|PASS|
|D05|rankdef.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|rankdef.primal|true|true|"exact"|—|PASS|
|D05|hard.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|hard.primal|true|true|"exact"|—|PASS|
|D05|fixed.independent_kkt_lp|true|true|"exact"|—|PASS|
|D05|fixed.primal|true|true|"exact"|—|PASS|
|D06|cross_repeat_intrinsic_nonzero|true|true|"exact"|—|PASS|
|D06|repeat_mean_cov|[[0.0009093073347693006,0.0],[0.0,0.001]]|[[0.0009093073347693006,0.0],[0.0,0.001]]|1e-12|—|PASS|
|D06|wrong_independent_differs|true|true|"exact"|—|PASS|
|D06|LOO_x|[0.6007162250709892,0.09840134925189753,0.30088242567711343]|[0.6007162250709892,0.09840134925189753,0.30088242567711343]|1e-12|—|PASS|
|D06|LOO_M_x|[[0.000912280701754386,-6.899993029142859e-22],[-3.4424225788065094e-22,0.000912280701754386]]|[[0.000912280701754386,-6.899993029142859e-22],[-3.4424225788065094e-22,0.000912280701754386]]|1e-12|—|PASS|
|D06|LOO_y|[0.6,0.10000000000000012,0.3]|[0.6,0.10000000000000012,0.3]|1e-12|—|PASS|
|D06|LOO_M_y|[[0.0009093073347693006,0.0],[0.0,0.001]]|[[0.0009093073347693006,0.0],[0.0,0.001]]|1e-12|—|PASS|
|D08|C.tangent_singular|[138.01311186847087,0.0]|[138.01311186847084,9.896688101312627e-16]|1e-08|—|PASS|
|D08|Ct.tangent_singular|[140.7052941362897,0.0]|[140.70529413628972,2.272935496515929e-15]|1e-08|—|PASS|
|D08|Ch.tangent_singular|[139.61674589653614,34.94924862636929]|[139.61674589653617,34.94924862636929]|1e-08|—|PASS|
|D08|correlation_objective_diff|true|true|"exact"|—|PASS|
|D09|bulk.lower|[0.57,-0.0,0.0]|[0.57,0.0,0.0]|1e-08|—|PASS|
|D09|bulk.upper|[0.63,0.43000000000000005,0.43000000000000005]|[0.63,0.43000000000000005,0.43000000000000005]|1e-08|—|PASS|
|D09|phase.lower|[0.57,0.04000000000000001,0.20999999999999996]|[0.57,0.04000000000000001,0.21]|1e-08|—|PASS|
|D09|phase.upper|[0.63,0.16,0.39]|[0.63,0.16,0.39]|1e-08|—|PASS|
|D09|nested_width|true|true|"exact"|—|PASS|
|D09|hard_width_A|0|0.0|1e-08|—|PASS|
|D09|fixedQ_width_Q|0|0.0|1e-08|—|PASS|
|D10|parent_T_(True, True, True)|[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]|[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]|1e-12|—|PASS|
|D10|parent_M_(True, True, True)|[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]]|[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]]|1e-12|—|PASS|
|D10|(True, True, True).None.A0.0.mass|[0.615,0.1925,0.1925]|[0.615,0.1925000000000001,0.19250000000000006]|1e-08|—|PASS|
|D10|(True, True, True).None.A1.0.mass|[0.6,0.1000000000000003,0.30000000000000016]|[0.6000000000000001,0.1,0.30000000000000004]|1e-08|—|PASS|
|D10|(True, True, True).None.A2.0.mass|[0.615,0.1925,0.1925]|[0.615,0.1925000000000001,0.19250000000000006]|1e-08|—|PASS|
|D10|(True, True, True).None.A2.0.01.mass|[0.6149974342475013,0.09250128287658656,0.29250128287591204]|[0.6149974342475013,0.09250128287622947,0.29250128287626925]|1e-08|—|PASS|
|D10|(True, True, True).None.A2.1.mass|[0.6147476972366848,0.09262615138165119,0.29262615138166526]|[0.614747697236684,0.09262615138165695,0.2926261513816592]|1e-08|—|PASS|
|D10|(True, True, True).0.6.A0.0.mass|[0.6,0.2,0.2]|[0.5999999999999995,0.19999999999999962,0.19999999999999962]|1e-08|—|PASS|
|D10|(True, True, True).0.6.A1.0.mass|[0.6000000000000004,0.10000000000000003,0.3000000000000001]|[0.6,0.1,0.3]|1e-08|—|PASS|
|D10|(True, True, True).0.6.A2.0.mass|[0.6,0.2,0.2]|[0.5999999999999995,0.19999999999999962,0.19999999999999962]|1e-08|—|PASS|
|D10|(True, True, True).0.6.A2.0.01.mass|[0.5999999999999851,0.0999999999999653,0.30000000000005433]|[0.5999999999999995,0.10000000000009415,0.2999999999999051]|1e-08|—|PASS|
|D10|(True, True, True).0.6.A2.1.mass|[0.5999999999948382,0.10000000000110289,0.3000000000010307]|[0.5999999999999995,0.10000000000000006,0.2999999999999992]|1e-08|—|PASS|
|D10|parent_T_(True, False, True)|[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]|[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]]|1e-12|—|PASS|
|D10|parent_M_(True, False, True)|[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]]|[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]]|1e-12|—|PASS|
|D10|(True, False, True).None.A0.0.mass|[0.615,0.0,0.385]|[0.6149999999999998,-4.690318705306234e-17,0.38499999999999984]|1e-08|—|PASS|
|D10|(True, False, True).None.A1.0.mass|[0.6499999999999995,-1.132993058676088e-16,0.3499999999999998]|[0.6499999999999998,-4.606468600199157e-17,0.34999999999999976]|1e-08|—|PASS|
|D10|(True, False, True).None.A2.0.mass|[0.615,0.0,0.385]|[0.6149999999999998,-4.690318705306234e-17,0.38499999999999984]|1e-08|—|PASS|
|D10|(True, False, True).None.A2.0.01.mass|[0.6150070278138804,-1.4232839855673103e-15,0.3849929721861204]|[0.6150070278138804,-4.6903018686510176e-17,0.38499297218611916]|1e-08|—|PASS|
|D10|(True, False, True).None.A2.1.mass|[0.615689083325587,-9.314921217736359e-16,0.3843109166744108]|[0.6156890833255888,-4.688667856469715e-17,0.38431091667441075]|1e-08|—|PASS|
|D10|(True, False, True).0.6.A0.0.mass|[0.6,0.0,0.4]|[0.6,-1.2805796264108082e-16,0.3999999999999999]|1e-08|—|PASS|
|D10|(True, False, True).0.6.A1.0.mass|[0.6,6.938893903907228e-17,0.4]|[0.6,0.0,0.4]|1e-08|—|PASS|
|D10|(True, False, True).0.6.A2.0.mass|[0.6,0.0,0.4]|[0.6,-1.2805796264108082e-16,0.3999999999999999]|1e-08|—|PASS|
|D10|(True, False, True).0.6.A2.0.01.mass|[0.5999999999999996,-1.792969616876736e-14,0.40000000000001773]|[0.6,-1.2805796264108082e-16,0.3999999999999999]|1e-08|—|PASS|
|D10|(True, False, True).0.6.A2.1.mass|[0.5999999999999961,3.519427571442324e-14,0.39999999999999014]|[0.6,-1.2805796264108082e-16,0.3999999999999999]|1e-08|—|PASS|
|D11|design_digest|"7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad"|"7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad"|"exact"|—|PASS|
|D11|source_file_count|5|5|"exact"|0%|PASS|
|D11|parent_nonimport|"read-only reference; no import or call by study code"|"read-only reference; no import or call by study code"|"exact"|—|PASS|
|D11|package_pin|"d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d"|"d9a0b27676a0cb3a4acb300a3f6b2ebc845d205d"|"exact"|—|PASS|
|D11|historical_paths|11|11|"exact"|0%|PASS|
|D11|historical_seed_count|2009|2009|"exact"|0%|PASS|
|D11|new_seed_count|2000|2000|"exact"|0%|PASS|
|D11|collision_count|0|0|"exact"|—|PASS|
|D11|historical_hash.source_manifest.json|"d3ce9ada450f22eecf0195131f690508b3364bd7e9cf82ff68ee1264ca10670a"|"d3ce9ada450f22eecf0195131f690508b3364bd7e9cf82ff68ee1264ca10670a"|"exact"|—|PASS|
|D11|historical_hash.manifest.json|"21d87288b39cbc0acadf492150e19e9baa8a94e8337281f1ed1a6acd55edea36"|"21d87288b39cbc0acadf492150e19e9baa8a94e8337281f1ed1a6acd55edea36"|"exact"|—|PASS|
|D11|historical_hash.fixture_manifest.json|"b2f7be63c55e6f933152588721fd0477f531103dba6814ce81c666c389b6cf9d"|"b2f7be63c55e6f933152588721fd0477f531103dba6814ce81c666c389b6cf9d"|"exact"|—|PASS|
|D11|historical_hash.baseline_freeze.json|"02ea077d3c96d9fe682079d3253088c731878b0a2d80962be748c231fffdf7b4"|"02ea077d3c96d9fe682079d3253088c731878b0a2d80962be748c231fffdf7b4"|"exact"|—|PASS|
|D11|historical_hash.manifest.json|"359bf2b7a8f7ba3d1a1fcfab9852416976c5889ada19a56d9d53d572f8595e9a"|"359bf2b7a8f7ba3d1a1fcfab9852416976c5889ada19a56d9d53d572f8595e9a"|"exact"|—|PASS|
|D11|historical_hash.preregistration.json|"09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa"|"09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa"|"exact"|—|PASS|
|D11|historical_hash.seeds.json|"eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa"|"eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa"|"exact"|—|PASS|
|D11|historical_hash.seeds.json|"eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa"|"eb1bc446b2d316414d787aa1f0bcc4349cd0df9a9fdb7cb15132062dd56ca8aa"|"exact"|—|PASS|
|D11|historical_hash.sim-spec.md|"0faa538b659d532f46fdb203720ac451e197c246da2b108e4e910039c05bd711"|"0faa538b659d532f46fdb203720ac451e197c246da2b108e4e910039c05bd711"|"exact"|—|PASS|
|D11|historical_hash.sim-spec.md|"8c89c581ca1add70ffa0c7cca7ce20eef5dd9a5f7296c59b6afde848412f2b07"|"8c89c581ca1add70ffa0c7cca7ce20eef5dd9a5f7296c59b6afde848412f2b07"|"exact"|—|PASS|
|D11|historical_hash.preregistration.json|"09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa"|"09bd689b886dc0b979c7bdb4587832b439291b7e5cecded2e645c7086555baaa"|"exact"|—|PASS|
|D11|unfrozen_run_rejected|"FileNotFoundError"|"FileNotFoundError"|"exact"|—|PASS|
|D11|unfrozen_generator_calls|0|0|"exact"|—|PASS|
|D12|truth_not_opened_in_predict|false|false|"exact"|—|PASS|
|D12|evaluation_design_bulk_only|true|true|"exact"|—|PASS|
|D12|nested_budgets|[0,2,5]|[0,2,5]|"exact"|—|PASS|
|D12|cell4_paired_support|["soft","hard"]|["soft","hard"]|"exact"|—|PASS|
|D12|stream_unique|2000|2000|"exact"|0%|PASS|
|D16|label_changed_files|["research/emc-part2b/prior_guided/FINITE_CALIBRATION_RESULTS.md","research/emc-part2b/prior_guided/PRIOR_SENSITIVITY.md"]|["research/emc-part2b/prior_guided/FINITE_CALIBRATION_RESULTS.md","research/emc-part2b/prior_guided/PRIOR_SENSITIVITY.md"]|"exact"|—|PASS|
|D16|label_direct_child|"07b3488dfbc6513ad9172655bebe2566fbeaa205"|"07b3488dfbc6513ad9172655bebe2566fbeaa205"|"exact"|—|PASS|
|D16|all_diff_scoped|true|true|"exact"|—|PASS|
|D16|source_excludes_old_parent_import|true|true|"exact"|—|PASS|
|D16|review_before_now|true|true|"exact"|—|PASS|
|D16|parent_hash|"e23a58cebeb954776c45877af66ed129dc28eba7fc1f1683a2a6575093f7bab2"|"e23a58cebeb954776c45877af66ed129dc28eba7fc1f1683a2a6575093f7bab2"|"exact"|—|PASS|
|D16|AST.phase_models.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.measurement_experiment.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.test_phase_models.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D16|AST.test_experiment.py|"parse_ok"|"parse_ok"|"exact"|—|PASS|
|D11|review_reject_STOP|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_PASS_WITH_NOTE|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_self_review|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_future|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_stale_design|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_stale_prereg|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|review_reject_missing_review_md|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|design_byte_reject_preregistration.json|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|design_byte_reject_MATHEMATICAL_DESIGN.md|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|restored_review_accept|"qar-phase-prereg-v1"|"qar-phase-prereg-v1"|"exact"|—|PASS|
|D11|seed_collision_reject|"RuntimeError"|"RuntimeError"|"exact"|—|PASS|
|D11|wall_cap_minutes|90|90|"exact"|0%|PASS|
|D11|output_cap_MB|500|500|"exact"|0%|PASS|
|D11|cpu_workers|2|2|"exact"|0%|PASS|
|D11|actual_threads|true|true|"exact"|—|PASS|
|D11|run_data_absent|false|false|"exact"|—|PASS|
|D11|run_results_absent|false|false|"exact"|—|PASS|
|D12|truth_read_functions|["score","study_diagnostics"]|["score","study_diagnostics"]|"exact"|—|PASS|
|D12|whole_unit_exclusion_branch|true|true|"exact"|—|PASS|
|D12|N_zero_update_branch|true|true|"exact"|—|PASS|
|D12|evaluation_only_bulk_branch|true|true|"exact"|—|PASS|
|D12|selection_fixed_prefix|true|true|"exact"|—|PASS|
|D12|no_pool_unpurchased_scoring|true|true|"exact"|—|PASS|
|D12|predictions_hash_before_truth|true|true|"exact"|—|PASS|
|D12|run_uses_distinct_observed_files|4|4|"exact"|0%|PASS|

## Before and after parent compatibility

|Metric|Before — prior blocked build|After — current build|Change|Interpretation|
|---|---:|---:|---:|---|
|Fixed-Q bulk A0 Anatase|0.4|0.2|−0.2|Corrected to exact minimum-norm tie|
|Fixed-Q bulk A0 Rutile|≈0|0.2|+0.2|Corrected to exact minimum-norm tie|
|Fixed-Q A2 strength 0 Anatase|0.4|0.2|−0.2|Corrected to A0 tie rule|
|Fixed-Q A2 strength 0 Rutile|≈0|0.2|+0.2|Corrected to A0 tie rule|

Current parent compatibility comparisons: 24 metric rows passed at mass atol=1e-8, rtol=0 in `tester_preflight_results.json`; earlier audit recorded four fixed-Q failures at maximum mass error 0.20000000000000023. No historical pilot run was repeated.

## Environment and tools

- Python 3.12.3; NumPy 2.5.3; SciPy 1.18.1; matplotlib 3.11.2; pytest 9.1.1; R 4.3.3; Linux 7.0.0-34-generic x86_64.
- Python executable `/tmp/bif-v3-world1-validation-env-20261023/bin/python`. One thread each for OPENBLAS, OMP, and MKL.
- `ruff` and `mypy` were unavailable in PATH. This additive research directory is not a package build target; no documentation build applies. AST parsing of four new Python source/test files passed.
- Environment and source freeze cannot be certified because `--freeze` failed. Source partial manifest includes both new tests, both source modules, `generation.R`, parent non-import reference, and pinned package provenance.

## Failure routing and next gate

Simulator: change the import-version scanner to parse Python files only while retaining the R source hash and separate R environment probe. Then rerun deterministic certification, actual `--freeze`, D11 source/environment negative probes, and only then the one bounded `--run`. Preserve the partial failed-freeze evidence. No source/config/package/seed/tolerance change was made by tester.
