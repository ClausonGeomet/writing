# Independent tester audit — BLOCK before sampling

## Verdict and timing

Pre-run validation is BLOCK. No `--freeze` or `--run` was invoked; no comparison data were drawn. The public review precedes this validation. D13–D15 remain pending by design until a lawful run exists. The simulator corrected the first certification lifecycle defect in commit `4d5635f`, but the source freeze omission and builder tie defect remain at this audit time. Source changes require rerunning checks and a fresh freeze before any draw.

## Independent per-test result table

The full numerical record is also in `research/emc-part2b/phase_sensitive/run/audit/tester_oracle_results.json` (135 metric rows). Tolerances below are exactly those used; comparisons marked exact used exact equality. No failed tolerance was changed.

| Check | Metric | Expected | Actual | Tolerance | Verdict |
| --- | --- | --- | --- | --- | --- |
| D01 | fit_initial.Y.ragged | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.posinf | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.neginf | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.string | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.bool | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.wrongshape | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.n0 | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.Y.n1 | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.R.singular | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.R.negative | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.R.asymmetric | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.R.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.R.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.floorzero | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.floornegative | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.shrinknegative | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.shrinkhigh | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.supportnone | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.supportbad | "ValueError" | "ValueError" | exact | PASS |
| D01 | fit_initial.supportshort | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.posinf | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.neginf | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.string | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.bool | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.wrongshape | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.y.ragged | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.cov.singular | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.cov.negative | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.cov.asymmetric | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.cov.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.ragged | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.string | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.bool | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.D.wrongshape | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.support.allfalse | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.support.nonbool | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.support.short | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.fixedQ.low | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.fixedQ.high | "ValueError" | "ValueError" | exact | PASS |
| D01 | estimate.fixedQ.conflict | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.posinf | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.neginf | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.string | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.bool | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.wrongshape | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.y.ragged | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.cov.singular | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.cov.negative | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.cov.asymmetric | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.cov.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.ragged | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.nan | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.string | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.bool | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.complex | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.D.wrongshape | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.support.allfalse | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.support.nonbool | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.support.short | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.fixedQ.low | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.fixedQ.high | "ValueError" | "ValueError" | exact | PASS |
| D01 | bounds.fixedQ.conflict | "ValueError" | "ValueError" | exact | PASS |
| D01 | unknownmethod | "ValueError" | "ValueError" | exact | PASS |
| D01 | A0prior | "ValueError" | "ValueError" | exact | PASS |
| D01 | A1data | "ValueError" | "ValueError" | exact | PASS |
| D01 | A2noprior | "ValueError" | "ValueError" | exact | PASS |
| D01 | negstrength | "ValueError" | "ValueError" | exact | PASS |
| D01 | nanstrength | "ValueError" | "ValueError" | exact | PASS |
| D01 | badprior | "ValueError" | "ValueError" | exact | PASS |
| D01 | duplicateunits | "ValueError" | "ValueError" | exact | PASS |
| D01 | unknownexclude | "ValueError" | "ValueError" | exact | PASS |
| D01 | signed.estimate.status | "ok" | "ok" | exact | PASS |
| D01 | signed.bounds.status | true | true | exact | PASS |
| D02 | fit.repeat | "{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}" | "{\"center\": [0.6000000000000001, 0.1, 0.30000000000000004], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1441.4414414414416, -3.580182890614511e-13], [-3.585711297839553e-13, 796.0199004975126]], \"mean_kkt_residual\": 3.469446951953615e-17, \"mean_score\": [470.7728034177882, -112.57421392024654], \"n_cal\": 4, \"n_update\": 0, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]]}, \"mean_cov\": [[0.0006937499999999999, 3.120213299707044e-19], [3.1250314361757125e-19, 0.0012562499999999998]], \"precision\": [[217.24372029871023, -108.62186014935517, -108.62186014935506], [-108.62186014935517, 139.32687056351926, -30.705010414164114], [-108.62186014935506, -30.705010414164114, 139.32687056351918]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835508e-18], [1.2488567692835506e-18, 0.004624999999999999]]}" | exact | PASS |
| D02 | fit.immutable | true | true | exact | PASS |
| D02 | update.repeat | "{\"center\": [0.6, 0.10000000000000003, 0.30000000000000016], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 5.335253217734519e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 2.8441001681421824e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}" | "{\"center\": [0.6, 0.10000000000000003, 0.30000000000000016], \"diagnostics\": {\"deconvolved_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"excluded_unit_id\": null, \"floored_eigenvalues\": [0.0019999999999999996, 0.004999999999999999], \"included_unit_ids\": [\"x\"], \"mean_constraint_violation\": 0.0, \"mean_information\": [[1442.7705658807172, -3.5829470942270316e-13], [-3.582947094227032e-13, 796.0199004975126]], \"mean_kkt_residual\": 5.335253217734519e-17, \"mean_score\": [471.2068936419066, -112.57421392024654], \"n_cal\": 4, \"n_update\": 1, \"projection_distance\": 1.2412670766236366e-16, \"raw_mean\": [0.6, 0.1, 0.3], \"raw_tangent_cov\": [[0.0024, 1.6653345369377347e-18], [1.6653345369377347e-18, 0.005399999999999999]], \"update_projection_distance\": 2.8441001681421824e-16}, \"mean_cov\": [[0.0006931108962495124, 3.119745712565944e-19], [3.119745712565944e-19, 0.0012562499999999998]], \"precision\": [[217.2889733163187, -108.64448665815941, -108.64448665815931], [-108.64448665815941, 139.3381838179214, -30.69369715976199], [-108.64448665815931, -30.69369715976199, 139.3381838179213]], \"reason\": \"\", \"status\": \"ok\", \"tangent_cov\": [[0.0023749999999999995, 1.2488567692835506e-18], [1.2488567692835506e-18, 0.004624999999999999]]}" | exact | PASS |
| D02 | update.immutable | true | true | exact | PASS |
| D02 | estimate.repeat | "{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 2.220446049250313e-16, \"kkt_residual\": 1.132191223788149e-17, \"mass\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"objective\": 5.3011416154269e-31, \"prior_loss\": 5.239511857206508e-31, \"reason\": \"\", \"reconstructed\": [0.6000000000000001, 0.4], \"residual\": [-1.1102230246251565e-16, 0.0], \"status\": \"ok\"}" | "{\"active_support\": [0, 1, 2], \"assay_loss\": 6.162975822039155e-33, \"constraint_violation\": 2.220446049250313e-16, \"kkt_residual\": 1.132191223788149e-17, \"mass\": [0.6000000000000001, 0.09999999999999995, 0.3000000000000001], \"objective\": 5.3011416154269e-31, \"prior_loss\": 5.239511857206508e-31, \"reason\": \"\", \"reconstructed\": [0.6000000000000001, 0.4], \"residual\": [-1.1102230246251565e-16, 0.0], \"status\": \"ok\"}" | exact | PASS |
| D02 | estimate.immutable | true | true | exact | PASS |
| D02 | information.repeat | "{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}" | "{\"rank_augmented\": 2, \"rank_raw\": 2, \"rank_support_tangent\": 1, \"rank_tangent\": 1, \"singular_augmented\": [2.1753277471610746, 1.126032500610494, 1.1716210994770199e-17], \"singular_raw\": [1.4142135623730951, 1.0], \"singular_support_tangent\": [1.1547005383792517, 2.1885947940466786e-19], \"singular_tangent\": [1.1547005383792517, 0.0]}" | exact | PASS |
| D02 | information.immutable | true | true | exact | PASS |
| D02 | bounds.repeat | "{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}" | "{\"lower\": [0.0, 0.0, 0.0], \"max_constraint_violation\": 0.0, \"reason\": \"\", \"status\": \"ok\", \"upper\": [1.0, 1.0, 1.0], \"width\": [1.0, 1.0, 1.0]}" | exact | PASS |
| D02 | bounds.immutable | true | true | exact | PASS |
| D03 | raw_cov | [[0.0024,0.0],[0.0,0.005399999999999999]] | {"value":[[0.0024,1.6653345369377347e-18],[1.6653345369377347e-18,0.005399999999999999]],"max_abs_error":1.6653345369377347e-18} | 1e-12 | PASS |
| D03 | intrinsic_T | [[0.0023749999999999995,0.0],[0.0,0.004624999999999999]] | {"value":[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]],"max_abs_error":1.2488567692835508e-18} | 1e-12 | PASS |
| D03 | mean_M | [[0.0006937499999999999,0.0],[0.0,0.0012562499999999998]] | {"value":[[0.0006937499999999999,3.120213299707044e-19],[3.1250314361757125e-19,0.0012562499999999998]],"max_abs_error":3.1250314361757125e-19} | 1e-12 | PASS |
| D03 | precision_K | [[217.24372029871023,-108.62186014935511,-108.62186014935511],[-108.62186014935511,139.3268705635192,-30.705010414164104],[-108.62186014935511,-30.705010414164104,139.3268705635192]] | {"value":[[217.24372029871023,-108.62186014935517,-108.62186014935506],[-108.62186014935517,139.32687056351926,-30.705010414164114],[-108.62186014935506,-30.705010414164114,139.32687056351918]],"max_abs_error":5.684341886080802e-14} | 1e-12 | PASS |
| D03 | center | [0.6,0.1,0.3] | {"value":[0.6000000000000001,0.1,0.30000000000000004],"max_abs_error":1.1102230246251565e-16} | 1e-12 | PASS |
| D03 | hard_center | [0.65,0,0.35] | {"value":[0.6499999999999998,-4.606468600199157e-17,0.34999999999999976],"max_abs_error":2.220446049250313e-16} | 1e-12 | PASS |
| D03 | hard_T_same | [[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]] | {"value":[[0.0023749999999999995,1.2488567692835508e-18],[1.2488567692835506e-18,0.004624999999999999]],"max_abs_error":0.0} | 1e-12 | PASS |
| D03 | floor_identical | [0.0001,0.0001] | {"value":[0.0001,0.0001],"max_abs_error":0.0} | 1e-12 | PASS |
| D03 | rotated_eigenvalues | [0.001866175514774443,0.005033824485225557] | {"value":[0.0018661755147744443,0.005033824485225553],"max_abs_error":3.469446951953614e-18} | 1e-12 | PASS |
| D03 | rotated_T | [[0.0031724999999999995,-0.001155],[-0.001155,0.0037275]] | {"value":[[0.0031724999999999987,-0.001154999999999998],[-0.0011549999999999983,0.0037274999999999977]],"max_abs_error":2.168404344971009e-18} | 1e-12 | PASS |
| D03 | rotated_M | [[0.0008931249999999999,-0.00026375],[-0.00026375,0.001056875]] | {"value":[[0.0008931249999999997,-0.0002637499999999995],[-0.00026374999999999955,0.0010568749999999994]],"max_abs_error":6.505213034913027e-19} | 1e-12 | PASS |
| D04 | bulk.mass | [0.6,0.2,0.2] | {"value":[0.6000000000000001,0.2,0.2],"max_abs_error":1.1102230246251565e-16} | 1e-08 | PASS |
| D05 | bulk.kkt_bound | true | true | exact | PASS |
| D04 | phase.mass | [0.6,0.1,0.3] | {"value":[0.6,0.10000000000000012,0.3],"max_abs_error":1.1102230246251565e-16} | 1e-08 | PASS |
| D05 | phase.kkt_bound | true | true | exact | PASS |
| D04 | redundant.mass | [0.6,0.2,0.2] | {"value":[0.6000000000000001,0.2,0.19999999999999993],"max_abs_error":1.1102230246251565e-16} | 1e-08 | PASS |
| D05 | redundant.kkt_bound | true | true | exact | PASS |
| D04 | lambda0_equals_A0 | [0.6150000000000001,0.1925,0.1925] | {"value":[0.6150000000000001,0.1925,0.1925],"max_abs_error":0.0} | 1e-08 | PASS |
| D04 | fixedQ_bulk_min_norm | [0.6,0.2,0.2] | {"value":[0.6,0.39999999999999997,-2.302972069330675e-16],"max_abs_error":0.20000000000000023} | 1e-08 | FAIL |
| D04 | fixedQ_lambda0_min_norm | [0.6,0.2,0.2] | {"value":[0.6,0.39999999999999997,-2.302972069330675e-16],"max_abs_error":0.20000000000000023} | 1e-08 | FAIL |
| D06 | oneunit_center | [0.6007162250709892,0.0984013492518974,0.3008824256771134] | {"value":[0.6007162250709892,0.09840134925189742,0.3008824256771134],"max_abs_error":1.3877787807814457e-17} | 1e-12 | PASS |
| D06 | oneunit_M | [[0.000912280701754386,0.0],[0.0,0.000912280701754386]] | {"value":[[0.000912280701754386,-6.899993029142859e-22],[-3.4424225788065094e-22,0.000912280701754386]],"max_abs_error":6.899993029142859e-22} | 1e-12 | PASS |
| D06 | empty_center | [0.6,0.1,0.3] | {"value":[0.6,0.1,0.3],"max_abs_error":0.0} | 1e-12 | PASS |
| D06 | wholeunit_LOO_center | [0.5985675498580216,0.10133649417729323,0.30009595596468525] | {"value":[0.5985675498580216,0.10133649417729323,0.30009595596468525],"max_abs_error":0.0} | 1e-12 | PASS |
| D06 | excluded_changes_no_effect | [0.5985675498580216,0.10133649417729323,0.30009595596468525] | {"value":[0.5985675498580216,0.10133649417729323,0.30009595596468525],"max_abs_error":0.0} | 1e-12 | PASS |
| D07 | soft_A_gt_.1 | true | true | exact | PASS |
| D07 | hard_A_zero | 0 | {"value":-4.7251753127059576e-17,"abs_error":4.7251753127059576e-17} | 1e-09 | PASS |
| D07 | soft_hard_T_equal | [[0.01,0.0],[0.0,0.01]] | {"value":[[0.01,0.0],[0.0,0.01]],"max_abs_error":0.0} | 1e-12 | PASS |
| D08 | C.ranks | [2,2,1] | {"value":[2,2,1],"max_abs_error":0.0} | 0 | PASS |
| D08 | Ct.ranks | [2,2,1] | {"value":[2,2,1],"max_abs_error":0.0} | 0 | PASS |
| D08 | Ch.ranks | [3,3,2] | {"value":[3,3,2],"max_abs_error":0.0} | 0 | PASS |
| D08 | hard_C_rank | 1 | {"value":1,"abs_error":0} | exact | PASS |
| D08 | joint_permutation_mass | [0.6147476972366841,0.09262615138165445,0.2926261513816616] | {"value":[0.6147476972366841,0.09262615138166011,0.2926261513816559],"max_abs_error":5.717648576819556e-15} | 1e-08 | PASS |
| D08 | joint_permutation_objective | 0.24637257016111225 | {"value":0.24637257016111233,"abs_error":8.326672684688674e-17} | 1e-12 | PASS |
| D09 | bulk_bounds_lo | [0.6,0,0] | {"value":[0.599999999999,0.0,0.0],"max_abs_error":9.999778782798785e-13} | 1e-08 | PASS |
| D09 | bulk_bounds_hi | [0.6,0.4,0.4] | {"value":[0.600000000001,0.400000000001,0.400000000001],"max_abs_error":9.999778782798785e-13} | 1e-08 | PASS |
| D09 | phase_singleton | [0.6,0.1,0.3] | {"value":[0.599999999999,0.099999999999,0.29999999999800003],"max_abs_error":1.999955756559757e-12} | 1e-08 | PASS |
| D09 | incompatible_status | "infeasible_envelope" | "infeasible_envelope" | exact | PASS |
| D09 | incompatible_null | null | null | exact | PASS |
| D11 | pre_run_required_ids | "D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16" | "D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,D11,D12,D16" | exact | PASS |
| D16 | AST.phase_models.py | "parse_ok" | "parse_ok" | exact | PASS |
| D16 | AST.measurement_experiment.py | "parse_ok" | "parse_ok" | exact | PASS |
| D16 | AST.test_phase_models.py | "parse_ok" | "parse_ok" | exact | PASS |
| D16 | AST.test_experiment.py | "parse_ok" | "parse_ok" | exact | PASS |

## Named check coverage

| ID | State | Evidence / reason |
| --- | --- | --- |
| D01 | PARTIAL PASS | API validation probes in tester_oracle_results.json; exhaustive subcases still to complete. |
| D02 | PARTIAL PASS | Five API repeats/nonmutation in tester_oracle_results.json; isolated import/alias checks pending. |
| D03 | PARTIAL PASS | Analytic covariance, rotated, flooring, hard center in tester_oracle_results.json; signed prior row pending. |
| D04 | FAIL | Fixed Quartz bulk A0 and lambda-zero A2 differ by 0.2 from exact minimum-norm target. |
| D05 | PARTIAL PASS | Reported KKT on three analytic cases; independent multiplier certificate/perturbation pending. |
| D06 | PARTIAL PASS | One unit and whole-unit LOO pass; repeat-block covariance oracle pending. |
| D07 | PARTIAL PASS | Soft/hard analytic probe passes; full certificate checks pending. |
| D08 | PARTIAL PASS | Rank and permutation probes pass; independent singular/correlation objective checks pending. |
| D09 | PARTIAL PASS | Zero-width bulk/phase and incompatible LP pass; nonzero half-plane oracle pending. |
| D10 | FAIL | 27 parent comparisons, four fixed Quartz minimum-norm disagreements; parent_comparison.json. |
| D11 | BLOCK | Pre-run/post-run gate repaired; source manifest omits test_phase_models.py. Full negative fixture matrix pending. |
| D12 | PENDING | Dataflow sentinel and exhaustive prior/prediction mapping require completed source/gates; no data drawn. |
| D13 | POST-RUN PENDING | Counts/schema require saved run outputs; prohibited to mark PASS pre-run. |
| D14 | POST-RUN PENDING | Metric/failure-copy recomputation requires saved outputs. |
| D15 | POST-RUN PENDING | Saved-observation replay requires the one bounded run. |
| D16 | PARTIAL PASS | AST parse, public design gate, pytest; full preservation/tool audit pending. |

## Primary validation and exact output

Command: `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/emc-phase-mpl PYTEST_ADDOPTS="-p no:cacheprovider" /tmp/bif-v3-world1-validation-env-20261023/bin/python -m pytest -q research/emc-part2b/phase_sensitive/test_phase_models.py research/emc-part2b/phase_sensitive/test_experiment.py`

```text
................                                                         [100%]
16 passed in 0.57s
```

Independent oracle command: `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/emc-phase-mpl /tmp/bif-v3-world1-validation-env-20261023/bin/python research/emc-part2b/phase_sensitive/run/audit/tester_oracles.py`

Actual: 135 metric rows, 133 PASS, 2 FAIL (D04 fixed Quartz A0 and A2 strength zero).

No package build applies to this additive research directory. Ruff and mypy executables were unavailable in PATH; pytest-cov is installed but coverage has not been used as a substitute for named checks.

## Before/after parent compatibility

Parent public `calibration_models.py` was called on the same deterministic calibration and correlated bulk inputs. Of 27 method/support/strength/fixed-Quartz comparisons, 23 agree to mass atol `1e-8`, four fail. Each failed comparison has parent `[0.6,0.2,0.2]`, new `[0.6,0.39999999999999997,-2.302972069330675e-16]`, max absolute error `0.20000000000000023`. Detailed full comparison table: `research/emc-part2b/phase_sensitive/run/audit/parent_comparison.json`. The old implementation satisfies the exact minimum-norm tie; the new one regresses on that fixture.

## Gate and provenance checks

Current `--check` (no draw) output:

```text
{"checked_utc": "2026-10-27T04:16:02.131273+00:00", "design_digest": "7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad", "planned": {"analysis_blocks": 250, "budgets": [0, 2, 5], "cells": [1, 2, 3, 4], "cohort_metrics": 21250, "cohorts": 200, "predictions": 350250, "specimens": 16000, "stage1_arms": ["A0_B", "A1", "A2_B", "A0_T", "A2_T", "A0_H", "A2_H"], "stage1_predictions": 35000, "stage2_arms": ["A0_B", "A0_R", "A0_P", "A1_N", "A2_N", "A1_B", "A2_B", "A1_R", "A2_R", "A1_P", "A2_P", "A2_R0", "A2_P0"], "stage2_predictions": 315250, "truth_calls": 800}, "review_sha256": "eb8621367868a09c04bae1949ac1fe33bb100b6784f7ffdf331824b03d930a0c", "schema": "qar-phase-check-v1", "verdict": "PASS"}
```

Design digest `7f011812d4ecfee33f8184bab59ea0591d98580215782d9dc509e547bfacabad`; strict public review PASS at `2026-10-27T03:58:25.724734+00:00`. New seed manifest probe: seven historical repository manifests, 5,009 historical seed values, 2,000 new streams, zero intersections. This does not yet certify all prior run-directory schedules. Source manifest currently hashes only four source paths and omits `test_phase_models.py`; source/environment freeze has not occurred.

## Required scientific reporting after run

Primary unmeasured A2_P−A2_R at budget five is still unmeasured. The five support/condition groups (accurate, weak, mismatch, wrong-occurrence soft, wrong-occurrence hard), direct versus independent unmeasured strata, whole-unit measured LOO, exact denominators, nonempty LP widths versus infeasible frequency, paired cohort SEs, and all prespecified contrasts remain pending. No prior-mean uncertainty is represented as calibrated posterior coverage. No field validation is claimed.

## Failure routing

- Builder: D04/D10 minimum-norm tie defect; see mailbox and oracle rows.
- Simulator: source manifest omits required new test file; see mailbox. The earlier pre/post certification lifecycle issue is corrected in `4d5635f` and must be rechecked after final source changes.

No study data generation, source changes, package edits, commits, or pushes were performed by tester.
