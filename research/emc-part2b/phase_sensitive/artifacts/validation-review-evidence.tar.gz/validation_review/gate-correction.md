# Simulator gate lifecycle correction

Verdict: source gate corrected; no study draw executed.

The prior `certification_gate()` required D01–D16 PASS before `--run`, although D13 actual counts, D14 saved metrics/failure copy, and D15 replay can only be checked after the run. It therefore blocked the first authorized draw or invited fabricated PASS rows.

The corrected pre-run gate requires evidence-backed PASS for D01–D12 and D16, plus explicit PENDING or NOT_EXECUTED rows with null actual for D13–D15. Freeze creates those pending rows. `--run` saves an exact-byte copy of the pre-run audit and its SHA256 in the execution ledger before launching generation; its CLI verdict is `RUN_COMPLETE_PENDING_POSTCHECKS`. Final `--verify` requires evidence-backed PASS for all D01–D16, unchanged pre-run rows, matching pre-run snapshot hash, existing freeze/review/timestamp checks, and unchanged generated output hashes. New post-run audit evidence is allowed; generated outputs remain immutable. Missing or failed rows do not pass.

Changed only `research/emc-part2b/phase_sensitive/measurement_experiment.py` and its narrow deterministic `test_experiment.py`. Frozen design, preregistration, review, statistical settings, seeds, generator, model, and old study were untouched. The source edit requires a new source/environment freeze before any draw, as the harness enforces.

Validation: focused two-test gate run passed (`2 passed, 9 deselected`) using `/tmp/decision-value-fresh-venv-20261017/bin/python`; `python3 -m py_compile` and `git diff --check` passed. System Python lacked pytest. No comparative run, new random data, or post-run evidence was created. D13–D15 remain pending until the tester has actual outputs.

Local worktree commit: `4d5635f` (`simulator: separate pre-run and post-run certification gates`). No push.
