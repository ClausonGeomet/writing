# Builder numerical correction — minimum-norm face ties

Commit: `4d31354` (`builder: preserve minimum-norm ties on singular faces`), local only; no push. Worktree clean after commit.

The reduced face Hessian was numerically nonzero along the analytically flat Anatase–Rutile direction when Quartz was fixed. The one-dimensional least-squares solve treated that roundoff as identification and selected a boundary point. `phase_models.py` now uses a symmetric eigendecomposition and a named `REDUCED_RANK_TOL = 1e-12` relative to the full Hessian spectral norm. It solves only identified directions and leaves null coordinates at zero in the minimum-norm face parameterization. Original objective evaluation, face enumeration, feasibility and KKT certification remain in place; no ridge or tolerance widening was introduced.

`test_phase_models.py` adds two deterministic regressions: correlated bulk with fixed Quartz for A0 and A2 strength zero, Quartz at 0 and 1, hard support, and an analytic correlated full-rank phase observation oracle. The independent witness now returns mass `[0.6, 0.2, 0.2]` within `1e-8` for A0; the zero-strength A2 case uses a fixed-Quartz-feasible prior and returns the same mass.

Focused checks:

1. `/tmp/bif-v3-world1-validation-env-20261023/bin/python -m pytest -q research/emc-part2b/phase_sensitive/test_phase_models.py -k 'fixed_quartz_singular_ties_and_zero_strength or fixed_quartz_full_rank_correlated_solution'` — 2 passed.
2. `/tmp/bif-v3-world1-validation-env-20261023/bin/python -m pytest -q research/emc-part2b/phase_sensitive/test_phase_models.py -k 'full_covariance_and_singular_a0_minimum_norm or correlated_assay_closed_form_oracle or whole_unit_exclusion_and_cross_repeat_covariance'` — 3 passed.
3. `git diff --check` — passed before commit.

No comparative data were generated. Frozen design and prior source were unchanged. Tester must rerun independent deterministic certification and source/environment freeze before the bounded measurement run.
