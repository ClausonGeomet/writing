# Simulator missing-row correction — 2026-10-27

Verdict: **SOURCE READY FOR INDEPENDENT TESTER AUDIT**. This is a draw-free source correction. It does not change the frozen design, inputs, results, archives, seeds, thresholds, or original executed sources. No full saved-result certification or scientific clearance is claimed here.

## Exact diff scope and identity

Local commit `807a0b8dcdc2913e07033385e9d996ec99503352`, parent `bf1b5085a216d7fce3a610bd84a456a7a1586450`, sole author Matt Clauson, no trailers. It changes exactly two additive files:

- `research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py`: one line replaced in `masked_record()`; `n_failure` is now `n_planned - n_success`, so absent required rows count as failures alongside present unsuccessful rows. SHA256 `2a95a0bc777603e003cade593c1fbf5e00d30b1ef6da5ea2446b8df891b374a2` (previous `bb3e993bdd22e93811b0ada715e2604d0ca98c1e56e086d0bd9abdfafedd7eac`). The draw-free CLI remains `--input-attempt PATH --evidence-output FRESH_PATH --verify-saved`.
- `research/emc-part2b/phase_sensitive/test_experiment_corrected.py`: nine lines added for a deterministic 29-success-of-30 missing-row regression. SHA256 `97e0767e2f7e3d074a8162c99a05a0f56b4d37e8f431d6cf1933d0d4650c8128` (previous `ee62e70709f8c0db88c7544e1fa412a9655ad8563794a19a1c9402dfbd5270da`).

`git show --numstat HEAD` reports 1 insertion/1 deletion in the harness and 9 insertions in the test. `git diff --check HEAD^ HEAD` passed and the worktree is clean. The correction contract SHA256 is `dd865b1452a6309ea77439e4cdaeb5842aa03bedaa350111423aeb07cd097bd1`.

The five historical executed-source hashes still match the earlier handoff: `measurement_experiment.py` `9577c4799d5ff8fbb8bbd14098cac23cafe8567fab91521ec46f0320c092d222`; `generation.R` `16432637b16c4a72eb07ec340d08cc96910d2d3172285d503b18e96428066610`; `test_experiment.py` `f1fc233065121554fd0e0aef85adb90dc036a03c40ae1cec43c304f8fe528e2e`; `phase_models.py` `2910f0f43c7effb392a8d71edf64c87e4b314712774b076738b127d324ead2e1`; `test_phase_models.py` `44d4bf7bb0057707ac58f8d8c6ddd4a5323c26eb1627c9dc06b0a2f18f480b4b`. The historical attempt and archived files were not opened for writing or regenerated.

## Deterministic checks performed

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/bif-v3-world1-validation-env-20261023/bin/python -m unittest discover -s research/emc-part2b/phase_sensitive -p test_experiment_corrected.py -v`: **9/9 passed**. The new case asserts `n_planned=30, n_success=29, n_failure=1`, `unavailable_matched_failure`, and metadata-only masking. The existing present-failure regression still asserts `2,1,1`. Compilation of both corrected Python files passed. System `python3` could not import NumPy; the frozen validation environment was used for the passing tests. No draws, R calls, new data, or estimate reruns occurred.

## Independent tester handoff

The tester should repeat its missing-required-row probe against this source identity, then independently rerun saved-input proof and scoring with a fresh evidence destination. From the merged checkout with the original saved attempt available:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
/tmp/bif-v3-world1-validation-env-20261023/bin/python \
research/emc-part2b/phase_sensitive/measurement_experiment_corrected.py \
  --input-attempt /home/matt/Documents/GitHub/writing/research/emc-part2b/phase_sensitive/run/attempts/correction-002 \
  --evidence-output /tmp/emc-part2-workspace/writing/runs/REQ-20261027-phase-sensitive/correction-evidence/tester-missing-row-fresh \
  --verify-saved
```

The evidence destination must be unused. Successful independent proof remains pending; the previous scientific STOP remains in force until tester and reviewer finish.
